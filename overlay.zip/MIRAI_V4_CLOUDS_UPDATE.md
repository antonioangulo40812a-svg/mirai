# Mirai V4 — Photoreal Clouds / Sunset update

This overlay patch upgrades the experimental cloud path in `src/include/`.

## Included
- Multi-scale Worley billows and fine edge erosion for more varied cumulus lobes.
- Stronger, less evenly dotted macro coverage mask for the photo preset.
- A separate sparse altocumulus-cloudlet layer above the main cumulus deck (photo style only).
- Retained cloud self-shadowing / approximate ambient occlusion and multiple-scattering shading.
- Warmer, stronger rim lighting near sunrise and sunset.
- A continuous turquoise-blue → mauve → golden-horizon gradient, plus a localized solar halo.
- The same sunset sky in the final pass and Sky Probe so the gradient can be reflected.
- Photo preset overrides and `MIRAI_SUNSET` enabled in the cloud/photo subpacks; default non-cloud subpack remains unchanged.

## Build/testing status
Static checks were run on preprocessor block balance, variant JSON, and variant macro names. This archive does not contain the project's `build.py` or Android material compiler outputs, and no Minecraft runtime is available here, so this update has **not** been compiled or visually validated in Bedrock. The `photo` subpack is intentionally the expensive quality path; performance needs to be measured on-device.
