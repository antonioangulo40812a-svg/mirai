# Mirai V4 — Photoreal Clouds / Sunset update

This overlay patch upgrades the experimental cloud path in `src/include/`.

## Included
- Multi-scale Worley billows and fine edge erosion for more varied cumulus lobes.
- Stronger, less evenly dotted macro coverage mask for the photo preset.
- A separate sparse altocumulus-cloudlet layer above the main cumulus deck (photo style only).
- Retained cloud self-shadowing / approximate ambient occlusion and multiple-scattering shading.
- Warmer, stronger rim lighting near sunrise and sunset.
- Chronological two-stage twilight: brief golden hour while the sun is above the horizon, then pale yellow → mauve → turquoise after sunset; plus a localized solar halo.
- Subtle warm direct-light tint during golden hour, with a softer peach tint as the sun nears the horizon.
- The same sunset sky in the final pass and Sky Probe so the gradient can be reflected.
- Photo preset overrides and `MIRAI_SUNSET` enabled in the cloud/photo subpacks; default non-cloud subpack remains unchanged.

## Build/testing status
Static checks were run on ZIP integrity, preprocessor block balance, variant JSON, and variant macro names. The sunset phase logic was adjusted to use signed sun elevation, so the post-sunset palette is intended to activate after the sun crosses the horizon. Changes were not compiled or visually validated in Bedrock. This archive does not contain the project's `build.py` or Android material compiler outputs, and no Minecraft runtime is available here, so this update has **not** been compiled or visually validated in Bedrock. The `photo` subpack is intentionally the expensive quality path; performance needs to be measured on-device.


Night desaturation correction: reduced the neutral ambient-light floor at low sky-light levels and preserved more chroma in sky-derived indirect lighting. Volumetric cloud source is unchanged. This is a code-level adjustment only; compile and in-game validation are still required.
