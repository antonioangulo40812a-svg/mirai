#ifndef MIRAI_GOLDEN_HOUR_INCLUDED
#define MIRAI_GOLDEN_HOUR_INCLUDED

// Golden hour. e = sin(sun elevation) = SunDir.y
//  * golden peak : sun roughly between 3 and 17 degrees, brief
//  * gold -> peach: the colour slides towards peach and the strength drops while the sun
//    reaches the horizon
//  * gone before night: nothing is left below about -4 degrees, so the night is never tinted
// It is applied to the LIGHT colours (direct light, ambient/fog), so blocks, vegetation,
// clouds and reflections all receive it. It does not touch the gradients of the sky above.

float goldenGold(float e) {
    return (1.0 - smoothstep(0.16, 0.34, e)) * smoothstep(0.0, 0.12, e);
}
float goldenPeach(float e) {
    return (1.0 - smoothstep(0.0, 0.10, e)) * smoothstep(-0.07, 0.0, e);
}
float goldenWeight(float e) {
    return clamp(goldenGold(e) + goldenPeach(e), 0.0, 1.0);
}

// multiplicative tint for light colours (1,1,1 = no change)
vec3 goldenHourTint(float e, float amount) {
    float wg = goldenGold(e);
    float wp = goldenPeach(e);
    vec3 tint = vec3(1.0);
    tint = mix(tint, GOLDEN_GOLD, clamp(wg * amount, 0.0, 1.0));
    tint = mix(tint, GOLDEN_PEACH, clamp(wp * amount, 0.0, 1.0));
    float lum = dot(tint, vec3(0.2126, 0.7152, 0.0722));
    tint = tint / max(lum, 0.0001);                    // keep the brightness, shift the colour
    return tint * (1.0 + GOLDEN_PEAK_BOOST * wg);      // a slightly brighter, brief peak
}

#endif
