#include "diag_config.glsl"

///////////////////////////////////////////////////////////
// VERTEX SHADER
///////////////////////////////////////////////////////////
#if SHADER_STAGE__VERTEX
#if FALLBACK_PASS
void main() {
    gl_Position = vec4(0.0);
}
#elif CAUSTICS_MULTIPLIER_PASS
in vec3 a_position;
void main() {
    gl_Position = vec4(a_position.xy * 2.0 - 1.0, a_position.z, 1.0);
}
#else
uniform vec4 SunDir;
uniform vec4 MoonDir;
uniform vec4 SunColor;

#include "lib/atmosphere.glsl"

in vec3 a_position;
in vec2 a_texcoord0;

layout(location = 0) out vec2 v_texcoord0;
#if !DIRECTIONAL_LIGHTING_PASS
layout(location = 1) flat out vec3 v_scatterColor;
#endif
#if !DISCRETE_INDIRECT_COMBINED_LIGHTING_PASS
layout(location = 2) flat out vec3 v_absorbColor;
layout(location = 3) out vec2 v_projPos;
#endif

void main() {
    v_texcoord0 = a_texcoord0;
    vec3 absorbColor, scatterColor;
    calcAtmLighting(SunDir.xyz, MoonDir.xyz, SunColor.r, absorbColor, scatterColor);
#if !DISCRETE_INDIRECT_COMBINED_LIGHTING_PASS
    v_absorbColor = absorbColor;
    v_projPos = a_position.xy * 2.0 - 1.0;
#endif
#if !DIRECTIONAL_LIGHTING_PASS
    v_scatterColor = scatterColor;
#endif
    gl_Position = vec4(a_position.xy * 2.0 - 1.0, a_position.z, 1.0);
}
#endif
#endif //SHADER_STAGE__VERTEX

///////////////////////////////////////////////////////////
// FRAGMENT SHADER
///////////////////////////////////////////////////////////
#if SHADER_STAGE__FRAGMENT
#if FALLBACK_PASS
out vec4 fragColor;
void main() {
    fragColor = vec4(0.0);
}
#endif //FALLBACK_PASS

#if CAUSTICS_MULTIPLIER_PASS
out vec4 fragData0;
void main() {
    fragData0 = vec4(0.0, 1.0, 1.0, 1.0);
}
#endif //CAUSTICS_MULTIPLIER_PASS

#if DIRECTIONAL_LIGHTING_PASS
uniform vec4 DirectionalLightSourceWorldSpaceDirection;
uniform vec4 Time;
uniform vec4 WorldOrigin;
uniform vec4 FogAndDistanceControl;
uniform vec4 SunColor;
uniform mat4 u_invViewProj;
uniform mat4 u_view;

SAMPLER2D(s_ColorMetalnessSubsurface);
SAMPLER2D(s_Normal);
SAMPLER2D(s_SceneDepth);
SAMPLER2D(s_CausticsMultiplier);
USAMPLER2D(s_EmissiveAmbientLinearRoughness);

#include "lib/materials.glsl"
#include "lib/space_transf.glsl"
#include "lib/shadow.glsl"
#include "lib/brdf.glsl"
#include "lib/water_wave.glsl"

layout(location = 2) flat in vec3 v_absorbColor;
layout(location = 3) in vec2 v_projPos;
layout(location = 0) in vec2 v_texcoord0;

layout(location = 0) out vec4 fragData0;
layout(location = 1) out vec4 fragData1;

void main() {
    float depth = sampleDepth(s_SceneDepth, v_texcoord0);

    vec3 worldPos = projToWorld(vec3(v_projPos, depth), u_invViewProj);
    vec3 worldDir = normalize(worldPos);
    vec3 position = worldPos - WorldOrigin.xyz;

    uvec4 data16 = texelFetch(s_EmissiveAmbientLinearRoughness,
        ivec2(gl_FragCoord.xy), 0) & 0xFFFFu;
    float roughness = float(data16.r >> 8) * (1.0 / 255.0);
    float emissive = float(data16.r & 0xFFu) * (1.0 / 255.0);

    vec4 data = texture(s_ColorMetalnessSubsurface, v_texcoord0);
    vec3 albedo = toLinear(data.rgb);
    float metalness = unpackMetalness(data.a);
    float subsurface = unpackSubsurface(data.a);
    vec3 f0 = mix(DEFAULT_F0, albedo, metalness);

    vec3 normal = octToNdirSnorm(texture(s_Normal, v_texcoord0).rg);

    vec2 shadowMap = calcShadowMap(worldPos, normal);

    float waterBodyMask = texture(s_CausticsMultiplier, v_texcoord0).r;

    if (waterBodyMask < 1.0) {
        float caustic = calcCaustic(position, DirectionalLightSourceWorldSpaceDirection.xyz,
            Time.x) * PI;
        shadowMap = (FogAndDistanceControl.r < EPSILON)
            ? shadowMap * (caustic + 0.1)
            : shadowMap * (caustic + 1.0);
    }

    vec3 alwaysLit = albedo * emissive * EMISSIVE_MATERIAL_INTENSITY;

    vec3 specular = calcSpecular(normal,
        DirectionalLightSourceWorldSpaceDirection.xyz, -worldDir, f0, roughness);

    albedo = (1.0 - metalness) * albedo;

    subsurface *= linearstep(
        ShadowFilterOffsetAndRangeFarAndMapSizeAndNormalOffsetStrength.y - 8.0,
        ShadowFilterOffsetAndRangeFarAndMapSizeAndNormalOffsetStrength.y - 16.0,
        length(worldPos)
    );

    float fdiffuse = diffuseLambert(normal, DirectionalLightSourceWorldSpaceDirection.xyz);
    float wdiffuse = diffuseWrap(normal, DirectionalLightSourceWorldSpaceDirection.xyz, 0.5);
    vec3 diffuse = mix(fdiffuse, wdiffuse, subsurface) * albedo;
    vec3 tDiffuse = diffuseWrap(-normal,
        DirectionalLightSourceWorldSpaceDirection.xyz, 0.5) * subsurface * albedo;

    vec3 directLightTint = vec3(1.0);
#if MIRAI_SUNSET
    // Directional light is the sun in this pass. Keep the tint subtle so whites remain white
    // while stone, foliage and PBR surfaces pick up a brief golden-hour warmth.
    float sunElevAbs = max(DirectionalLightSourceWorldSpaceDirection.y, 0.0);
    float goldenHour = smoothstep(0.045, 0.085, sunElevAbs)
                     * (1.0 - smoothstep(0.105, 0.165, sunElevAbs));
    float lateWarm = 1.0 - smoothstep(0.012, 0.065, sunElevAbs);
    directLightTint = mix(vec3(1.0), vec3(1.16, 1.055, 0.84), goldenHour * 0.32 + lateWarm * 0.10);
#endif

    fragData0 = depth < 1.0
        ? vec4(v_absorbColor * directLightTint
            * (diffuse * shadowMap.r + tDiffuse * shadowMap.g + specular * shadowMap.r)
            * SunColor.r + alwaysLit, 1.0)
        : vec4(0.0);
    fragData1 = vec4(waterBodyMask, 0.0, 0.0, 1.0);
#if MIRAI_DIAG_AMBIENT
    fragData0 = vec4(0.0);
    // keep the varyings alive so vertex/fragment still link (negligible, non-foldable term)
    fragData0.rgb += (v_absorbColor + vec3(v_projPos, 0.0)) * 1.0e-20;
#endif
}
#endif //DIRECTIONAL_LIGHTING_PASS

#if DISCRETE_INDIRECT_COMBINED_LIGHTING_PASS
uniform vec4 CameraLightIntensity;
uniform vec4 AmbientLightParams;
uniform vec4 DirectionalLightSourceWorldSpaceDirection;

SAMPLER2D(s_ColorMetalnessSubsurface);
USAMPLER2D(s_EmissiveAmbientLinearRoughness);
#if MIRAI_DIAG_AMBIENT || MIRAI_SSAO_CODE
SAMPLER2D(s_SceneDepth);
SAMPLER2D(s_Normal);
#endif

#include "lib/common.glsl"
#include "lib/materials.glsl"
#if MIRAI_SSAO_CODE
#include "ssao.glsl"
#endif

layout(location = 1) flat in vec3 v_scatterColor;
layout(location = 0) in vec2 v_texcoord0;

layout(location = 0) out vec4 fragData0;
layout(location = 1) out vec4 fragData1;
layout(location = 2) out vec4 fragData2;

void main() {
    uvec4 data16 = texelFetch(s_EmissiveAmbientLinearRoughness,
        ivec2(gl_FragCoord.xy), 0) & 0xFFFFu;

    vec4 blightColor = vec4(data16.g >> 8, data16.g & 0xFFu,
        data16.b >> 8, data16.b & 0xFFu) * (1.0 / 255.0);
    float skyLightmap = float(data16.a & 0xFFu) * (1.0 / 255.0);
    float vanillaAO = float(data16.a >> 8) * (1.0 / 255.0);

    vec4 data = texture(s_ColorMetalnessSubsurface, v_texcoord0);

    vec3 albedo = toLinear(data.rgb);
    float metalness = unpackMetalness(data.a);
    albedo = (1.0 - metalness) * albedo;

    vec3 blmColor = blightColor.rgb * blightColor.a * 6.0;
    vec3 blockAmbient = (blmColor + blmColor * blmColor * blmColor * blmColor * 10.0)
        * BLOCK_AMBIENT_MULTIPLIER;

    // Avoid crushing skylight during the post-sunset transition. The original
    // cubic/quintic response removes nearly all ambient contribution at low
    // sky-lightmap values even while the visible sky remains bright.
    float skylmContrib = mix(pow(skyLightmap, 1.8), pow(skyLightmap, 3.0),
        CameraLightIntensity.y);
    // Preserve the chroma of sky-derived indirect light on terrain and foliage.
    vec3 skyAmbient = saturation(v_scatterColor, 0.90)
        * PI * skylmContrib * SKY_AMBIENT_MULTIPLIER;

    // Keep a restrained neutral floor, but don't let the twilight transition
    // collapse the scene to near-black/gray before the night lighting settles.
    float ambientDayFactor = smoothstep(0.035, 0.42, skyLightmap);
    float ambientFloorScale = mix(0.10, 1.0, ambientDayFactor);
    float ambientFloor = AmbientLightParams.a * vanillaAO * vanillaAO
        * (1.0 / EXPOSURE_MULTIPLIER) * ambientFloorScale;
    vec3 ambientLight = max(
        blockAmbient * vanillaAO + skyAmbient * vanillaAO * vanillaAO,
        vec3(ambientFloor)
    );

#if MIRAI_SSAO_CODE
    float ssaoOcc = 0.0;
    float ssaoDepth = sampleDepth(s_SceneDepth, v_texcoord0);
    if (ssaoDepth < 0.9999) {
        vec3 ssaoNormal = octToNdirSnorm(texture(s_Normal, v_texcoord0).rg);
        ssaoOcc = ssaoOcclusion(v_texcoord0, ssaoDepth, ssaoNormal);
    }
#endif
#if MIRAI_SSAO
    ambientLight *= 1.0 - SSAO_STRENGTH * ssaoOcc;
#endif

    fragData0 = vec4(0.0);
#if MIRAI_DIAG == 5
    float dRaw = sampleDepth(s_SceneDepth, v_texcoord0);
    vec3 dbg = vec3(1.0 - dRaw) * 40.0;
    if (dRaw >= 0.9999) dbg = vec3(0.0, 0.8, 1.0);                       // cyan = sky / far
    if (dRaw <= -0.9999 || abs(dRaw) < 0.000001) dbg = vec3(1.0, 0.0, 1.0); // magenta = exactly 0 (empty binding?)
    fragData1 = vec4(dbg * MIRAI_DIAG_AMBIENT_GAIN, 1.0);
#elif MIRAI_DIAG == 6
    vec3 dn = octToNdirSnorm(texture(s_Normal, v_texcoord0).rg);
    fragData1 = vec4((dn * 0.5 + 0.5) * MIRAI_DIAG_AMBIENT_GAIN, 1.0);
#elif MIRAI_DIAG == 7
    fragData1 = vec4(vec3(1.0 - SSAO_STRENGTH * ssaoOcc) * MIRAI_DIAG_AMBIENT_GAIN * 4.0, 1.0);
#else
    fragData1 = vec4(albedo * ambientLight, 1.0);
#endif
#if MIRAI_DIAG_AMBIENT
    fragData1.rgb += v_scatterColor * 1.0e-20; // keep the varying alive (negligible term)
#endif
    fragData2 = vec4(0.0);
}
#endif //DISCRETE_INDIRECT_COMBINED_LIGHTING_PASS

#if SURFACE_RADIANCE_UPSCALE_PASS
uniform vec4 CameraLightIntensity;
uniform vec4 FogColor;
uniform vec4 SunDir;
uniform vec4 MoonDir;
uniform vec4 DirectionalLightSourceWorldSpaceDirection;
uniform vec4 Time;
uniform vec4 FogAndDistanceControl;
uniform vec4 RenderChunkFogAlpha;
uniform vec4 WorldOrigin;
uniform vec4 SunColor;
uniform vec4 FogSkyBlend;
uniform vec4 VolumeDimensions;
uniform vec4 VolumeNearFar;
uniform vec4 VolumeScatteringEnabledAndPointLightVolumetricsEnabled;
uniform mat4 u_invViewProj;
uniform mat4 u_invProj;

SAMPLER2D(s_SceneDepth);
SAMPLER2D(s_DiffuseLighting);
SAMPLER2D(s_SpecularLighting);
SAMPLER2D(s_PreviousFrameAverageLuminance);
SAMPLER2DARRAY(s_ScatteringBuffer);
#if MIRAI_DIAG == 2 || MIRAI_SSGI_CODE
SAMPLER2D(s_Normal);
#endif
#if MIRAI_DIAG == 3 || MIRAI_SSGI_CODE
SAMPLER2D(s_ColorMetalnessSubsurface);
#endif

#include "lib/materials.glsl"
#include "lib/atmosphere.glsl"
#include "lib/froxel_utils.glsl"
#include "lib/clouds.glsl"
#if MIRAI_VCLOUDS
#include "volclouds.glsl"
#endif
#if MIRAI_SUNSET
#include "sunset_sky.glsl"
#endif
#include "lib/space_transf.glsl"
#if MIRAI_SSGI_CODE
#include "ssgi.glsl"
#endif

layout(location = 2) flat in vec3 v_absorbColor;
layout(location = 1) flat in vec3 v_scatterColor;
layout(location = 3) in vec2 v_projPos;
layout(location = 0) in vec2 v_texcoord0;

out vec4 fragData0;

void main() {
    float depth = sampleDepth(s_SceneDepth, v_texcoord0);

    vec3 projPos = vec3(v_projPos, depth);
    vec3 worldPos = projToWorld(projPos, u_invViewProj);
    vec3 worldDir = normalize(worldPos);
    float worldDist = length(worldPos);
    float wDistNorm = worldDist / FogAndDistanceControl.z;

    vec3 outColor = vec3(0.0);

    bool isTerrain = depth < 1.0;
    if (isTerrain) outColor = texture(s_DiffuseLighting, v_texcoord0).rgb;
#if MIRAI_SSGI_CODE
    vec3 giTerm = vec3(0.0);
    vec3 giTint = vec3(1.0);
    bool giWater = texture(s_SpecularLighting, v_texcoord0).r < 1.0
        && FogAndDistanceControl.r < EPSILON;
    if (isTerrain && !giWater) {
        vec4 giData = texture(s_ColorMetalnessSubsurface, v_texcoord0);
        vec3 giAlbedo = toLinear(giData.rgb) * (1.0 - unpackMetalness(giData.a));
        vec3 giNormal = octToNdirSnorm(texture(s_Normal, v_texcoord0).rg);
        giTerm = giAlbedo * ssgiGather(v_texcoord0, depth, giNormal, giAlbedo, giTint) * SSGI_STRENGTH;
    }
#endif
#if MIRAI_SSGI
    outColor = outColor * giTint + giTerm;
#endif

    if (isOverworld(FogSkyBlend.g)) {
        bool isWater = texture(s_SpecularLighting, v_texcoord0).r < 1.0
            && FogAndDistanceControl.r < EPSILON;

        float fogModulator = luminance(v_absorbColor) * CameraLightIntensity.y;

        if (isTerrain) {
            float fogFactor = isWater ? 0.0 : clamp(wDistNorm, 0.0, 1.0);
            outColor = mix(outColor, v_scatterColor * fogModulator * PI,
                fogFactor * fogFactor * BORDER_FOG_INTENSITY);
        } else {
            outColor = calcAtmSky(worldDir, SunDir.xyz, MoonDir.xyz, SunColor.r);
#if MIRAI_SUNSET
            outColor = applySunsetSky(outColor, worldDir, SunDir.xyz);
#endif
        }

        vec3 cloudColor = SunDir.y > 0.0 ? v_absorbColor : v_absorbColor * SunColor.r * 0.5;
        applyCirrusClouds(outColor, worldDir, -WorldOrigin.xyz,
            DirectionalLightSourceWorldSpaceDirection.xyz, cloudColor, Time.x, isTerrain);
#if MIRAI_VCLOUDS
        outColor = applyVolumetricClouds(outColor, worldDir, -WorldOrigin.xyz,
            DirectionalLightSourceWorldSpaceDirection.xyz, cloudColor,
            v_scatterColor * fogModulator * PI, Time.x,
            isTerrain ? worldDist : 1.0e9, gl_FragCoord.xy, SunDir.y);
#endif

        if (isWater) {
            outColor *= exp(-WATER_EXTINCTION_COEFFICIENTS * worldDist);
            outColor = mix(outColor, exp(-WATER_EXTINCTION_COEFFICIENTS * 10.0)
                * fogModulator, 0.01);
        }

        if (VolumeScatteringEnabledAndPointLightVolumetricsEnabled.x > 0.0) {
            vec3 uvw = ndcToVolume(VolumeNearFar.xy, projPos, u_invProj);
            vec4 volumetricFog = sampleVolume(s_ScatteringBuffer, uvw, VolumeDimensions.z);
            outColor = outColor * volumetricFog.a + volumetricFog.rgb;
        }
    } else {
        float fogFactor = clamp((wDistNorm + RenderChunkFogAlpha.x - FogAndDistanceControl.x)
            * FogAndDistanceControl.y, 0.0, 1.0);
        vec3 linFogColor = toLinear(FogColor.rgb) * (1.0 / EXPOSURE_MULTIPLIER);
        outColor = mix(outColor, linFogColor, fogFactor);
    }

    outColor = preExposeLighting(outColor * EXPOSURE_MULTIPLIER,
        texture(s_PreviousFrameAverageLuminance, vec2(0.5)).r);

#if MIRAI_DIAG == 1
    vec3 dbg = vec3(clamp(worldDist / 64.0, 0.0, 1.0));
    if (!isTerrain) dbg = vec3(0.0, 0.0, 0.3);
    else if (fract(worldDist / 8.0) < 0.05) dbg = vec3(1.0, 0.0, 0.0);
    outColor = dbg * MIRAI_DIAG_FINAL_GAIN;
#elif MIRAI_DIAG == 2
    vec3 dn = octToNdirSnorm(texture(s_Normal, v_texcoord0).rg);
    outColor = isTerrain ? (dn * 0.5 + 0.5) * MIRAI_DIAG_FINAL_GAIN : vec3(0.0, 0.0, 0.3);
#elif MIRAI_DIAG == 3
    outColor = isTerrain
        ? toLinear(texture(s_ColorMetalnessSubsurface, v_texcoord0).rgb) * MIRAI_DIAG_FINAL_GAIN
        : vec3(0.0, 0.0, 0.3);
#elif MIRAI_DIAG == 4
    outColor = isTerrain
        ? preExposeLighting(texture(s_DiffuseLighting, v_texcoord0).rgb * EXPOSURE_MULTIPLIER,
            texture(s_PreviousFrameAverageLuminance, vec2(0.5)).r)
        : vec3(0.0, 0.0, 0.3);
#elif MIRAI_DIAG == 8
    outColor = isTerrain
        ? preExposeLighting(giTerm * EXPOSURE_MULTIPLIER,
            texture(s_PreviousFrameAverageLuminance, vec2(0.5)).r) * SSGI_DEBUG_GAIN
        : vec3(0.0, 0.0, 0.3);
#elif MIRAI_DIAG == 9
    outColor = isTerrain ? giTint * 0.5 : vec3(0.0, 0.0, 0.3);
#endif
#if MIRAI_DIAG_FINAL
    outColor += (v_absorbColor + v_scatterColor + vec3(v_projPos, 0.0)) * 1.0e-20; // keep varyings alive
#endif
    fragData0 = vec4(outColor, 1.0);
}
#endif //SURFACE_RADIANCE_UPSCALE_PASS
#endif //SHADER_STAGE__FRAGMENT
