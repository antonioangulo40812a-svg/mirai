#include "diag_config.glsl"

///////////////////////////////////////////////////////////
// VERTEX SHADER
///////////////////////////////////////////////////////////
#if SHADER_STAGE__VERTEX
#if FALLBACK_PASS
void main() {
    gl_Position = vec4(0.0);
}
#elif CAUSTICS_MULTIPLIER_PASS
in vec3 a_position;
void main() {
    gl_Position = vec4(a_position.xy * 2.0 - 1.0, a_position.z, 1.0);
}
#else
uniform vec4 SunDir;
uniform vec4 MoonDir;
uniform vec4 SunColor;

#include "lib/atmosphere.glsl"

in vec3 a_position;
in vec2 a_texcoord0;

layout(location = 0) out vec2 v_texcoord0;
// The debug-only SSGI view discards the ambient term, so this varying is
// intentionally omitted for that pass/configuration to keep the vertex and
// fragment interfaces identical after dead-code elimination.
#if !DIRECTIONAL_LIGHTING_PASS && (!DISCRETE_INDIRECT_COMBINED_LIGHTING_PASS || MIRAI_DIAG != 8)
layout(location = 1) flat out vec3 v_scatterColor;
#endif
// Keep atmospheric transmittance available to the indirect-light pass as well.
layout(location = 2) flat out vec3 v_absorbColor;
#if !DISCRETE_INDIRECT_COMBINED_LIGHTING_PASS
layout(location = 3) out vec2 v_projPos;
#endif

void main() {
    v_texcoord0 = a_texcoord0;
    vec3 absorbColor, scatterColor;
    calcAtmLighting(SunDir.xyz, MoonDir.xyz, SunColor.r, absorbColor, scatterColor);
    v_absorbColor = absorbColor;
#if !DISCRETE_INDIRECT_COMBINED_LIGHTING_PASS
    v_projPos = a_position.xy * 2.0 - 1.0;
#endif
#if !DIRECTIONAL_LIGHTING_PASS && (!DISCRETE_INDIRECT_COMBINED_LIGHTING_PASS || MIRAI_DIAG != 8)
    v_scatterColor = scatterColor;
#endif
    gl_Position = vec4(a_position.xy * 2.0 - 1.0, a_position.z, 1.0);
}
#endif
#endif //SHADER_STAGE__VERTEX

///////////////////////////////////////////////////////////
// FRAGMENT SHADER
///////////////////////////////////////////////////////////
#if SHADER_STAGE__FRAGMENT
#if FALLBACK_PASS
out vec4 fragColor;
void main() {
    fragColor = vec4(0.0);
}
#endif //FALLBACK_PASS

#if CAUSTICS_MULTIPLIER_PASS
out vec4 fragData0;
void main() {
    fragData0 = vec4(0.0, 1.0, 1.0, 1.0);
}
#endif //CAUSTICS_MULTIPLIER_PASS

#if DIRECTIONAL_LIGHTING_PASS
uniform vec4 DirectionalLightSourceWorldSpaceDirection;
uniform vec4 Time;
uniform vec4 WorldOrigin;
uniform vec4 FogAndDistanceControl;
uniform vec4 SunColor;
uniform mat4 u_invViewProj;
uniform mat4 u_view;

SAMPLER2D(s_ColorMetalnessSubsurface);
SAMPLER2D(s_Normal);
SAMPLER2D(s_SceneDepth);
SAMPLER2D(s_CausticsMultiplier);
USAMPLER2D(s_EmissiveAmbientLinearRoughness);

#include "lib/materials.glsl"
#include "lib/space_transf.glsl"
#include "lib/shadow.glsl"
#include "lib/brdf.glsl"
#include "lib/water_wave.glsl"

layout(location = 2) flat in vec3 v_absorbColor;
layout(location = 3) in vec2 v_projPos;
layout(location = 0) in vec2 v_texcoord0;

layout(location = 0) out vec4 fragData0;
layout(location = 1) out vec4 fragData1;

void main() {
    float depth = sampleDepth(s_SceneDepth, v_texcoord0);

    vec3 worldPos = projToWorld(vec3(v_projPos, depth), u_invViewProj);
    vec3 worldDir = normalize(worldPos);
    vec3 position = worldPos - WorldOrigin.xyz;

    uvec4 data16 = texelFetch(s_EmissiveAmbientLinearRoughness,
        ivec2(gl_FragCoord.xy), 0) & 0xFFFFu;
    float roughness = float(data16.r >> 8) * (1.0 / 255.0);
    float emissive = float(data16.r & 0xFFu) * (1.0 / 255.0);

    vec4 data = texture(s_ColorMetalnessSubsurface, v_texcoord0);
    vec3 albedo = toLinear(data.rgb);
    float metalness = unpackMetalness(data.a);
    float subsurface = unpackSubsurface(data.a);
    vec3 f0 = mix(DEFAULT_F0, albedo, metalness);

    vec3 normal = octToNdirSnorm(texture(s_Normal, v_texcoord0).rg);

    vec2 shadowMap = calcShadowMap(worldPos, normal);

    float waterBodyMask = texture(s_CausticsMultiplier, v_texcoord0).r;

    if (waterBodyMask < 1.0) {
        float caustic = calcCaustic(position, DirectionalLightSourceWorldSpaceDirection.xyz,
            Time.x) * PI;
        shadowMap = (FogAndDistanceControl.r < EPSILON)
            ? shadowMap * (caustic + 0.1)
            : shadowMap * (caustic + 1.0);
    }

    vec3 alwaysLit = albedo * emissive * EMISSIVE_MATERIAL_INTENSITY;

    vec3 specular = calcSpecular(normal,
        DirectionalLightSourceWorldSpaceDirection.xyz, -worldDir, f0, roughness);

    albedo = (1.0 - metalness) * albedo;

    subsurface *= linearstep(
        ShadowFilterOffsetAndRangeFarAndMapSizeAndNormalOffsetStrength.y - 16.0,
        ShadowFilterOffsetAndRangeFarAndMapSizeAndNormalOffsetStrength.y - 24.0,
        length(worldPos)
    );

    float fdiffuse = diffuseLambert(normal, DirectionalLightSourceWorldSpaceDirection.xyz);
    float wdiffuse = diffuseWrap(normal, DirectionalLightSourceWorldSpaceDirection.xyz, 0.5);
    vec3 diffuse = mix(fdiffuse, wdiffuse, subsurface) * albedo;
    vec3 tDiffuse = diffuseWrap(-normal,
        DirectionalLightSourceWorldSpaceDirection.xyz, 0.5) * subsurface * albedo;

    fragData0 = depth < 1.0
        ? vec4(v_absorbColor
            * (diffuse * shadowMap.r + tDiffuse * shadowMap.g + specular * shadowMap.r)
            * SunColor.r + alwaysLit, 1.0)
        : vec4(0.0);
    fragData1 = vec4(waterBodyMask, 0.0, 0.0, 1.0);
}
#endif //DIRECTIONAL_LIGHTING_PASS

#if DISCRETE_INDIRECT_COMBINED_LIGHTING_PASS
uniform vec4 CameraLightIntensity;
uniform vec4 AmbientLightParams;
uniform vec4 DirectionalLightSourceWorldSpaceDirection;
uniform vec4 SunColor;
uniform mat4 u_invProj;
uniform mat4 u_proj;
uniform mat4 u_view;
uniform mat4 u_invViewProj;

SAMPLER2D(s_ColorMetalnessSubsurface);
SAMPLER2D(s_Normal);
SAMPLER2D(s_SceneDepth);
USAMPLER2D(s_EmissiveAmbientLinearRoughness);

#include "lib/common.glsl"
#include "lib/materials.glsl"
#include "lib/space_transf.glsl"
#include "lib/shadow.glsl"

// Keep UV-to-NDC conversion inverse to viewToProj() for non-GLSL targets.
vec3 ssgiUvDepthToNdc(vec2 uv, float depth) {
    vec2 ndc = uv * 2.0 - 1.0;
#if !TRANSPILE_TARGET__GLSL
    ndc.y = -ndc.y;
#endif
    return vec3(ndc, depth);
}

#if MIRAI_DIAG != 8
layout(location = 1) flat in vec3 v_scatterColor;
#endif
layout(location = 2) flat in vec3 v_absorbColor;
layout(location = 0) in vec2 v_texcoord0;

layout(location = 0) out vec4 fragData0;
layout(location = 1) out vec4 fragData1;
layout(location = 2) out vec4 fragData2;

#if MIRAI_SSGI
float ssgiHash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

// Cosine-weighted, screen-space diffuse raymarching. A ray contributes only
// when it reaches a visible surface that is directly illuminated by the sun.
// The hit albedo tints the returned radiance, producing screen-space color bleed.
vec3 calcRaymarchedSSGI(
    vec3 startViewPos,
    vec3 startViewNormal,
    vec3 receiverAlbedo
) {
    vec3 n = normalize(startViewNormal);
    vec3 helper = abs(n.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(0.0, 1.0, 0.0);
    vec3 tangent = normalize(cross(helper, n));
    vec3 bitangent = normalize(cross(n, tangent));

    float rotation = ssgiHash(gl_FragCoord.xy) * 6.28318530718;
    vec3 accumulatedRadiance = vec3(0.0);
    vec3 rayOrigin = startViewPos + n * SSGI_BIAS;
    vec3 sunDirection = normalize(DirectionalLightSourceWorldSpaceDirection.xyz);

    for (int rayIndex = 0; rayIndex < SSGI_SAMPLES; ++rayIndex) {
        // Cosine hemisphere distribution (pdf = cos(theta) / PI).
        float xi = (float(rayIndex) + 0.5) / float(SSGI_SAMPLES);
        float phi = float(rayIndex) * 2.39996322973 + rotation;
        float radial = sqrt(xi);
        float vertical = sqrt(max(0.0, 1.0 - xi));
        vec3 localDirection = vec3(radial * cos(phi), radial * sin(phi), vertical);
        vec3 rayDirection = normalize(
            tangent * localDirection.x
            + bitangent * localDirection.y
            + n * localDirection.z
        );

        float previousT = 0.0;
        bool foundHit = false;

        for (int stepIndex = 0; stepIndex < SSGI_RAY_STEPS; ++stepIndex) {
            float stepFraction = (float(stepIndex) + 1.0) / float(SSGI_RAY_STEPS);
            float currentT = SSGI_RADIUS * pow(stepFraction, 1.15);
            float stepLength = currentT - previousT;
            vec3 rayViewPos = rayOrigin + rayDirection * currentT;
            if (rayViewPos.z >= -0.001) break;

            vec3 rayScreen = viewToProj(rayViewPos, u_proj);
            vec2 hitUV = rayScreen.xy;

            if (hitUV.x <= 0.002 || hitUV.y <= 0.002
                || hitUV.x >= 0.998 || hitUV.y >= 0.998) {
                break;
            }

            float hitDepth = sampleDepth(s_SceneDepth, hitUV);
            if (hitDepth >= 0.999) {
                break;
            }

            vec3 hitNdc = ssgiUvDepthToNdc(hitUV, hitDepth);
            vec3 sceneViewPos = projToView(hitNdc, u_invProj);
            float rayLinearDepth = -rayViewPos.z;
            float sceneLinearDepth = -sceneViewPos.z;
            float depthDelta = rayLinearDepth - sceneLinearDepth;
            float thickness = max(SSGI_THICKNESS, stepLength * 0.95);

            if (depthDelta > 0.0 && depthDelta < thickness && currentT > SSGI_BIAS * 2.0) {
                vec3 hitNormal = octToNdirSnorm(texture(s_Normal, hitUV).rg);
                vec3 hitNormalView = normalize((u_view * vec4(hitNormal, 0.0)).xyz);

                // Reject back-facing depth layers and self-intersections.
                if (dot(hitNormalView, rayDirection) < -0.025) {
                    vec3 hitWorldPos = projToWorld(hitNdc, u_invViewProj);
                    vec4 hitMaterial = texture(s_ColorMetalnessSubsurface, hitUV);
                    vec3 hitAlbedo = toLinear(hitMaterial.rgb)
                        * (1.0 - unpackMetalness(hitMaterial.a));

                    float sunNdotL = diffuseLambert(hitNormal, sunDirection);
                    if (sunNdotL > 0.0) {
                        float sunVisibility = calcShadowMap(hitWorldPos, hitNormal).r;
                        vec3 hitDirectRadiance = hitAlbedo
                            * sunNdotL
                            * sunVisibility
                            * v_absorbColor
                            * SunColor.r;
                        accumulatedRadiance += hitDirectRadiance;
                    }
                    foundHit = true;
                }
            }

            if (foundHit) break;
            previousT = currentT;
        }
    }

    // Keep the indirect term bounded: this is a single-bounce screen-space
    // approximation, not a second copy of direct sunlight. Without this cap,
    // bright sun-facing hits can overwhelm Mirai's existing ambient lighting
    // and wash the entire scene toward white.
    vec3 averageBounce = accumulatedRadiance / float(SSGI_SAMPLES);
    averageBounce = clamp(averageBounce, vec3(0.0), vec3(0.35));
    vec3 indirect = receiverAlbedo * averageBounce * SSGI_STRENGTH;
    return min(indirect, receiverAlbedo * 0.32);
}
#endif // MIRAI_SSGI

void main() {
    uvec4 data16 = texelFetch(s_EmissiveAmbientLinearRoughness,
        ivec2(gl_FragCoord.xy), 0) & 0xFFFFu;

    vec4 blightColor = vec4(data16.g >> 8, data16.g & 0xFFu,
        data16.b >> 8, data16.b & 0xFFu) * (1.0 / 255.0);
    float skyLightmap = float(data16.a & 0xFFu) * (1.0 / 255.0);
    float vanillaAO = float(data16.a >> 8) * (1.0 / 255.0);

    vec4 data = texture(s_ColorMetalnessSubsurface, v_texcoord0);

    vec3 albedo = toLinear(data.rgb);
    float metalness = unpackMetalness(data.a);
    albedo = (1.0 - metalness) * albedo;

    vec3 blmColor = blightColor.rgb * blightColor.a * 6.0;
    vec3 blockAmbient = (blmColor + pow(blmColor, vec3(5.0)) * 10.0)
        * BLOCK_AMBIENT_MULTIPLIER;

#if MIRAI_DIAG != 8
    float skylmContrib = skyLightmap * (linearstep(0.9, 1.0, skyLightmap) * 0.5 + 0.5);
    vec3 skyAmbient = saturation(v_scatterColor, 0.5)
        * PI * skylmContrib * SKY_AMBIENT_MULTIPLIER;

    vec3 ambientLight = max(
        blockAmbient * vanillaAO + skyAmbient * vanillaAO * vanillaAO,
        vec3(AmbientLightParams.a * vanillaAO * vanillaAO * (1.0 / EXPOSURE_MULTIPLIER))
    );
#endif

    vec3 ssgiBounce = vec3(0.0);
#if MIRAI_SSGI
    float sceneDepth = sampleDepth(s_SceneDepth, v_texcoord0);
    if (sceneDepth < 0.999) {
        vec3 currentNdc = ssgiUvDepthToNdc(v_texcoord0, sceneDepth);
        vec3 currentViewPos = projToView(currentNdc, u_invProj);
        vec3 currentNormal = octToNdirSnorm(texture(s_Normal, v_texcoord0).rg);
        vec3 currentViewNormal = normalize((u_view * vec4(currentNormal, 0.0)).xyz);
        ssgiBounce = calcRaymarchedSSGI(
            currentViewPos,
            currentViewNormal,
            albedo
        );
    }
#endif

#if MIRAI_DIAG == 8
    fragData1 = vec4(ssgiBounce, 1.0);
#else
    fragData1 = vec4(albedo * ambientLight + ssgiBounce, 1.0);
#endif
    fragData0 = vec4(0.0);
    fragData2 = vec4(0.0);
}
#endif //DISCRETE_INDIRECT_COMBINED_LIGHTING_PASS

#if SURFACE_RADIANCE_UPSCALE_PASS
uniform vec4 CameraLightIntensity;
uniform vec4 FogColor;
uniform vec4 SunDir;
uniform vec4 MoonDir;
uniform vec4 DirectionalLightSourceWorldSpaceDirection;
uniform vec4 Time;
uniform vec4 FogAndDistanceControl;
uniform vec4 RenderChunkFogAlpha;
uniform vec4 WorldOrigin;
uniform vec4 SunColor;
uniform vec4 FogSkyBlend;
uniform mat4 u_invViewProj;
uniform mat4 u_invProj;

SAMPLER2D(s_SceneDepth);
SAMPLER2D(s_DiffuseLighting);
SAMPLER2D(s_SpecularLighting);
SAMPLER2D(s_PreviousFrameAverageLuminance);

#include "lib/materials.glsl"
#include "lib/atmosphere.glsl"
#include "lib/clouds.glsl"
#include "lib/space_transf.glsl"

layout(location = 2) flat in vec3 v_absorbColor;
layout(location = 1) flat in vec3 v_scatterColor;
layout(location = 3) in vec2 v_projPos;
layout(location = 0) in vec2 v_texcoord0;

out vec4 fragData0;

void main() {
    float depth = sampleDepth(s_SceneDepth, v_texcoord0);

    vec3 projPos = vec3(v_projPos, depth);
    vec3 worldPos = projToWorld(projPos, u_invViewProj);
    vec3 worldDir = normalize(worldPos);
    float worldDist = length(worldPos);
    float wDistNorm = worldDist / FogAndDistanceControl.z;

    vec3 outColor = vec3(0.0);

    bool isTerrain = depth < 1.0;
    if (isTerrain) outColor = texture(s_DiffuseLighting, v_texcoord0).rgb;

    if (isOverworld(FogSkyBlend.g)) {
        bool isWater = texture(s_SpecularLighting, v_texcoord0).r < 1.0
            && FogAndDistanceControl.r < EPSILON;

        float fogModulator = luminance(v_absorbColor) * CameraLightIntensity.y;

        if (isTerrain) {
            float fogFactor = isWater ? 0.0 : clamp(wDistNorm, 0.0, 1.0);
            outColor = mix(outColor, v_scatterColor * fogModulator * PI,
                fogFactor * fogFactor * BORDER_FOG_INTENSITY);
        } else {
            outColor = calcAtmSky(worldDir, SunDir.xyz, MoonDir.xyz, SunColor.r);
        }

        vec3 cloudColor = SunDir.y > 0.0 ? v_absorbColor : v_absorbColor * SunColor.r * 0.5;
        applyCirrusClouds(outColor, worldDir, -WorldOrigin.xyz,
            DirectionalLightSourceWorldSpaceDirection.xyz, cloudColor, Time.x, isTerrain);

        if (isWater) {
            outColor *= exp(-WATER_EXTINCTION_COEFFICIENTS * worldDist);
            outColor = mix(outColor, exp(-WATER_EXTINCTION_COEFFICIENTS * 10.0)
                * fogModulator, 0.01);
        }

    } else {
        float fogFactor = clamp((wDistNorm + RenderChunkFogAlpha.x - FogAndDistanceControl.x)
            * FogAndDistanceControl.y, 0.0, 1.0);
        vec3 linFogColor = toLinear(FogColor.rgb) * (1.0 / EXPOSURE_MULTIPLIER);
        outColor = mix(outColor, linFogColor, fogFactor);
    }

    outColor = preExposeLighting(outColor * EXPOSURE_MULTIPLIER,
        texture(s_PreviousFrameAverageLuminance, vec2(0.5)).r);

    fragData0 = vec4(outColor, 1.0);
}
#endif //SURFACE_RADIANCE_UPSCALE_PASS
#endif //SHADER_STAGE__FRAGMENT
