#ifndef MIRAI_SSGI_INCLUDED
#define MIRAI_SSGI_INCLUDED

// Screen space indirect light (one bounce), final pass.
// Samples visible surfaces around each pixel and gathers the light they emit
// (s_DiffuseLighting already contains albedo * light, so colour bleeding comes for free).
// Requires before this include: s_SceneDepth, s_Normal, s_DiffuseLighting samplers
// and the uniforms u_invProj (declared by the pass). View-space units, 1 unit ~ 1 block.

uniform mat4 u_view;
uniform mat4 u_proj;

vec2 ssgiUvToNdc(vec2 uv) {
    vec2 ndc = uv * 2.0 - 1.0;
#if !TRANSPILE_TARGET__GLSL
    ndc.y = -ndc.y;
#endif
    return ndc;
}

// 4x4 ordered (Bayer) rotation: regular fine pattern instead of white noise
float ssgiRotation() {
    ivec2 p = ivec2(mod(gl_FragCoord.xy, 4.0));
    int a = p.x ^ p.y;
    int idx = ((a & 1) << 3) | ((p.y & 1) << 2) | (a & 2) | ((p.y & 2) >> 1);
    return float(idx) * (6.2831853 / 16.0);
}

// returns averaged incoming radiance (same units as s_DiffuseLighting), NOT multiplied by albedo
vec3 ssgiGather(vec2 uv, float depth, vec3 worldNormal) {
    vec3 viewPos = projToView(vec3(ssgiUvToNdc(uv), depth), u_invProj);
    float dist = length(viewPos);

    float fade = 1.0 - smoothstep(SSGI_FADE_START, SSGI_FADE_END, dist);
    if (fade <= 0.0) return vec3(0.0);

    vec3 n = normalize((u_view * vec4(worldNormal, 0.0)).xyz);
    vec3 helper = abs(n.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 t = normalize(cross(helper, n));
    vec3 b = cross(n, t);

    float rot = ssgiRotation();
    vec3 sum = vec3(0.0);

    for (int i = 0; i < SSGI_SAMPLES; ++i) {
        float fi = (float(i) + 0.5) / float(SSGI_SAMPLES);
        float phi = float(i) * 2.3999632 + rot;
        float sxy = sqrt(fi);
        float cz = sqrt(1.0 - fi);
        vec3 h = vec3(cos(phi) * sxy, sin(phi) * sxy, cz);
        float r = 0.25 + 0.75 * fract(fi * 3.7);
        float reach = SSGI_RADIUS * r;

        vec3 sampleView = viewPos + (t * h.x + b * h.y + n * h.z) * reach;
        vec3 sp = viewToProj(sampleView, u_proj);
        if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0) continue;

        float sceneDepth = sampleDepth(s_SceneDepth, sp.xy);
        if (sceneDepth >= 0.9999) continue;

        vec3 emitView = projToView(vec3(ssgiUvToNdc(sp.xy), sceneDepth), u_invProj);
        // the visible surface must be close to the sample point, otherwise it is unrelated geometry
        if (distance(emitView, sampleView) > SSGI_RADIUS * 0.5) continue;

        vec3 d = emitView - viewPos;
        float dl = length(d);
        if (dl < 0.15) continue;
        vec3 dir = d / dl;

        vec3 emitNormalW = octToNdirSnorm(textureLod(s_Normal, sp.xy, 0.0).rg);
        vec3 emitNormal = normalize((u_view * vec4(emitNormalW, 0.0)).xyz);

        float cosR = max(dot(n, dir), 0.0);
        float cosE = max(dot(emitNormal, -dir), 0.0);
        float att = 1.0 / (1.0 + dl * dl * (4.0 / (SSGI_RADIUS * SSGI_RADIUS)));
        float w = cosR * cosE * att;

#if SSGI_VIS_CHECK
        if (w > 0.0) {
            // something in front of the middle of the segment blocks the light
            vec3 midView = (viewPos + emitView) * 0.5;
            vec3 mp = viewToProj(midView, u_proj);
            if (mp.x >= 0.0 && mp.x <= 1.0 && mp.y >= 0.0 && mp.y <= 1.0) {
                float midDepth = sampleDepth(s_SceneDepth, mp.xy);
                vec3 midScene = projToView(vec3(ssgiUvToNdc(mp.xy), midDepth), u_invProj);
                if (length(midScene) < length(midView) - 0.2) w = 0.0;
            }
        }
#endif

        if (w > 0.0) {
            vec3 L = textureLod(s_DiffuseLighting, sp.xy, 0.0).rgb;
            L = mix(vec3(luminance(L)), L, SSGI_BLEED);
            sum += L * w;
        }
    }
    return sum * (fade / float(SSGI_SAMPLES));
}

#endif
