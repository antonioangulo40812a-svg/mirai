#ifndef MIRAI_SSGI_INCLUDED
#define MIRAI_SSGI_INCLUDED

// Screen space indirect light (one bounce) + colour bleeding, final pass.
//
// For every pixel we gather the visible surfaces around it IN SCREEN SPACE (disk of
// radius SSGI_RADIUS world units projected to the screen), reconstruct them in view
// space and weigh each one by geometry (both surfaces must face each other, distance
// falloff, optional occlusion test). s_DiffuseLighting already holds albedo * light,
// so the gathered radiance carries the colour of the emitting surface.
//
// Two outputs:
//   return value : averaged incoming radiance (caller multiplies by receiver albedo)
//   tint         : multiplicative colour shift of the receiver (energy preserving),
//                  = (average chroma of neighbours) / (chroma of the receiver)
//
// Requires before this include: s_SceneDepth, s_Normal, s_DiffuseLighting samplers and
// u_invProj (declared by the pass). View-space units, 1 unit ~ 1 block.

uniform mat4 u_view;
uniform mat4 u_proj;

vec2 ssgiUvToNdc(vec2 uv) {
    vec2 ndc = uv * 2.0 - 1.0;
#if !TRANSPILE_TARGET__GLSL
    ndc.y = -ndc.y;
#endif
    return ndc;
}

// 4x4 ordered (Bayer) rotation: regular fine pattern instead of white noise
float ssgiRotation() {
    ivec2 p = ivec2(mod(gl_FragCoord.xy, 4.0));
    int a = p.x ^ p.y;
    int idx = ((a & 1) << 3) | ((p.y & 1) << 2) | (a & 2) | ((p.y & 2) >> 1);
    return float(idx) * (6.2831853 / 16.0);
}

vec3 ssgiGather(vec2 uv, float depth, vec3 worldNormal, out vec3 tint) {
    tint = vec3(1.0);

    vec3 viewPos = projToView(vec3(ssgiUvToNdc(uv), depth), u_invProj);
    float dist = length(viewPos);

    float fade = 1.0 - smoothstep(SSGI_FADE_START, SSGI_FADE_END, dist);
    if (fade <= 0.0) return vec3(0.0);

    vec3 n = normalize((u_view * vec4(worldNormal, 0.0)).xyz);

    vec3 Lr = textureLod(s_DiffuseLighting, uv, 0.0).rgb;
    float lumR = max(luminance(Lr), 1.0e-5);
    vec3 chromaR = Lr / lumR;

    // screen-space size (in uv) of SSGI_RADIUS world units at this distance
    vec2 duv = 0.5 * vec2(u_proj[0][0], u_proj[1][1]) * (SSGI_RADIUS / max(dist, 0.5));
    duv = min(duv, vec2(0.4));   // generous cap: a tight cap makes the reach depend on distance

    float rot = ssgiRotation();
    vec3 sum = vec3(0.0);
    vec3 chromaSum = vec3(0.0);
    float wSum = 0.0;

    for (int i = 0; i < SSGI_SAMPLES; ++i) {
        float fi = (float(i) + 0.5) / float(SSGI_SAMPLES);
        float phi = float(i) * 2.3999632 + rot;          // golden angle spiral
        float rr = 0.06 + 0.94 * fi * fi;                // denser near the receiver (contact)
        vec2 o = vec2(cos(phi), sin(phi)) * rr;

        vec2 uvS = uv + o * duv;
        if (uvS.x < 0.0 || uvS.x > 1.0 || uvS.y < 0.0 || uvS.y > 1.0) continue;

        float sceneDepth = sampleDepth(s_SceneDepth, uvS);
        if (sceneDepth >= 0.9999) continue;              // sky is not a surface

        vec3 emitView = projToView(vec3(ssgiUvToNdc(uvS), sceneDepth), u_invProj);
        vec3 d = emitView - viewPos;
        float dl = length(d);
        float reach = SSGI_RADIUS * 1.5;
        if (dl < 0.02 || dl >= reach) continue;          // unrelated geometry
        vec3 dir = d / dl;

        vec3 emitNormalW = octToNdirSnorm(textureLod(s_Normal, uvS, 0.0).rg);
        vec3 emitNormal = normalize((u_view * vec4(emitNormalW, 0.0)).xyz);

        float cosR = max(dot(n, dir), 0.0);              // receiver faces the emitter
        float cosE = max(dot(emitNormal, -dir), 0.0);    // emitter faces the receiver
        float att = 1.0 / (1.0 + dl * dl * (SSGI_FALLOFF / (SSGI_RADIUS * SSGI_RADIUS)));
        float win = 1.0 - smoothstep(0.35 * reach, reach, dl); // weight reaches 0 smoothly, no hard edge
        float w = cosR * cosE * att * win;

#if SSGI_VIS_CHECK
        if (w > 0.0) {
            // something in front of the middle of the segment blocks the light
            vec3 midView = (viewPos + emitView) * 0.5;
            vec3 mp = viewToProj(midView, u_proj);
            if (mp.x >= 0.0 && mp.x <= 1.0 && mp.y >= 0.0 && mp.y <= 1.0) {
                float midDepth = sampleDepth(s_SceneDepth, mp.xy);
                vec3 midScene = projToView(vec3(ssgiUvToNdc(mp.xy), midDepth), u_invProj);
                if (length(midScene) < length(midView) - 0.2) w = 0.0;
            }
        }
#endif

        if (w > 0.0) {
            vec3 L = textureLod(s_DiffuseLighting, uvS, 0.0).rgb;
            float lum = max(luminance(L), 1.0e-6);
            sum += mix(vec3(lum), L, SSGI_BLEED) * w;
            float wt = w * min(lum / lumR, 2.0);         // brighter emitters bleed more
            chromaSum += (L / lum) * wt;
            wSum += wt;
        }
    }

    // colour bleeding: shift the receiver towards the colour of what surrounds it
    if (wSum > 1.0e-5) {
        float coverage = 1.0 - exp(-wSum * 2.0);
        vec3 rel = (chromaSum / wSum) / max(chromaR, vec3(0.05));
        vec3 t = mix(vec3(1.0), rel, SSGI_TINT * coverage);
        t = clamp(t, vec3(0.4), vec3(2.0));
        t = t / max(luminance(t), 1.0e-3);               // keep brightness, change colour only
        tint = mix(vec3(1.0), t, fade);
    }

    return sum * (fade * SSGI_GAIN / float(SSGI_SAMPLES));
}

#endif
