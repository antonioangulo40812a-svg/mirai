#ifndef MIRAI_SUNSET_SKY_INCLUDED
#define MIRAI_SUNSET_SKY_INCLUDED

// Chronological twilight treatment:
// 1) golden hour while the sun is above the horizon;
// 2) pale-yellow -> mauve -> turquoise only after the sun has set.
vec3 applySunsetSky(vec3 skyColor, vec3 viewDir, vec3 sunDir)
{
    float sunElevation = sunDir.y;
    float preSunset = smoothstep(-0.025, 0.018, sunElevation);
    float postSunset = 1.0 - smoothstep(-0.010, 0.075, sunElevation);
    float twilightWindow = max(1.0 - smoothstep(0.010, 0.205, abs(sunElevation)), 0.0);
    if (twilightWindow <= 0.001) return skyColor;

    // Short, intense golden phase strictly before sunset.
    float goldenBand = smoothstep(0.045, 0.085, sunElevation)
                     * (1.0 - smoothstep(0.105, 0.165, sunElevation));
    float goldenHour = goldenBand * preSunset;

    // Post-sunset gradient: pale yellow at the horizon, mauve in the middle, turquoise above.
    float h = max(viewDir.y, 0.0);
    float lowerToMauve = smoothstep(0.018, 0.265, h);
    float mauveToBlue = smoothstep(0.29, 0.79, h);
    vec3 lateGradient = mix(vec3(1.0, 0.82, 0.48), SUNSET_MAUVE, lowerToMauve);
    lateGradient = mix(lateGradient, SUNSET_BLUE, mauveToBlue);

    // Golden hour fades into the ordinary atmospheric sky above the horizon.
    float goldToSky = smoothstep(0.025, 0.70, h);
    vec3 goldenGradient = mix(SUNSET_GOLD, skyColor, goldToSky);
    vec3 gradient = mix(lateGradient, goldenGradient, goldenHour);

    // Palette weights are phase-specific: late palette is suppressed before sunset and
    // takes over after the sun dips below the horizon.
    float latePhase = postSunset * twilightWindow;
    float goldenPhase = goldenHour * twilightWindow;
    float phaseWeight = clamp(max(latePhase, goldenPhase), 0.0, 1.0);
    float horizonWeight = 1.0 - smoothstep(0.025, 0.56, h);
    float zenithWeight = smoothstep(0.24, 0.84, h);
    float lateWeight = SUNSET_STRENGTH * latePhase * (0.30 + 0.24 * horizonWeight + 0.035 * zenithWeight);
    float goldWeight = SUNSET_STRENGTH * goldenPhase * (0.30 + 0.24 * horizonWeight + 0.035 * zenithWeight);
    skyColor = mix(skyColor, lateGradient, clamp(lateWeight, 0.0, 0.74));
    skyColor = mix(skyColor, goldenGradient, clamp(goldWeight, 0.0, 0.74));

    // Solar halo is warm near sunset but naturally fades after the sun disappears.
    float sunDot = clamp(dot(normalize(viewDir), normalize(sunDir)), 0.0, 1.0);
    float angularDistance = 1.0 - sunDot;
    float broadHalo = exp(-angularDistance * 115.0);
    float innerHalo = exp(-angularDistance * 520.0);
    float solarCore = exp(-angularDistance * 2400.0);
    float horizonGate = 1.0 - smoothstep(0.035, 0.30, h);
    vec3 haloColor = mix(vec3(1.0, 0.78, 0.43), SUNSET_GOLD, goldenHour);
    vec3 glow = haloColor * twilightWindow * horizonGate * preSunset
        * (0.065 * broadHalo + 0.13 * innerHalo + (0.38 + 0.16 * goldenHour) * solarCore);
    return skyColor + glow;
}
#endif
