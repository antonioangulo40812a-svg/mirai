#ifndef MIRAI_SUNSET_SKY_INCLUDED
#define MIRAI_SUNSET_SKY_INCLUDED

#if MIRAI_GOLDEN
#include "golden_hour.glsl"
#endif

// Soft stylised-atmospheric gradient for dawn/dusk. The palette is blended over the existing
// atmospheric scattering instead of replacing it with flat bands. A tight and a broad angular
// lobe around the sun create a bloom-like aureole without tinting the whole night sky orange.
vec3 applySunsetSky(vec3 skyColor, vec3 viewDir, vec3 sunDir)
{
    float sunElevation = sunDir.y;
    float sunsetWindow = (1.0 - smoothstep(0.012, 0.205, abs(sunElevation)))
                       * smoothstep(-0.045, 0.004, sunElevation);
    if (sunsetWindow <= 0.001) return skyColor;

    float h = max(viewDir.y, 0.0);
    float lowerToMauve = smoothstep(0.015, 0.255, h);
    float mauveToBlue = smoothstep(0.285, 0.78, h);
    vec3 gradient = mix(SUNSET_GOLD, SUNSET_MAUVE, lowerToMauve);
    gradient = mix(gradient, SUNSET_BLUE, mauveToBlue);

    // More color in the lower atmosphere, less replacement at the zenith; the two smoothstep
    // ranges intentionally overlap to avoid a visible boundary between mauve and turquoise-blue.
    float horizonWeight = 1.0 - smoothstep(0.03, 0.52, h);
    float zenithWeight = smoothstep(0.22, 0.82, h);
    float paletteWeight = SUNSET_STRENGTH * sunsetWindow * (0.43 + 0.30 * horizonWeight + 0.06 * zenithWeight);
    // Preserve the scattering detail, but give the lower atmosphere a clearly saturated
    // amber-orange band instead of letting the renderer wash it into pale yellow.
    skyColor = mix(skyColor, gradient, clamp(paletteWeight, 0.0, 0.86));

    // Solar halo is based on angular distance, not screen coordinates, so it follows the sun
    // and can be reflected by the Sky Probe. Keep the wide aureole restrained; the narrow core
    // supplies the bright golden hotspot that bloom can pick up if the renderer enables it.
    float sunDot = clamp(dot(normalize(viewDir), normalize(sunDir)), 0.0, 1.0);
    float angularDistance = 1.0 - sunDot;
    float broadHalo = exp(-angularDistance * 72.0);
    float innerHalo = exp(-angularDistance * 330.0);
    float solarCore = exp(-angularDistance * 1800.0);
    float horizonGate = 1.0 - smoothstep(0.025, 0.36, h);
    vec3 glow = SUNSET_GOLD * sunsetWindow * horizonGate
              * (0.24 * broadHalo + 0.42 * innerHalo + 1.05 * solarCore);
    // Warm, low-intensity aureole spreads into nearby sky; the narrow core remains bright
    // enough to read as a solar glow without adding orange to the night sky.
    skyColor += glow;

#if MIRAI_GOLDEN
    // golden-orange strip on the horizon: only the lowest few degrees, fading together with the
    // golden hour (gold in the afternoon, peach at the end), stronger towards the sun
    {
        float gw = goldenWeight(sunElevation);
        float stripH = pow(1.0 - smoothstep(0.0, GOLDEN_STRIP_HEIGHT, h), 0.65);   // wide soft falloff upwards
        float peachRatio = goldenPeach(sunElevation) / max(gw, 0.0001);
        float hd = sqrt(viewDir.x * viewDir.x + viewDir.z * viewDir.z);
        float hs = sqrt(sunDir.x * sunDir.x + sunDir.z * sunDir.z);
        float az = (viewDir.x * sunDir.x + viewDir.z * sunDir.z) / max(hd * hs, 0.0001);
        float toward = smoothstep(-0.6, 1.0, az);
        vec3 stripCol = mix(GOLDEN_STRIP_GOLD, GOLDEN_STRIP_PEACH, clamp(peachRatio, 0.0, 1.0));
        stripCol = stripCol / max(luminance(stripCol), 0.0001);
        float k = gw * stripH * (0.5 + 0.5 * toward) * GOLDEN_STRIP_STRENGTH;
        skyColor = mix(skyColor, stripCol * (luminance(skyColor) * 1.0 + 0.01), clamp(k, 0.0, 1.0));
    }
#endif
    return skyColor;
}

#endif
