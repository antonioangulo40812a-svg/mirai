#ifndef MIRAI_SUNSET_SKY_INCLUDED
#define MIRAI_SUNSET_SKY_INCLUDED

// Soft stylised-atmospheric gradient for dawn/dusk. The palette is blended over the existing
// atmospheric scattering instead of replacing it with flat bands. A tight and a broad angular
// lobe around the sun create a bloom-like aureole without tinting the whole night sky orange.
vec3 applySunsetSky(vec3 skyColor, vec3 viewDir, vec3 sunDir)
{
    float sunElevation = sunDir.y;
    float sunsetWindow = (1.0 - smoothstep(0.012, 0.205, abs(sunElevation)))
                       * smoothstep(-0.045, 0.004, sunElevation);
    if (sunsetWindow <= 0.001) return skyColor;

    float h = max(viewDir.y, 0.0);
    float lowerToMauve = smoothstep(0.015, 0.255, h);
    float mauveToBlue = smoothstep(0.285, 0.78, h);
    vec3 gradient = mix(SUNSET_GOLD, SUNSET_MAUVE, lowerToMauve);
    gradient = mix(gradient, SUNSET_BLUE, mauveToBlue);

    // More color in the lower atmosphere, less replacement at the zenith; the two smoothstep
    // ranges intentionally overlap to avoid a visible boundary between mauve and turquoise-blue.
    float horizonWeight = 1.0 - smoothstep(0.03, 0.52, h);
    float zenithWeight = smoothstep(0.22, 0.82, h);
    float paletteWeight = SUNSET_STRENGTH * sunsetWindow * (0.30 + 0.18 * horizonWeight + 0.04 * zenithWeight);
    skyColor = mix(skyColor, gradient, clamp(paletteWeight, 0.0, 0.72));

    // Solar halo is based on angular distance, not screen coordinates, so it follows the sun
    // and can be reflected by the Sky Probe. Keep the wide aureole restrained; the narrow core
    // supplies the bright golden hotspot that bloom can pick up if the renderer enables it.
    float sunDot = clamp(dot(normalize(viewDir), normalize(sunDir)), 0.0, 1.0);
    float angularDistance = 1.0 - sunDot;
    float broadHalo = exp(-angularDistance * 115.0);
    float innerHalo = exp(-angularDistance * 520.0);
    float solarCore = exp(-angularDistance * 2400.0);
    float horizonGate = 1.0 - smoothstep(0.035, 0.30, h);
    vec3 glow = SUNSET_GOLD * sunsetWindow * horizonGate
              * (0.14 * broadHalo + 0.26 * innerHalo + 0.72 * solarCore);
    return skyColor + glow;
}

#endif
