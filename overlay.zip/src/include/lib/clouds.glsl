#ifndef CLOUDS_INCLUDED
#define CLOUDS_INCLUDED

// Mirai Revamped — Fotorrealista cloud field.
// Static world-space clouds. The main volume is deliberately broken into
// isolated masses; it is not a continuous overcast sheet.
#define CIRRUS_HEIGHT 610.0
#define MR_CLOUD_BASE_HEIGHT 175.0
#define MR_CLOUD_TOP_HEIGHT 440.0
#define MR_CLOUD_RAY_STEPS 12

#include "common.glsl"
#include "noises.glsl"

// 2-D Worley F1 + distance between the closest and second-closest feature.
// F1 shapes rounded cloud lobes; the border distance gives a restrained edge
// breakup without outlining every cell with a visible honeycomb pattern.
float mrCloudWorley(vec2 p, out float borderDistance) {
    vec2 cell = floor(p);
    vec2 local = fract(p);
    float first = 10.0;
    float second = 10.0;

    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec2 grid = vec2(float(x), float(y));
            vec2 id = cell + grid;
            vec2 feature = vec2(
                rand(id + vec2(17.17, 41.73)),
                rand(id + vec2(63.31, 11.19))
            );
            feature = 0.12 + feature * 0.76;
            vec2 delta = grid + feature - local;
            float d2 = dot(delta, delta);
            if (d2 < first) {
                second = first;
                first = d2;
            } else if (d2 < second) {
                second = d2;
            }
        }
    }

    float f1 = sqrt(first);
    borderDistance = sqrt(second) - f1;
    return f1;
}

// Shared sparse cloud-shape field. A low-frequency regional value raises or
// lowers the coverage threshold over hundreds of blocks, so gaps form broad
// clear-sky windows instead of one globally continuous cloud blanket.
float mrCloudShape(vec2 worldXZ, float scale, float threshold, float seed, float rain,
    out float macroNoise, out float bodyNoise, out float regional) {
    vec2 p = worldXZ;
    float warpX = valueNoise(p * (scale * 0.27) + vec2(13.7 + seed, 4.1));
    float warpZ = valueNoise(p * (scale * 0.27) + vec2(31.2, 19.4 + seed));
    vec2 uv = p * scale + (vec2(warpX, warpZ) - 0.5) * 0.34;

    macroNoise = valueNoise(uv * 0.48 + vec2(seed, 7.3));
    bodyNoise = valueNoise(uv * 1.22 + vec2(17.4, seed * 0.71));
    regional = valueNoise(p * 0.00082 + vec2(47.0 + seed, 23.0));
    float localThreshold = threshold + (regional - 0.5) * 0.22 - rain * 0.045;

    float broadShape = macroNoise * 0.64 + bodyNoise * 0.36;

    // Early-out before fine noise and the 3x3 cellular evaluation when the
    // broad field is clearly empty. Most ray samples should remain cheap sky.
    float preMask = smoothstep(localThreshold - 0.15, localThreshold + 0.015, broadShape);
    if (preMask < 0.012) return 0.0;

    float detailNoise = valueNoise(uv * 2.65 + vec2(seed * 1.7, 29.1));
    float borderDistance;
    float cellDistance = mrCloudWorley(uv * 2.45 + vec2(9.3, 21.7), borderDistance);
    float roundedLobe = 1.0 - smoothstep(0.12, 0.78, cellDistance);
    float edgeErosion = (1.0 - smoothstep(0.018, 0.16, borderDistance)) * 0.055;
    float shape = broadShape * 0.78 + roundedLobe * 0.22;
    shape -= edgeErosion + (1.0 - detailNoise) * 0.018;

    return smoothstep(localThreshold - 0.045, localThreshold + 0.105, shape);
}

// Approximate density for a short light-space tap. It intentionally uses only
// cheap value noise; the full Worley field is reserved for camera ray samples.
float mrCloudCoarseDensity(vec3 p, float rain) {
    float lowH = (p.y - 175.0) / 135.0;
    float midH = (p.y - 290.0) / 150.0;
    float density = 0.0;

    if (lowH > 0.0 && lowH < 1.0) {
        vec2 uv = p.xz * 0.0048;
        float broad = valueNoise(uv * 0.55);
        float body = valueNoise(uv * 1.35);
        float region = valueNoise(p.xz * 0.00082 + vec2(48.0, 24.0));
        float threshold = 0.54 + (region - 0.5) * 0.22 - rain * 0.045;
        float mask = smoothstep(threshold - 0.10, threshold + 0.10,
            broad * 0.63 + body * 0.37);
        float topNoise = broad;
        float top = mix(0.48, 0.98, topNoise);
        float vertical = smoothstep(0.0, 0.045, lowH)
            * (1.0 - smoothstep(top - 0.10, top + 0.025, lowH));
        density = max(density, mask * vertical * 0.82);
    }

    if (midH > 0.0 && midH < 1.0) {
        vec2 uv = p.xz * 0.0087;
        float broad = valueNoise(uv * 0.62 + vec2(6.0, 2.0));
        float body = valueNoise(uv * 1.55 + vec2(19.0, 11.0));
        float region = valueNoise(p.xz * 0.0010 + vec2(11.0, 67.0));
        float threshold = 0.59 + (region - 0.5) * 0.20 - rain * 0.04;
        float mask = smoothstep(threshold - 0.10, threshold + 0.10,
            broad * 0.58 + body * 0.42);
        float vertical = smoothstep(0.0, 0.13, midH)
            * (1.0 - smoothstep(0.74, 0.98, midH));
        density = max(density, mask * vertical * 0.50);
    }

    return clamp(density, 0.0, 1.0);
}

// Two separate cloud families share a single ray march: low cumulus with a
// flatter base and variable cauliflower tops, plus smaller, broken mid-level
// altocumulus. Each family has its own horizontal scale and weather pattern.
float mrCloudDensity(vec3 p, float rain) {
    float density = 0.0;

    float lowH = (p.y - 175.0) / 135.0;
    if (lowH > 0.0 && lowH < 1.0) {
        float macroNoise, bodyNoise, regional;
        float shape = mrCloudShape(p.xz, 0.0048, 0.535, 2.0, rain,
            macroNoise, bodyNoise, regional);
        float top = mix(0.48, 0.985, macroNoise);
        float slightBaseWarp = (regional - 0.5) * 0.018;
        float height = lowH - slightBaseWarp;
        float vertical = smoothstep(0.0, 0.045, height)
            * (1.0 - smoothstep(top - 0.105, top + 0.025, height));

        // Reuse body noise to shape the crown without another noise octave.
        vertical *= mix(0.84, 1.0, bodyNoise);
        density = max(density, shape * vertical * 0.96);
    }

    float midH = (p.y - 290.0) / 150.0;
    if (midH > 0.0 && midH < 1.0) {
        float macroNoise, bodyNoise, regional;
        float shape = mrCloudShape(p.xz, 0.0087, 0.585, 19.0, rain,
            macroNoise, bodyNoise, regional);
        float vertical = smoothstep(0.0, 0.12, midH)
            * (1.0 - smoothstep(0.73, 0.98, midH));
        // Mid-level clouds are less opaque and more fragmented than cumulus.
        density = max(density, shape * vertical * 0.48);
    }

    return clamp(density, 0.0, 1.0);
}

float mrCloudLightTransmission(vec3 p, vec3 lightDir, float density, float rain) {
    // One inexpensive sun-direction tap plus local optical depth approximates
    // internal AO and soft self-shadowing without a second full ray march.
    float shadowDensity = mrCloudCoarseDensity(p + lightDir * 34.0, rain);
    return exp(-(shadowDensity * 1.55 + density * 0.48));
}

void applyProceduralCloudLayer(
    inout vec3 outColor,
    vec3 worldDir,
    vec3 rayOrigin,
    vec3 lightDir,
    vec3 cloudColor,
    float rain
) {
    float absDirY = abs(worldDir.y);
    if (absDirY < 0.018) return;

    float tBase = (MR_CLOUD_BASE_HEIGHT - rayOrigin.y) / worldDir.y;
    float tTop = (MR_CLOUD_TOP_HEIGHT - rayOrigin.y) / worldDir.y;
    float tStart = max(min(tBase, tTop), 0.0);
    float tEnd = max(tBase, tTop);
    if (tEnd <= tStart || tEnd <= 0.0) return;

    // Bound near-horizon work. Twelve samples are distributed across this
    // segment; a density-first early-out keeps the expensive shape field sparse.
    tEnd = min(tEnd, tStart + 820.0);
    float segmentLength = tEnd - tStart;
    if (segmentLength <= 0.0) return;

    float rainAmount = clamp(rain, 0.0, 1.0);
    float horizonFade = smoothstep(0.018, 0.085, absDirY);
    float stepLength = segmentLength / float(MR_CLOUD_RAY_STEPS);
    float coverageScale = mix(1.0, 0.84, rainAmount);

    vec3 accumulatedLight = vec3(0.0);
    float accumulatedOpacity = 0.0;
    float sunElevation = smoothstep(-0.10, 0.58, lightDir.y);

    for (int i = 0; i < MR_CLOUD_RAY_STEPS; i++) {
        if (accumulatedOpacity > 0.955) break;

        float t = tStart + (float(i) + 0.5) * stepLength;
        vec3 samplePos = rayOrigin + worldDir * t;
        float density = mrCloudDensity(samplePos, rainAmount);
        if (density <= 0.008) continue;
        density *= coverageScale;

        float lightTransmission = mrCloudLightTransmission(samplePos, lightDir, density, rainAmount);
        float directLight = clamp(lightTransmission * (0.26 + 0.74 * sunElevation), 0.0, 1.0);

        // Beer-Lambert extinction integrated front-to-back. Slightly lower
        // extinction preserves internal form at mobile resolution.
        float opticalDepth = min(density * stepLength * 0.022, 1.25);
        float sampleOpacity = (1.0 - exp(-opticalDepth)) * horizonFade;
        if (sampleOpacity <= 0.001) continue;

        vec3 ambientCloud = max(outColor * 0.38, vec3(0.042, 0.050, 0.064));
        vec3 sunCloud = cloudColor * (0.72 + 0.28 * sunElevation);
        vec3 sampleLight = mix(ambientCloud, sunCloud, 0.22 + 0.72 * directLight);

        // Broad, restrained silver lining when looking toward the light source.
        float forwardScatter = pow(max(dot(worldDir, lightDir), 0.0), 12.0) * 0.11;
        sampleLight += cloudColor * forwardScatter * directLight;

        accumulatedLight += (1.0 - accumulatedOpacity) * sampleOpacity * sampleLight;
        accumulatedOpacity += (1.0 - accumulatedOpacity) * sampleOpacity;
    }

    outColor = outColor * (1.0 - accumulatedOpacity) + accumulatedLight;
}

// Thin high-altitude cirrus are kept as a separate veil, but deliberately
// sparse and non-directionally-stretched so they do not become a global sheet.
float calcCirrusModel(vec2 pos, float time) {
    vec2 p = pos * vec2(0.62, 1.18);
    float warpA = valueNoise(p * 0.22 + vec2(13.0, 5.0));
    float warpB = valueNoise(p * 0.22 + vec2(29.0, 17.0));
    p += (vec2(warpA, warpB) - 0.5) * 0.28;

    float broad = valueNoise(p * 0.62);
    float strands = valueNoise(p * 1.42 + vec2(7.0, 23.0));
    float fine = valueNoise(p * 3.25 + vec2(29.0, 11.0));
    float shape = broad * 0.52 + strands * 0.34 + fine * 0.14;
    float coverage = valueNoise(p * 0.19 + vec2(61.0, 9.0));
    float threshold = 0.655 + (coverage - 0.5) * 0.12;
    float wisps = smoothstep(threshold, threshold + 0.13, shape);
    return wisps * 0.12;
}

void applyCirrusClouds(
    inout vec3 outColor,
    vec3 worldDir,
    vec3 rayOrigin,
    vec3 lightDir,
    vec3 cloudColor,
    float time,
    bool isTerrain
) {
    if (isTerrain) return;

    if (abs(worldDir.y) > 0.0001) {
        float tPlane = (CIRRUS_HEIGHT - rayOrigin.y) / worldDir.y;
        bool crossesPlane = tPlane >= 0.0
            && !(worldDir.y < 0.0 && rayOrigin.y < CIRRUS_HEIGHT)
            && !(worldDir.y > 0.0 && rayOrigin.y > CIRRUS_HEIGHT);

        if (crossesPlane) {
            vec3 samplePos = rayOrigin + worldDir * tPlane;
            float altFade = smoothstep(0.0, 180.0, CIRRUS_HEIGHT - rayOrigin.y);
            float horizonFade = smoothstep(0.008, 0.085, abs(worldDir.y));
            float extinction = calcCirrusModel(samplePos.xz * 0.0025, time)
                * altFade * horizonFade;
            float transmittance = exp(-extinction);
            float costh = dot(worldDir, lightDir);
            float cirrusPhase = phase(costh, 0.1, 1.0);
            outColor = outColor * transmittance
                + cloudColor * cirrusPhase * (1.0 - transmittance);
        }
    }

    applyProceduralCloudLayer(outColor, worldDir, rayOrigin, lightDir,
        cloudColor, SunColor.r);
}

#endif
