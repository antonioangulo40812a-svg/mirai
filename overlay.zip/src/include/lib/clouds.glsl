#ifndef CLOUDS_INCLUDED
#define CLOUDS_INCLUDED

// Mirai 2.1.1 volumetric cloud model ported to Mirai 3.1.x.
// Keep the original cloud-layer geometry, FBM profile, raymarch integration,
// direct-scattering model, powder effect and cirrus field as close as possible.
// The old precomputed Worley atlas is unavailable in the current shader source,
// so its 3-D Worley lookup is reproduced procedurally below.

#include "common.glsl"
#include "noises.glsl"

#define CLOUD_HEIGHT 180.0
#define CLOUD_THICKNESS 200.0
#define CLOUD_VOLUME_MAX_STEP_COUNTS 200
#define CLOUD_VOLUME_STEP_SPACE 10.0
#define CIRRUS_HEIGHT (CLOUD_HEIGHT + CLOUD_THICKNESS + 200.0)
#define CLOUD_SHADOW_CONTRIBUTION 0.8

float mrSaturate(float x) { return clamp(x, 0.0, 1.0); }
float mrPow5(float x) { float x2 = x * x; return x2 * x2 * x; }
float mrPow8(float x) { float x2 = x * x; float x4 = x2 * x2; return x4 * x4; }

float mrHash3(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}

float mrValueNoise3D(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n000 = mrHash3(i + vec3(0.0,0.0,0.0));
    float n100 = mrHash3(i + vec3(1.0,0.0,0.0));
    float n010 = mrHash3(i + vec3(0.0,1.0,0.0));
    float n110 = mrHash3(i + vec3(1.0,1.0,0.0));
    float n001 = mrHash3(i + vec3(0.0,0.0,1.0));
    float n101 = mrHash3(i + vec3(1.0,0.0,1.0));
    float n011 = mrHash3(i + vec3(0.0,1.0,1.0));
    float n111 = mrHash3(i + vec3(1.0,1.0,1.0));
    float z0 = mix(mix(n000,n100,f.x), mix(n010,n110,f.x), f.y);
    float z1 = mix(mix(n001,n101,f.x), mix(n011,n111,f.x), f.y);
    return mix(z0,z1,f.z);
}

// Procedural approximation of Mirai 2.1.1's precomputed Worley atlas.
// Eight neighbouring feature points preserve the broken, cellular billows
// without the prohibitive cost of a 27-cell search on mobile GPUs.
float mrWorley3D(vec3 p) {
    vec3 cell = floor(p);
    vec3 f = fract(p);
    float nearest = 10.0;
    for (int z = 0; z < 2; z++) {
        for (int y = 0; y < 2; y++) {
            for (int x = 0; x < 2; x++) {
                vec3 g = vec3(float(x), float(y), float(z));
                vec3 feature = g + vec3(
                    mrHash3(cell + g + vec3(17.1, 3.7, 9.2)),
                    mrHash3(cell + g + vec3(5.3, 29.1, 13.4)),
                    mrHash3(cell + g + vec3(23.7, 11.8, 2.6))
                );
                vec3 delta = g + feature - g - f;
                nearest = min(nearest, dot(delta, delta));
            }
        }
    }
    return clamp(sqrt(nearest) * 0.95, 0.0, 1.0);
}

float mrLinearStep(float edge0, float edge1, float x) {
    return clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0);
}

float mrPhaseHG(float costh, float g) {
    float g2 = g * g;
    return (1.0 - g2) / (4.0 * PI * pow(max(1.0 + g2 - 2.0 * g * costh, 0.0001), 1.5));
}

struct CloudSetup {
    float tMin;
    float tMax;
    int stepCounts;
    bool isValidCloud;
};

CloudSetup calcCloudSetup(float direction, float camAltitude) {
    CloudSetup setup;
    setup.tMin = 0.0;
    setup.tMax = 1e6;
    setup.stepCounts = CLOUD_VOLUME_MAX_STEP_COUNTS;
    setup.isValidCloud = true;

    if (abs(direction) < 0.0001) {
        setup.isValidCloud = camAltitude >= CLOUD_HEIGHT
            && camAltitude <= CLOUD_HEIGHT + CLOUD_THICKNESS;
        setup.tMax = setup.isValidCloud ? 1e6 : 0.0;
        setup.stepCounts = setup.isValidCloud ? CLOUD_VOLUME_MAX_STEP_COUNTS : 0;
        return setup;
    }

    float cloudMaxY = CLOUD_HEIGHT + CLOUD_THICKNESS;
    float tBottomPlane = (CLOUD_HEIGHT - camAltitude) / direction;
    float tTopPlane = (cloudMaxY - camAltitude) / direction;

    if (camAltitude > cloudMaxY) {
        if (direction > 0.0) { setup.isValidCloud = false; return setup; }
        setup.tMin = tTopPlane;
        setup.tMax = tBottomPlane;
    } else if (camAltitude < CLOUD_HEIGHT) {
        if (direction < 0.0) { setup.isValidCloud = false; return setup; }
        setup.tMin = tBottomPlane;
        setup.tMax = tTopPlane;
    } else {
        setup.tMin = 0.0;
        setup.tMax = direction > 0.0 ? tTopPlane : tBottomPlane;
    }

    setup.tMin = max(setup.tMin, 0.0);
    setup.tMax = max(setup.tMax, setup.tMin);
    float raySpan = (setup.tMax - setup.tMin) / CLOUD_VOLUME_STEP_SPACE;
    setup.stepCounts = min(setup.stepCounts, max(int(raySpan), 0));
    return setup;
}

float calcCumulusModel(vec3 pos) {
    vec2 windDir = vec2(0.0, Time.x);
    vec2 basePos = (pos.xz + windDir) * 0.003;

    float base = valueNoise(basePos);
    base += valueNoise(basePos * 2.0) * 0.5;
    base += valueNoise(basePos * 4.0) * 0.25;
    base += valueNoise(basePos * 8.0) * 0.125;
    base = mrSaturate(base * 0.533333 - 0.25);

    float heightFraction = mrSaturate((pos.y - CLOUD_HEIGHT) / CLOUD_THICKNESS);
    base = mrLinearStep(mrPow8(heightFraction), 1.0, base);
    base = mrLinearStep(exp(-heightFraction * 25.0), 1.0, base);

    float wsculpting = mrWorley3D(pos * 0.15 + windDir.xxy * 0.05);
    base = mrLinearStep(wsculpting * heightFraction, 1.0, base);
    return base;
}

float calcDirectScattering(vec3 samplePos, vec3 lightDir, float extinction, float costh) {
    float shadow = 0.0;
    float stepSpace = CLOUD_THICKNESS / max(lightDir.y, 0.01) * 0.25;
    stepSpace = min(stepSpace, CLOUD_THICKNESS);

    for (int i = 0; i < 4; i++) {
        samplePos += lightDir * stepSpace * 0.1;
        shadow += calcCumulusModel(samplePos);
    }

    float lighting = 0.0;
    float lMod = mrSaturate(lightDir.y);
    float g = 1.0;
    float b = 1.0 + lMod * 0.5;
    float a = 1.0;

    for (int j = 0; j < 4; j++) {
        float fphase = mrPhaseHG(costh, 0.7 * g);
        float bphase = mrPhaseHG(costh, -0.1 * g);
        float dphase = mix(fphase, bphase, 0.4);
        lighting += b * dphase * exp(-shadow * stepSpace * a);
        a *= 0.25 + lMod * 0.15;
        g *= 0.5;
        b *= 0.75;
    }

    float powder = 1.0 - exp(-extinction * CLOUD_VOLUME_STEP_SPACE * 3.0);
    lighting *= mix(mrPow5(powder) * 5.0, 1.0, costh * 0.5 + 0.5);
    return lighting;
}

vec3 calcCloud(vec3 worldDir, vec3 lightDir, float worldDist, float dither, bool isTerrain, CloudSetup setup) {
    if (!setup.isValidCloud) return vec3(0.0, 0.0, 1.0);

    vec3 rayOrigin = -WorldOrigin.xyz;
    vec3 rayDir = worldDir;
    float costh = dot(worldDir, lightDir);
    float lighting = 0.0;
    float wdepth = 0.0;
    float tweight = 0.0;
    float transmittance = 1.0;

    if (isTerrain) setup.tMax = min(setup.tMax, worldDist);

    for (int i = 0; i < setup.stepCounts; i++) {
        vec3 samplePos = rayOrigin + rayDir * (setup.tMin + dither * CLOUD_VOLUME_STEP_SPACE);
        float extinction = calcCumulusModel(samplePos);

        if (extinction > 0.0) {
            float dscattering = calcDirectScattering(samplePos, lightDir, extinction, costh) * extinction;
            float stepTransmittance = exp(-extinction * CLOUD_VOLUME_STEP_SPACE);
            float scatterInt = (dscattering - dscattering * stepTransmittance) / max(extinction, EPSILON);
            lighting += transmittance * scatterInt;
            wdepth += transmittance * setup.tMin;
            tweight += transmittance;
            transmittance *= stepTransmittance;
        }

        if (transmittance < EPSILON) break;
        setup.tMin += CLOUD_VOLUME_STEP_SPACE;
        if (setup.tMin > setup.tMax) break;
    }

    if (tweight > EPSILON) wdepth /= tweight;
    return vec3(lighting, wdepth, transmittance);
}

float calcCloudTransmittanceOnly(vec3 worldDir, float worldDist, float dither, bool isTerrain, CloudSetup setup) {
    if (!setup.isValidCloud) return 1.0;
    vec3 rayOrigin = -WorldOrigin.xyz;
    if (isTerrain) setup.tMax = min(setup.tMax, worldDist);
    float transmittance = 1.0;

    for (int i = 0; i < setup.stepCounts; i++) {
        vec3 samplePos = rayOrigin + worldDir * (setup.tMin + dither * CLOUD_VOLUME_STEP_SPACE);
        float extinction = calcCumulusModel(samplePos);
        if (extinction > 0.0) transmittance *= exp(-extinction * CLOUD_VOLUME_STEP_SPACE);
        if (transmittance < EPSILON) break;
        setup.tMin += CLOUD_VOLUME_STEP_SPACE;
        if (setup.tMin > setup.tMax) break;
    }
    return transmittance;
}

float calcCloudShadow(vec3 position, vec3 lightDir, float hardness, CloudSetup setup) {
    if (!setup.isValidCloud) return 1.0;
    float transmittance = 1.0;
    for (int i = 0; i < setup.stepCounts; i++) {
        vec3 samplePos = position + setup.tMin * lightDir;
        float extinction = calcCumulusModel(samplePos);
        if (extinction > 0.0) transmittance *= exp(-extinction * CLOUD_VOLUME_STEP_SPACE * hardness);
        if (transmittance < EPSILON) break;
        setup.tMin += CLOUD_VOLUME_STEP_SPACE;
        if (setup.tMin > setup.tMax) break;
    }
    return transmittance;
}

// Original Mirai 2.1.1 high cirrus field.
float calcCirrusModel(vec2 pos) {
    float tdensity = 0.0;
    float amplitude = 1.0;
    pos.y *= 0.3;
    pos.y += Time.x * 0.001;
    pos.x += sin(pos.y * 3.0) * 0.2;

    for (int i = 0; i < 4; i++) {
        float dens = valueNoise(pos) * amplitude;
        tdensity += dens;
        pos *= 3.0;
        pos.y += dens * pos.y * 0.2 + Time.x * 0.005;
        amplitude *= 0.5;
    }
    return mrSaturate(tdensity * 0.533333 - 0.2);
}

void applyMiraiLegacyClouds(inout vec3 outColor, vec3 worldDir, float worldDist, vec3 cloudColor, bool isTerrain) {
    float camAltitude = -WorldOrigin.y;
    float dirY = worldDir.y;

    // Keep the old high-altitude cirrus layer.
    if (abs(dirY) > 0.0001) {
        float tPlane = (CIRRUS_HEIGHT - camAltitude) / dirY;
        if (tPlane >= 0.0 && !((dirY < 0.0 && camAltitude < CIRRUS_HEIGHT)
            || (dirY > 0.0 && camAltitude > CIRRUS_HEIGHT))) {
            vec3 rayOrigin = -WorldOrigin.xyz;
            vec3 samplePos = rayOrigin + worldDir * tPlane;
            float extinction = isTerrain ? 0.0 : calcCirrusModel(samplePos.xz * 0.005);
            extinction *= smoothstep(0.0, 0.4, dirY);
            extinction *= smoothstep(0.0, 180.0, CIRRUS_HEIGHT - camAltitude);
            float transmittance = exp(-extinction);
            float costh = dot(worldDir, DirectionalLightSourceWorldSpaceDirection.xyz);
            float phaseR = phase(costh, 0.0, 1.0);
            outColor = outColor * transmittance + cloudColor * phaseR * (1.0 - transmittance);
        }
    }

    // Same 200-step volume march and 4-sample self-shadowing as Mirai 2.1.1.
    float dither = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
    CloudSetup cloudSetup = calcCloudSetup(worldDir.y, camAltitude);
    vec3 clouds = calcCloud(worldDir, DirectionalLightSourceWorldSpaceDirection.xyz,
        worldDist, dither, isTerrain, cloudSetup);

    // Port the original volume/transmittance blend. The old GetAtmosphere API
    // no longer exists in 3.1.x, so current sky radiance supplies the in-cloud
    // atmospheric contribution while preserving the old scattering integral.
    if (MoonDir.y > 0.0) clouds.r *= 0.8;
    vec3 cloudsColor = clouds.r * cloudColor;
    cloudsColor += outColor * (1.0 - clouds.b) * 0.18;
    outColor = clouds.b * outColor + cloudsColor;
}

#endif
