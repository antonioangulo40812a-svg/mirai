#ifndef CLOUDS_INCLUDED
#define CLOUDS_INCLUDED

// Mirai Revamped - procedural cloud layer.
// The original high-altitude cirrus layer is retained, but frozen in place.
// Procedural clouds use world-space coordinates and have no time-dependent motion.
#define CIRRUS_HEIGHT 580.0
#define MR_CLOUD_BASE_HEIGHT 204.0
#define MR_CLOUD_TOP_HEIGHT 278.0
#define MR_CLOUD_RAY_STEPS 6
#define MR_CLOUD_BASE_SCALE 0.0092

#include "common.glsl"
#include "noises.glsl"

// 2D Worley F1 and distance-to-cell-border.  The border term erodes cloud
// edges without hollowing out every cellular feature.
float mrCloudWorley(vec2 p, out float borderDistance) {
    vec2 cell = floor(p);
    vec2 local = fract(p);
    float first = 10.0;
    float second = 10.0;

    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec2 grid = vec2(float(x), float(y));
            vec2 id = cell + grid;
            vec2 feature = vec2(
                rand(id + vec2(17.17, 41.73)),
                rand(id + vec2(63.31, 11.19))
            );
            // Keep feature points away from perfect cell corners.
            feature = 0.12 + feature * 0.76;
            vec2 delta = grid + feature - local;
            float d2 = dot(delta, delta);
            if (d2 < first) {
                second = first;
                first = d2;
            } else if (d2 < second) {
                second = d2;
            }
        }
    }

    float f1 = sqrt(first);
    borderDistance = sqrt(second) - f1;
    return f1;
}

// A cheaper broad density field is used for the two short light-occlusion
// taps. It deliberately avoids Worley and fine-octave noise.
float mrCloudCoarseDensity(vec3 p, float coverage) {
    float rawHeight = (p.y - MR_CLOUD_BASE_HEIGHT)
        / (MR_CLOUD_TOP_HEIGHT - MR_CLOUD_BASE_HEIGHT);
    if (rawHeight <= 0.0 || rawHeight >= 1.0) return 0.0;

    float h = clamp(rawHeight, 0.0, 1.0);
    vec2 uv = p.xz * MR_CLOUD_BASE_SCALE + vec2(h * 0.38, -h * 0.29);
    float broad = valueNoise(uv * 0.42);
    float middle = valueNoise(uv * 1.10);
    float mask = smoothstep(coverage - 0.10, coverage + 0.13,
        broad * 0.62 + middle * 0.38);
    float vertical = smoothstep(0.0, 0.12, h)
        * (1.0 - smoothstep(0.78, 0.97, h));
    return mask * vertical;
}

// Multi-scale density: broad coverage, rounded medium lobes, fine breakup,
// Worley edge erosion and a height-varying horizontal slice give the volume
// different cross-sections at the base and top.
float mrCloudDensity(vec3 p, float coverage) {
    float rawHeight = (p.y - MR_CLOUD_BASE_HEIGHT)
        / (MR_CLOUD_TOP_HEIGHT - MR_CLOUD_BASE_HEIGHT);
    if (rawHeight <= 0.0 || rawHeight >= 1.0) return 0.0;

    float h = clamp(rawHeight, 0.0, 1.0);
    float region = valueNoise(p.xz * 0.0021 + vec2(37.2, 19.5));
    float sizeScale = mix(0.78, 1.26, region);
    vec2 uv = p.xz * (MR_CLOUD_BASE_SCALE * sizeScale)
        + vec2(h * 0.38, -h * 0.29);

    float broad = valueNoise(uv * 0.30);
    float middle = valueNoise(uv * 0.92);
    float detail = valueNoise(uv * 2.15);
    float micro = valueNoise(uv * 4.65);

    float borderDistance;
    float cell = mrCloudWorley(uv * 2.25 + vec2(11.7, 29.3), borderDistance);
    float edgeErosion = (1.0 - smoothstep(0.035, 0.22, borderDistance)) * 0.065;
    float cellularShape = (cell - 0.42) * 0.035;

    float shape = broad * 0.40 + middle * 0.31
        + detail * 0.20 + micro * 0.09;
    shape += cellularShape;
    shape -= edgeErosion + (1.0 - micro) * 0.018;

    float cloudMask = smoothstep(coverage - 0.105, coverage + 0.115, shape);

    // Spatially varying profile: shorter, layered stratocumulus in some
    // regions and more billowy, rounded cumulus in others.
    float capHeight = 0.48 + 0.34 * (middle * 0.62 + detail * 0.38);
    float cumulusProfile = smoothstep(0.0, 0.115, h)
        * (1.0 - smoothstep(capHeight, min(capHeight + 0.22, 1.0), h));
    float stratusProfile = smoothstep(0.0, 0.075, h)
        * (1.0 - smoothstep(0.83, 0.99, h));
    float altocumulusProfile = smoothstep(0.0, 0.09, h)
        * (1.0 - smoothstep(0.62, 0.81, h));
    float stratocumulusWeight = smoothstep(0.60, 0.80, region) * 0.68;
    float altocumulusWeight = (1.0 - smoothstep(0.18, 0.38, region)) * 0.42;
    float profile = mix(cumulusProfile, stratusProfile, stratocumulusWeight);
    profile = mix(profile, altocumulusProfile, altocumulusWeight);

    return clamp(cloudMask * profile, 0.0, 1.0);
}

float mrCloudLightTransmission(vec3 p, vec3 lightDir, float coverage, float density) {
    // One coarse light-space tap plus local optical depth approximates internal
    // AO/self-shadowing while keeping the mobile cost bounded.
    float shadowDensity = mrCloudCoarseDensity(p + lightDir * 27.0, coverage);
    return exp(-(shadowDensity * 1.05 + density * 0.38));
}

void applyProceduralCloudLayer(
    inout vec3 outColor,
    vec3 worldDir,
    vec3 rayOrigin,
    vec3 lightDir,
    vec3 cloudColor,
    float rain
) {
    // Avoid unstable divisions at the exact horizon. Opacity fades in across
    // low angles so the cloud layer transitions naturally into the atmosphere.
    float absDirY = abs(worldDir.y);
    if (absDirY < 0.025) return;

    float tBase = (MR_CLOUD_BASE_HEIGHT - rayOrigin.y) / worldDir.y;
    float tTop = (MR_CLOUD_TOP_HEIGHT - rayOrigin.y) / worldDir.y;
    float tStart = max(min(tBase, tTop), 0.0);
    float tEnd = max(tBase, tTop);
    if (tEnd <= tStart || tEnd <= 0.0) return;

    // Limit the ray segment on near-horizon views to keep sample spacing and
    // mobile GPU cost under control; the nearby section dominates visibility.
    tEnd = min(tEnd, tStart + 900.0);
    float segmentLength = tEnd - tStart;
    if (segmentLength <= 0.0) return;

    float rainAmount = clamp(rain, 0.0, 1.0);
    // Clear weather leaves broad blue gaps; rainy weather increases coverage
    // but does not generate giant storm towers.
    float coverage = mix(0.655, 0.505, rainAmount);
    float horizonFade = smoothstep(0.025, 0.105, absDirY);
    float stepLength = segmentLength / float(MR_CLOUD_RAY_STEPS);

    vec3 accumulatedLight = vec3(0.0);
    float accumulatedOpacity = 0.0;

    for (int i = 0; i < MR_CLOUD_RAY_STEPS; i++) {
        if (accumulatedOpacity > 0.965) break;

        float t = tStart + (float(i) + 0.5) * stepLength;
        vec3 samplePos = rayOrigin + worldDir * t;
        float density = mrCloudDensity(samplePos, coverage);
        if (density <= 0.008) continue;

        float lightTransmission = mrCloudLightTransmission(samplePos, lightDir, coverage, density);
        float sunElevation = smoothstep(-0.12, 0.62, lightDir.y);
        float directLight = clamp(lightTransmission * (0.30 + 0.70 * sunElevation), 0.0, 1.0);

        // Beer-Lambert extinction, integrated front-to-back.
        float opticalDepth = min(density * stepLength * 0.034, 1.8);
        float sampleOpacity = (1.0 - exp(-opticalDepth)) * horizonFade;
        if (sampleOpacity <= 0.001) continue;

        vec3 ambientCloud = max(outColor * 0.34, vec3(0.032, 0.038, 0.048));
        vec3 directCloud = cloudColor * (0.54 + 0.46 * max(lightDir.y, 0.0));
        vec3 sampleLight = mix(ambientCloud, directCloud, 0.28 + 0.72 * directLight);

        // A restrained forward-scattering lobe gives sunlight a luminous edge
        // without painting a hard, artificial outline around every cloud.
        float forwardScatter = pow(max(dot(worldDir, lightDir), 0.0), 10.0) * 0.16;
        sampleLight += cloudColor * forwardScatter * directLight;

        accumulatedLight += (1.0 - accumulatedOpacity) * sampleOpacity * sampleLight;
        accumulatedOpacity += (1.0 - accumulatedOpacity) * sampleOpacity;
    }

    outColor = outColor * (1.0 - accumulatedOpacity) + accumulatedLight;
}

float calcCirrusModel(vec2 pos, float time) {
    float tdensity = 0.0;
    float amplitude = 0.2;

    // Keep Mirai's existing high-altitude cirrus layer, but make it static.
    pos.x += sin(pos.y * 2.0) * 0.1;

    for (int i = 0; i < 4; i++) {
        float dens = valueNoise(pos) * amplitude;
        tdensity += dens;
        pos *= 2.0;
        pos.x += pos.x * 0.5;
        amplitude *= 0.5;
    }

    return clamp(tdensity - 0.15, 0.0, 1.0);
}

void applyCirrusClouds(
    inout vec3 outColor,
    vec3 worldDir,
    vec3 rayOrigin,
    vec3 lightDir,
    vec3 cloudColor,
    float time,
    bool isTerrain
) {
    if (isTerrain) return;

    // High-altitude cirrus remain a separate, thin layer behind the new lower
    // procedural volume. This also keeps the existing Mirai look available.
    if (abs(worldDir.y) > 0.0001) {
        float tPlane = (CIRRUS_HEIGHT - rayOrigin.y) / worldDir.y;
        bool crossesPlane = tPlane >= 0.0
            && !(worldDir.y < 0.0 && rayOrigin.y < CIRRUS_HEIGHT)
            && !(worldDir.y > 0.0 && rayOrigin.y > CIRRUS_HEIGHT);

        if (crossesPlane) {
            vec3 samplePos = rayOrigin + worldDir * tPlane;
            float distFade = smoothstep(0.0, 0.2, worldDir.y);
            float altFade = smoothstep(0.0, 180.0, CIRRUS_HEIGHT - rayOrigin.y);
            float extinction = calcCirrusModel(samplePos.xz * 0.0025, time)
                * distFade * altFade;
            float transmittance = exp(-extinction);
            float costh = dot(worldDir, lightDir);
            float cirrusPhase = phase(costh, 0.1, 1.0);
            outColor = outColor * transmittance
                + cloudColor * cirrusPhase * (1.0 - transmittance);
        }
    }

    // Procedural cumulus/stratocumulus are composited in front of cirrus.
    // SunColor.r is already used by Mirai as the atmospheric rain parameter.
    applyProceduralCloudLayer(outColor, worldDir, rayOrigin, lightDir,
        cloudColor, SunColor.r);
}

#endif
