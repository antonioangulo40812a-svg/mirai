#ifndef CLOUDS_INCLUDED
#define CLOUDS_INCLUDED

// Mirai Revamped — Fotorrealista v2.
// Static 3-D density field: no animated UVs, no stacked 2-D cloud sheets.
// Three-dimensional domain warping gives cloud lobes real depth and erosion.
#define MR_CLOUD_BASE_HEIGHT 175.0
#define MR_CLOUD_TOP_HEIGHT 445.0
#define MR_CLOUD_RAY_STEPS 16

#include "common.glsl"
#include "noises.glsl"

float mrHash3(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.yxz + 33.33);
    return fract((p.x + p.y) * p.z);
}

float mrValueNoise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n000 = mrHash3(i + vec3(0.0, 0.0, 0.0));
    float n100 = mrHash3(i + vec3(1.0, 0.0, 0.0));
    float n010 = mrHash3(i + vec3(0.0, 1.0, 0.0));
    float n110 = mrHash3(i + vec3(1.0, 1.0, 0.0));
    float n001 = mrHash3(i + vec3(0.0, 0.0, 1.0));
    float n101 = mrHash3(i + vec3(1.0, 0.0, 1.0));
    float n011 = mrHash3(i + vec3(0.0, 1.0, 1.0));
    float n111 = mrHash3(i + vec3(1.0, 1.0, 1.0));
    float z0 = mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y);
    float z1 = mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y);
    return mix(z0, z1, f.z);
}

// Low-frequency weather mask: large clear windows and separated cloud groups.
float mrWeatherCoverage(vec2 xz, float seed) {
    float a = valueNoise(xz * 0.00115 + vec2(seed + 3.1, 17.7));
    float b = valueNoise(xz * 0.00235 + vec2(29.4, seed + 8.2));
    return a * 0.72 + b * 0.28;
}

// Density is evaluated in XYZ. Vertical profile shapes the flat-ish cloud base,
// while 3-D noise forms bulging tops, cavities and broken edges in every direction.
float mrCumulusDensity(vec3 p, float rain) {
    float h = (p.y - MR_CLOUD_BASE_HEIGHT) / (MR_CLOUD_TOP_HEIGHT - MR_CLOUD_BASE_HEIGHT);
    if (h <= 0.0 || h >= 1.0) return 0.0;

    vec3 q = p * vec3(0.0105, 0.0082, 0.0105);
    vec3 warp = vec3(
        mrValueNoise3(q * 0.53 + vec3(13.2, 2.7, 5.1)),
        mrValueNoise3(q * 0.53 + vec3(4.8, 19.1, 11.3)),
        mrValueNoise3(q * 0.53 + vec3(21.7, 7.4, 16.2))
    );
    q += (warp - 0.5) * vec3(0.92, 0.46, 0.92);

    float weather = mrWeatherCoverage(p.xz, 2.0);
    float broad = mrValueNoise3(q * 0.78 + vec3(3.0, 9.0, 1.0));
    float body = mrValueNoise3(q * 1.65 + vec3(17.0, 4.0, 23.0));
    float detail = mrValueNoise3(q * 3.35 + vec3(29.0, 13.0, 7.0));
    float shape = broad * 0.54 + body * 0.34 + detail * 0.12;
    float threshold = mix(0.635, 0.565, rain) + (0.5 - weather) * 0.30;
    float cloud = smoothstep(threshold - 0.075, threshold + 0.075, shape);
    if (cloud < 0.008) return 0.0;

    // Individual cloud tops vary by position; the base remains relatively level.
    float topNoise = mrValueNoise3(q * 0.72 + vec3(39.0, 2.0, 31.0));
    float top = mix(0.54, 0.99, topNoise);
    float vertical = smoothstep(0.015, 0.115, h)
        * (1.0 - smoothstep(top - 0.13, top + 0.035, h));
    // More erosion near the silhouette, preserving a solid interior.
    float erosion = (1.0 - detail) * 0.075;
    cloud = smoothstep(threshold - 0.055 - erosion, threshold + 0.085, shape);
    return clamp(cloud * vertical * 1.18, 0.0, 1.0);
}

// Broken mid-level clouds, not a continuous horizontal stratus layer.
float mrAltocumulusDensity(vec3 p, float rain) {
    float h = (p.y - 305.0) / 115.0;
    if (h <= 0.0 || h >= 1.0) return 0.0;
    vec3 q = p * vec3(0.017, 0.013, 0.017) + vec3(8.1, 3.7, 19.3);
    float broad = mrValueNoise3(q * 0.72);
    float detail = mrValueNoise3(q * 1.9 + vec3(21.0, 11.0, 4.0));
    float coverage = mrWeatherCoverage(p.xz, 37.0);
    float shape = broad * 0.64 + detail * 0.36;
    float mask = smoothstep(0.675 + (0.5 - coverage) * 0.23 - rain * 0.045,
        0.79 + (0.5 - coverage) * 0.23, shape);
    float vertical = smoothstep(0.03, 0.20, h) * (1.0 - smoothstep(0.72, 0.99, h));
    return mask * vertical * 0.43;
}

float mrCloudDensity(vec3 p, float rain) {
    return clamp(max(mrCumulusDensity(p, rain), mrAltocumulusDensity(p, rain)), 0.0, 1.0);
}

// Cheap one-tap light-space estimate. Density remains fully 3-D for the view ray;
// this tap estimates soft self-shadowing without a second full march.
float mrCloudLightTransmission(vec3 p, vec3 lightDir, float density, float rain) {
    vec3 lightPoint = p + lightDir * 28.0;
    float broad = mrValueNoise3(lightPoint * vec3(0.0105, 0.0082, 0.0105));
    float shadow = smoothstep(0.43, 0.72, broad) * 0.72;
    return exp(-(shadow * 1.25 + density * 0.72));
}

void applyProceduralCloudLayer(
    inout vec3 outColor,
    vec3 worldDir,
    vec3 rayOrigin,
    vec3 lightDir,
    vec3 cloudColor,
    float rain
) {
    if (worldDir.y <= 0.012) return;

    float tBase = (MR_CLOUD_BASE_HEIGHT - rayOrigin.y) / worldDir.y;
    float tTop = (MR_CLOUD_TOP_HEIGHT - rayOrigin.y) / worldDir.y;
    float tStart = max(tBase, 0.0);
    float tEnd = max(tTop, 0.0);
    if (tEnd <= tStart) return;

    // Keep horizon rays bounded to avoid huge mobile GPU work.
    tEnd = min(tEnd, tStart + 1250.0);
    float segmentLength = tEnd - tStart;
    if (segmentLength <= 0.0) return;

    float stepLength = segmentLength / float(MR_CLOUD_RAY_STEPS);
    float opacity = 0.0;
    vec3 cloudRadiance = vec3(0.0);
    float sunElevation = smoothstep(-0.08, 0.55, lightDir.y);
    float rainAmount = clamp(rain, 0.0, 1.0);

    for (int i = 0; i < MR_CLOUD_RAY_STEPS; i++) {
        if (opacity > 0.965) break;
        float t = tStart + (float(i) + 0.5) * stepLength;
        vec3 p = rayOrigin + worldDir * t;
        float density = mrCloudDensity(p, rainAmount);
        if (density < 0.012) continue;

        float trans = mrCloudLightTransmission(p, lightDir, density, rainAmount);
        float direct = clamp(trans * (0.20 + 0.80 * sunElevation), 0.0, 1.0);
        // Step-length-aware Beer-Lambert extinction.
        float sampleAlpha = 1.0 - exp(-density * stepLength * 0.0105);
        sampleAlpha = clamp(sampleAlpha, 0.0, 0.82);
        vec3 ambient = max(outColor * 0.30, vec3(0.045, 0.054, 0.070));
        vec3 sunlit = cloudColor * (0.74 + 0.26 * sunElevation);
        vec3 lighting = mix(ambient, sunlit, 0.18 + 0.78 * direct);
        // Forward-scattering silver edge, restrained to prevent white blobs.
        float phaseForward = pow(max(dot(normalize(worldDir), normalize(lightDir)), 0.0), 10.0);
        lighting += cloudColor * phaseForward * direct * 0.075;

        cloudRadiance += (1.0 - opacity) * sampleAlpha * lighting;
        opacity += (1.0 - opacity) * sampleAlpha;
    }

    outColor = outColor * (1.0 - opacity) + cloudRadiance;
}

// Sparse, non-directional wisps. Their contribution is intentionally tiny so
// they never dominate the sky as a continuous striped veil.
float calcCirrusModel(vec2 pos, float time) {
    vec2 p = pos * 0.78;
    float broad = valueNoise(p * 0.34 + vec2(13.0, 5.0));
    float detail = valueNoise(p * 0.95 + vec2(29.0, 17.0));
    float mask = smoothstep(0.72, 0.88, broad * 0.72 + detail * 0.28);
    return mask * 0.025;
}

void applyCirrusClouds(
    inout vec3 outColor,
    vec3 worldDir,
    vec3 rayOrigin,
    vec3 lightDir,
    vec3 cloudColor,
    float time,
    bool isTerrain
) {
    if (isTerrain) return;
    // Preserve only a very faint high-altitude wisp field, then render the true
    // volumetric cloud bodies through a 3-D ray march.
    if (worldDir.y > 0.018) {
        float tPlane = (610.0 - rayOrigin.y) / worldDir.y;
        if (tPlane > 0.0) {
            vec3 samplePos = rayOrigin + worldDir * tPlane;
            float wisps = calcCirrusModel(samplePos.xz * 0.0025, 0.0);
            float alpha = clamp(wisps * smoothstep(0.018, 0.09, worldDir.y), 0.0, 0.035);
            outColor = mix(outColor, cloudColor * 0.92, alpha);
        }
    }
    applyProceduralCloudLayer(outColor, worldDir, rayOrigin, lightDir, cloudColor, SunColor.r);
}

#endif
