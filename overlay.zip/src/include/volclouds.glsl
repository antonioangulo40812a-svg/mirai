#ifndef MIRAI_VOLCLOUDS_INCLUDED
#define MIRAI_VOLCLOUDS_INCLUDED

// Procedural volumetric clouds (own implementation, no noise texture needed).
//
//  * Main layer: big cumulus with large gaps between them, plus a few small puffs so the sky
//    is not empty. 3D value-noise density, ray marched, lit by the sun with a short march
//    towards the light.
//  * Upper layer: sparse thin clouds during the day, transitioning into grouped,
//    smaller altocumulus toward sunset. It reuses the same short ray march.
//  * Sky state (VC_SKY_STATE): 0 = cumulus-dominant, 1 = thin-cloud-dominant.
//  * Evening: individual cloud regions flatten at different times; upper cloud groups
//    strengthen as corresponding low cumulus regions thin out.
//  * Rim lighting: forward scattering glow on cloud edges that grows near sunrise / sunset.
//
// Written without swizzles / inout on purpose, so it can also be compiled and previewed on a CPU.

float vcHash3(ivec3 p) {
    uint h = uint(p.x) * 374761393u + uint(p.y) * 668265263u + uint(p.z) * 2147483647u;
    h = (h ^ (h >> 13u)) * 1274126177u;
    h = h ^ (h >> 16u);
    return float(h & 16777215u) / 16777216.0;
}

float vcNoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = p - i;
    f = f * f * (3.0 - 2.0 * f);
    ivec3 ip = ivec3(i);
    float c000 = vcHash3(ip);
    float c100 = vcHash3(ip + ivec3(1, 0, 0));
    float c010 = vcHash3(ip + ivec3(0, 1, 0));
    float c110 = vcHash3(ip + ivec3(1, 1, 0));
    float c001 = vcHash3(ip + ivec3(0, 0, 1));
    float c101 = vcHash3(ip + ivec3(1, 0, 1));
    float c011 = vcHash3(ip + ivec3(0, 1, 1));
    float c111 = vcHash3(ip + ivec3(1, 1, 1));
    float x00 = mix(c000, c100, f.x);
    float x10 = mix(c010, c110, f.x);
    float x01 = mix(c001, c101, f.x);
    float x11 = mix(c011, c111, f.x);
    return mix(mix(x00, x10, f.y), mix(x01, x11, f.y), f.z);
}

// 2D slice of the 3D noise (used for the large scale cloud placement)
float vcNoise2(float x, float z) {
    return vcNoise(vec3(x, 0.37, z));
}

// detail scales the amplitude of every octave after the first one (1 = full detail)
float vcFbm(vec3 p, float detail) {
    float sum = 0.0;
    float amp = 0.5;
    float norm = 0.0;
    for (int i = 0; i < VC_OCTAVES; ++i) {
        float w = (i == 0) ? 1.0 : detail;
        sum += vcNoise(p) * amp * w;
        norm += amp * w;
        p = p * 2.03 + vec3(17.1, 9.3, 5.7);
        amp *= 0.5;
    }
    return sum / norm;
}

// ---------------------------------------------------------------- main (cumulus) layer
// decay : 0 = day, 1 = evening/night (clouds flatten)      cumW : 1 = cumulus sky, 0 = cirrus sky
float vcDensity(vec3 pos, float time, float decay, float cumW) {
    // All cumulus share one cloud-base altitude. Their tops vary through the
    // 3D density field, rather than by moving each cloud to a different layer.
    float wx = pos.x + time * VC_WIND;
    float wz = pos.z + time * VC_WIND * 0.35;

    // Sparse placement: one broad cell mask controls the main formations;
    // small secondary cells only add occasional satellite puffs.
    float cellBig = vcNoise2(wx * VC_CELL_SCALE, wz * VC_CELL_SCALE);
    float cellSmall = vcNoise2(wx * VC_CELL_SCALE * 2.65 + 31.7,
                               wz * VC_CELL_SCALE * 2.65 + 12.9);
    float bigMask = smoothstep(VC_CELL_THRESHOLD, VC_CELL_THRESHOLD + 0.16, cellBig);
    float smallMask = smoothstep(VC_SMALL_THRESHOLD, VC_SMALL_THRESHOLD + 0.12, cellSmall);
    float mask = max(bigMask, smallMask * 0.32);
    if (mask < 0.015) return 0.0;

    // A slow, spatially varying transition lets only some cumulus flatten first.
    float region = vcNoise2(wx * VC_REGION_SCALE + 9.0,
                            wz * VC_REGION_SCALE + 3.0);
    float localDecay = smoothstep(region - 0.20, region + 0.20, decay);

    float base = VC_BASE;
    float thick = VC_THICKNESS * mix(1.0, VC_DEGRADE_THICKNESS, localDecay);
    float h = (pos.y - base) / thick;
    if (h < 0.0 || h > 1.0) return 0.0;

    // Rounded cloud base, deep body, and a broken upper silhouette.
    float baseProfile = smoothstep(0.015, 0.16, h);
    float topProfile = 1.0 - smoothstep(mix(0.92, 0.66, localDecay), 1.0, h);
    float profile = baseProfile * topProfile;

    // Shared cloud-base altitude, with height variation produced by the density
    // field itself. Domain warping prevents the billows from reading as repeated
    // spheres and makes adjacent protrusions merge into irregular cloud towers.
    float horizontalScale = VC_SCALE;
    float verticalScale = mix(1.9, 0.72, localDecay);
    vec3 p = vec3(wx * horizontalScale,
                  h * verticalScale * 3.0,
                  wz * horizontalScale);
    p.x += (cellBig - 0.5) * 0.62;
    p.z += (cellSmall - 0.5) * 0.62;

    // Coarse silhouette + medium billows + restrained fine erosion. The medium
    // field is sampled at a different frequency and offset so it forms uneven
    // cauliflower-like lobes instead of smooth, uniformly round puffs.
    float broad = vcFbm(p, mix(0.92, 0.38, localDecay));
    vec3 billowP = vec3(p.x * 1.72 + 5.3,
                        p.y * 1.28 + 11.7,
                        p.z * 1.72 - 3.9);
    float billows = vcFbm(billowP, 0.72);
    float topBias = smoothstep(0.08, 0.72, h);
    float bodyShape = mix(broad * 0.78 + billows * 0.22,
                          broad * 0.48 + billows * 0.52, topBias);

    // Fine-scale erosion cuts notches between protrusions. Keep its amplitude
    // limited so details affect the silhouette without making the cloud wispy.
    float erosion = vcNoise(vec3(p.x * 3.1 + 23.4,
                                 p.y * 2.2 + 7.1,
                                 p.z * 3.1 - 16.8));
    float shape = bodyShape - (0.5 - erosion) * mix(0.10, 0.17, topBias);
    float threshold = mix(0.42, 0.49, topBias);
    float edge = smoothstep(threshold, threshold + 0.16, shape);
    float d = edge * mask * profile;
    d *= VC_DENSITY * mix(1.0, 0.58, localDecay);
    return d;
}

// ---------------------------------------------------------------- upper layer: thin daytime clouds -> sunset altocumulus
float vcDensityHigh(vec3 pos, float time, float amount, float decay) {
    float h = (pos.y - VC_HIGH_BASE) / VC_HIGH_THICK;
    if (h < 0.0 || h > 1.0) return 0.0;
    float lowerBand = smoothstep(0.00, 0.20, h) * (1.0 - smoothstep(0.38, 0.58, h));
    float upperBand = smoothstep(0.42, 0.62, h) * (1.0 - smoothstep(0.78, 1.0, h));
    float profile = max(lowerBand, 0.72 * upperBand);

    float wx = pos.x + time * VC_WIND * 1.6;
    float wz = pos.z + time * VC_WIND * 0.5;
    float highYScale = mix(0.08, 1.0, decay);
    vec3 p = vec3(wx, pos.y * highYScale, wz) * VC_HIGH_SCALE;
    float n = vcFbm(p, mix(0.65, 0.9, decay));

    // Thin sheets for the daytime/cirrus regime.
    float sheetThreshold = 0.74 - amount * 0.26;
    float sheet = smoothstep(sheetThreshold, sheetThreshold + 0.12, n);
    float sheetCoverage = smoothstep(0.05, 0.65, amount);
    sheet *= sheetCoverage;

    // Altocumulus: discrete groups containing many small rounded cloudlets,
    // rather than a uniform noisy blanket. This is only mixed in as the sun lowers.
    float macroCells = vcNoise2(wx * VC_HIGH_CELL_SCALE, wz * VC_HIGH_CELL_SCALE);
    float smallCells = vcNoise2(wx * VC_HIGH_CELL_SCALE * 2.8 + 17.3,
                                wz * VC_HIGH_CELL_SCALE * 2.8 + 8.1);
    float clusters = smoothstep(0.43, 0.61, macroCells);
    clusters = max(clusters,
        0.30 * smoothstep(0.65, 0.78, smallCells));
    float cloudlets = smoothstep(0.48, 0.68, n) * clusters;
    float fineNoise = vcFbm(vec3(wx * VC_HIGH_SCALE * 2.7, h * 5.0, wz * VC_HIGH_SCALE * 2.7) + vec3(8.2, 3.7, 19.1), 0.85);
    // Keep individual cloudlets rounded and separated; avoid a continuous smoke veil.
    float puffs = cloudlets * smoothstep(0.38, 0.56, fineNoise);
    puffs *= smoothstep(0.04, 0.36, amount);

    // Vary the conversion by broad cloud region so only some cumulus degrade first.
    float region = vcNoise2(wx * VC_REGION_SCALE + 9.0,
                            wz * VC_REGION_SCALE + 3.0);
    float localDegrade = smoothstep(region - 0.18, region + 0.18, decay);
    float altoMix = smoothstep(VC_ALTOMIX_START, VC_ALTOMIX_END, decay) * localDegrade;
    float density = mix(sheet, puffs, altoMix);
    return density * profile * VC_HIGH_DENSITY;
}

// 4x4 ordered dither in [0,1)
float vcBayer(vec2 fragCoord) {
    int x = int(mod(fragCoord.x, 4.0));
    int y = int(mod(fragCoord.y, 4.0));
    int a = x ^ y;
    int idx = ((a & 1) << 3) | ((y & 1) << 2) | (a & 2) | ((y & 2) >> 1);
    return (float(idx) + 0.5) / 16.0;
}

// ray / slab intersection, returns false in 'hit' when the ray does not cross it
float vcSlabNear(float oy, float dy, float yLo, float yHi) {
    float t0 = (yLo - oy) / dy;
    float t1 = (yHi - oy) / dy;
    return max(min(t0, t1), 0.0);
}
float vcSlabFar(float oy, float dy, float yLo, float yHi, float limit) {
    float t0 = (yLo - oy) / dy;
    float t1 = (yHi - oy) / dy;
    return min(max(t0, t1), limit);
}

// sceneColor : background; dir : normalized view ray; org : world-origin camera offset
// lightDir : active light direction for the short optical-depth march
// sunDir / sunIntensity : sun direction and scalar brightness
// cloudColor : direct-cloud tint; ambCol : sky/ambient radiance
// maxDist : distance to terrain (huge for sky); sunElev : SunDir.y
vec3 applyVolumetricClouds(vec3 sceneColor, vec3 dir, vec3 org, vec3 lightDir,
    vec3 sunDir, float sunIntensity, vec3 cloudColor, vec3 ambCol,
    float time, float maxDist, vec2 fragCoord, float sunElev)
{
    if (abs(dir.y) < 0.0001) return sceneColor;

    float limit = min(maxDist, VC_MAX_DIST);
    float decay = 1.0 - smoothstep(0.02, 0.5, sunElev);
    float cumW = 1.0 - VC_SKY_STATE;
    float rimBoost = 1.0 - smoothstep(0.02, 0.4, abs(sunElev));
    float cosT = clamp(dot(dir, normalize(sunDir)), -1.0, 1.0);
    float sunPhase = mix(phase(cosT, 0.55, 1.0), phase(cosT, -0.2, 1.0), 0.35);
    float rimPhase = phase(cosT, 0.92, 1.0);
    float jitter = vcBayer(fragCoord);

    vec3 color = sceneColor;

    // ---- upper layer (behind the main one; thin clouds -> altocumulus) ----------------------
    {
        float yLo = VC_HIGH_BASE;
        float yHi = VC_HIGH_BASE + VC_HIGH_THICK;
        float tN = vcSlabNear(org.y, dir.y, yLo, yHi);
        float tF = vcSlabFar(org.y, dir.y, yLo, yHi, limit);
        if (tF > tN) {
            float amount = clamp(VC_CIRRUS_MIN + (1.0 - cumW) * 0.55 + decay * 0.25, 0.0, 0.95);
            float dt = (tF - tN) / float(VC_HIGH_STEPS);
            float t = tN + dt * jitter;
            float trans = 1.0;
            vec3 inscatter = vec3(0.0);
            float firstHit = -1.0;
            for (int i = 0; i < VC_HIGH_STEPS; ++i) {
                vec3 pos = org + dir * t;
                float sigma = vcDensityHigh(pos, time, amount, decay);
                if (sigma > 0.0003) {
                    if (firstHit < 0.0) firstHit = t;
                    vec3 radiance = cloudColor * (sunIntensity
                                      * (sunPhase * VC_SUN_GAIN * 0.9
                                      + rimPhase * rimBoost * VC_RIM_GAIN * 0.5))
                                  + ambCol * (VC_AMBIENT_GAIN * 0.9);
                    float stepTrans = exp(-sigma * dt);
                    inscatter += radiance * (trans * (1.0 - stepTrans));
                    trans *= stepTrans;
                }
                t += dt;
            }
            if (firstHit >= 0.0) {
                float fade = exp(-firstHit * VC_FOG * 0.5);
                color = mix(color, color * trans + inscatter, fade);
            }
        }
    }

    // ---- main layer ------------------------------------------------------------------------
    float yLo = VC_BASE;
    float yHi = VC_BASE + VC_THICKNESS;
    float tNear = vcSlabNear(org.y, dir.y, yLo, yHi);
    float tFar = vcSlabFar(org.y, dir.y, yLo, yHi, limit);
    if (tFar <= tNear) return color;

    float dt = (tFar - tNear) / float(VC_STEPS);
    float t = tNear + dt * jitter;
    float lightStep = VC_THICKNESS * 0.45 / float(VC_LIGHT_STEPS);

    float trans = 1.0;
    vec3 inscatter = vec3(0.0);
    float firstHit = -1.0;

    for (int i = 0; i < VC_STEPS; ++i) {
        vec3 pos = org + dir * t;
        float sigma = vcDensity(pos, time, decay, cumW);
        if (sigma > 0.0005) {
            if (firstHit < 0.0) firstHit = t;

            float od = 0.0;
            for (int j = 1; j <= VC_LIGHT_STEPS; ++j) {
                od += vcDensity(pos + lightDir * (lightStep * float(j)), time, decay, cumW) * lightStep;
            }
            float sunVis = exp(-od * 1.12) + 0.16 * exp(-od * 0.18); // stronger self-shadowing, soft fill
            float rim = rimPhase * rimBoost * VC_RIM_GAIN * exp(-od * 0.55); // sun-facing edge glow
            float h = clamp((pos.y - VC_BASE) / VC_THICKNESS, 0.0, 1.0);
            vec3 radiance = cloudColor * (sunIntensity * (sunVis * sunPhase * VC_SUN_GAIN + rim))
                          + ambCol * (mix(0.45, 1.0, h) * VC_AMBIENT_GAIN);

            float stepTrans = exp(-sigma * dt);
            inscatter += radiance * (trans * (1.0 - stepTrans));
            trans *= stepTrans;
            if (trans < 0.02) break;
        }
        t += dt;
    }

    if (firstHit < 0.0) return color;
    float fade = exp(-firstHit * VC_FOG);
    return mix(color, color * trans + inscatter, fade);
}

#endif
