#ifndef MIRAI_VOLCLOUDS_INCLUDED
#define MIRAI_VOLCLOUDS_INCLUDED

// Procedural volumetric clouds (own implementation, no noise texture needed).
//
//  * Main layer: big cumulus with large gaps between them, plus a few small puffs so the sky
//    is not empty. 3D value-noise density, ray marched, lit by the sun with a short march
//    towards the light.
//  * High thin layer: cirrostratus / cirrus-like sheets, cheap (few steps, no light march).
//  * Sky state (VC_SKY_STATE): 0 = lots of cumulus, 1 = few cumulus and many thin clouds.
//  * Evening: from sun elevation ~30 deg down to the horizon some clouds (not all at the same
//    time) flatten: less detail noise, thinner, a bit higher and less dense. Gradual.
//  * Rim lighting: forward scattering glow on cloud edges that grows near sunrise / sunset.
//
// Written without swizzles / inout on purpose, so it can also be compiled and previewed on a CPU.

float vcHash3(ivec3 p) {
    uint h = uint(p.x) * 374761393u + uint(p.y) * 668265263u + uint(p.z) * 2147483647u;
    h = (h ^ (h >> 13u)) * 1274126177u;
    h = h ^ (h >> 16u);
    return float(h & 16777215u) / 16777216.0;
}

float vcNoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = p - i;
    f = f * f * (3.0 - 2.0 * f);
    ivec3 ip = ivec3(i);
    float c000 = vcHash3(ip);
    float c100 = vcHash3(ip + ivec3(1, 0, 0));
    float c010 = vcHash3(ip + ivec3(0, 1, 0));
    float c110 = vcHash3(ip + ivec3(1, 1, 0));
    float c001 = vcHash3(ip + ivec3(0, 0, 1));
    float c101 = vcHash3(ip + ivec3(1, 0, 1));
    float c011 = vcHash3(ip + ivec3(0, 1, 1));
    float c111 = vcHash3(ip + ivec3(1, 1, 1));
    float x00 = mix(c000, c100, f.x);
    float x10 = mix(c010, c110, f.x);
    float x01 = mix(c001, c101, f.x);
    float x11 = mix(c011, c111, f.x);
    return mix(mix(x00, x10, f.y), mix(x01, x11, f.y), f.z);
}

// 2D slice of the 3D noise (used for the large scale cloud placement)
float vcNoise2(float x, float z) {
    return vcNoise(vec3(x, 0.37, z));
}

// detail scales the amplitude of every octave after the first one (1 = full detail)
float vcFbm(vec3 p, float detail) {
    float sum = 0.0;
    float amp = 0.5;
    float norm = 0.0;
    for (int i = 0; i < VC_OCTAVES; ++i) {
        float w = (i == 0) ? 1.0 : detail;
        sum += vcNoise(p) * amp * w;
        norm += amp * w;
        p = p * 2.03 + vec3(17.1, 9.3, 5.7);
        amp *= 0.5;
    }
    return sum / norm;
}

// ---------------------------------------------------------------- main (cumulus) layer
// decay : 0 = day, 1 = evening/night (clouds flatten)      cumW : 1 = cumulus sky, 0 = cirrus sky
float vcDensity(vec3 pos, float time, float decay, float cumW) {
    float wx = pos.x + time * VC_WIND;
    float wz = pos.z + time * VC_WIND * 0.35;

    // where clouds may exist: large blobs separated by wide gaps, plus a few small puffs
    float cellBig = vcNoise2(wx * VC_CELL_SCALE, wz * VC_CELL_SCALE);
    float cellSmall = vcNoise2(wx * VC_CELL_SCALE * 3.3 + 31.7, wz * VC_CELL_SCALE * 3.3 + 12.9);
    float thrBig = mix(0.9, VC_CELL_THRESHOLD, cumW);            // cirrus sky: almost no big cumulus
    float mask = smoothstep(thrBig, thrBig + 0.12, cellBig);
    mask = max(mask, 0.6 * smoothstep(VC_SMALL_THRESHOLD, VC_SMALL_THRESHOLD + 0.1, cellSmall));
    if (mask <= 0.0) return 0.0;

    // evening: every region flattens at its own moment (some clouds first)
    float degMask = vcNoise2(wx * 0.0007 + 9.0, wz * 0.0007 + 3.0);
    float fl = smoothstep(degMask - 0.18, degMask + 0.18, decay);

    float base = VC_BASE + fl * 40.0;
    float thick = VC_THICKNESS * mix(1.0, 0.3, fl);
    float h = (pos.y - base) / thick;
    if (h < 0.0 || h > 1.0) return 0.0;
    float profile = smoothstep(0.0, 0.14, h) * (1.0 - smoothstep(0.5, 1.0, h));

    float ys = mix(1.4, 0.35, fl);
    vec3 p = vec3(wx, pos.y * ys, wz) * VC_SCALE;
    float shape = vcFbm(p, mix(1.0, 0.15, fl));
    float d = smoothstep(0.38, 0.6, shape) * mask * profile;
    return d * VC_DENSITY * mix(1.0, 0.55, fl);
}

// ---------------------------------------------------------------- high thin layer
float vcDensityHigh(vec3 pos, float time, float amount) {
    float h = (pos.y - VC_HIGH_BASE) / VC_HIGH_THICK;
    if (h < 0.0 || h > 1.0) return 0.0;
    float profile = smoothstep(0.0, 0.3, h) * (1.0 - smoothstep(0.4, 1.0, h));
    vec3 p = vec3((pos.x + time * VC_WIND * 1.6) * VC_HIGH_SCALE,
                  pos.y * 0.08,
                  (pos.z + time * VC_WIND * 0.5) * VC_HIGH_SCALE * 2.4);
    float n = vcFbm(p, 0.8);
    float thr = 0.74 - amount * 0.26;                   // more amount = lower threshold = more sky covered
    return smoothstep(thr, thr + 0.12, n) * profile * VC_HIGH_DENSITY;
}

// 4x4 ordered dither in [0,1)
float vcBayer(vec2 fragCoord) {
    int x = int(mod(fragCoord.x, 4.0));
    int y = int(mod(fragCoord.y, 4.0));
    int a = x ^ y;
    int idx = ((a & 1) << 3) | ((y & 1) << 2) | (a & 2) | ((y & 2) >> 1);
    return (float(idx) + 0.5) / 16.0;
}

// ray / slab intersection, returns false in 'hit' when the ray does not cross it
float vcSlabNear(float oy, float dy, float yLo, float yHi) {
    float t0 = (yLo - oy) / dy;
    float t1 = (yHi - oy) / dy;
    return max(min(t0, t1), 0.0);
}
float vcSlabFar(float oy, float dy, float yLo, float yHi, float limit) {
    float t0 = (yLo - oy) / dy;
    float t1 = (yHi - oy) / dy;
    return min(max(t0, t1), limit);
}


// ================================================================ photoreal style
#if VC_STYLE == 1
// cellular (Worley) noise: distance to the nearest feature point, ~0 at a point, ~1 far away
float vcWorley(vec3 p) {
    vec3 ip = floor(p);
    vec3 fp = p - ip;
    ivec3 base = ivec3(ip);
    float dmin = 4.0;
    for (int z = -1; z <= 1; ++z) {
        for (int y = -1; y <= 1; ++y) {
            for (int x = -1; x <= 1; ++x) {
                ivec3 c = base + ivec3(x, y, z);
                vec3 o = vec3(vcHash3(c), vcHash3(c + ivec3(17, 5, 31)), vcHash3(c + ivec3(7, 43, 11)));
                vec3 d = vec3(float(x), float(y), float(z)) + o - fp;
                dmin = min(dmin, dot(d, d));
            }
        }
    }
    return sqrt(dmin);
}

// erodeW = 1 adds the fine edge erosion (primary rays), 0 skips it (light / AO samples)
float vcDensityP(vec3 pos, float time, float decay, float cumW, float erodeW) {
    float wx = pos.x + time * VC_WIND;
    float wz = pos.z + time * VC_WIND * 0.35;

    // Sparse, large-scale weather cells. Keeping the small-puff mask weaker avoids a dotted,
    // evenly tiled sky; each active cell is then shaped by 3D Worley billows below.
    float cellBig = vcNoise2(wx * VC_CELL_SCALE, wz * VC_CELL_SCALE);
    float cellSmall = vcNoise2(wx * VC_CELL_SCALE * 3.3 + 31.7, wz * VC_CELL_SCALE * 3.3 + 12.9);
    float thrBig = mix(0.9, VC_CELL_THRESHOLD, cumW);
    float mBig = smoothstep(thrBig, thrBig + 0.12, cellBig);
    float mSmall = 0.52 * smoothstep(VC_SMALL_THRESHOLD, VC_SMALL_THRESHOLD + 0.12, cellSmall);
    float m = max(mBig, mSmall);
    if (m <= 0.001) return 0.0;

    // Region-by-region flattening around twilight. The transition is spatially varied, not a
    // global switch, so some towers soften before others.
    float degMask = vcNoise2(wx * 0.0007 + 9.0, wz * 0.0007 + 3.0);
    float fl = smoothstep(degMask - 0.18, degMask + 0.18, decay);

    float base = VC_BASE + fl * 40.0;
    float thick = VC_P_THICK * mix(1.0, 0.25, fl);
    float h = (pos.y - base) / thick;
    if (h < 0.0 || h > 1.0) return 0.0;

    // Broad towers grow from a comparatively flat base. Smaller cells remain short and
    // irregular instead of becoming miniature copies of the large cumulonimbus shapes.
    float hMax = mix(0.48, 1.0, mBig);
    float prof = smoothstep(0.0, 0.04, h) * (1.0 - smoothstep(hMax * 0.60, hMax, h));
    if (prof <= 0.001) return 0.0;

    float ys = mix(0.95, 0.30, fl);
    vec3 p = vec3(wx, pos.y * ys, wz);

    // Main billows: Worley gives rounded lobes, low-frequency FBM warps their silhouette.
    // A second, finer Worley scale is evaluated only for camera rays, keeping lighting and
    // AO marches cheaper while preserving fine protuberances at visible edges.
    float billow = clamp(1.0 - vcWorley(p * VC_P_BILLOW_SCALE), 0.0, 1.0);
    float lowFreq = vcFbm(p * (VC_SCALE * 0.42), 0.58);
    float shape = pow(billow, 1.45) * 0.67 + lowFreq * 0.33;
    if (erodeW > 0.5) {
        vec3 pFine = (p + vec3(13.7, 5.2, 19.1)) * VC_P_BILLOW2_SCALE;
        float fineBillow = clamp(1.0 - vcWorley(pFine), 0.0, 1.0);
        shape = shape * (1.0 - VC_P_BILLOW2_WEIGHT) + pow(fineBillow, 1.25) * VC_P_BILLOW2_WEIGHT;
        // Domain erosion breaks the overly smooth, bead-like contour into unequal scallops.
        float er = 1.0 - vcWorley(p * VC_P_ERODE_SCALE + vec3(3.1, 7.7, 1.3));
        float amt = VC_P_ERODE * (1.0 - fl * 0.82);
        shape = clamp((shape - (1.0 - er) * amt) / max(0.25, 1.0 - amt), 0.0, 1.0);
    }

    float d = smoothstep(0.34, 0.59, shape) * prof * m;
    return d * VC_P_DENSITY * mix(1.0, 0.52, fl);
}

// Small, separated altocumulus cloudlets in a higher layer. A coarse cluster mask creates
// naturally uneven groups and clear gaps; the 3D Worley field gives each cloudlet a rounded
// but slightly broken shape. This layer is enabled only in VC_STYLE 1.
float vcDensityAlto(vec3 pos, float time) {
    float wx = pos.x + time * VC_WIND * 0.55;
    float wz = pos.z + time * VC_WIND * 0.28;
    float clusterN = vcNoise2(wx * VC_ALTO_CLUSTER_SCALE + 71.3,
                              wz * VC_ALTO_CLUSTER_SCALE - 23.7);
    float cluster = smoothstep(VC_ALTO_CLUSTER_THRESHOLD,
                               VC_ALTO_CLUSTER_THRESHOLD + 0.15, clusterN);
    if (cluster <= 0.001) return 0.0;

    float h = (pos.y - VC_ALTO_BASE) / VC_ALTO_THICK;
    if (h < 0.0 || h > 1.0) return 0.0;
    float profile = smoothstep(0.0, 0.10, h) * (1.0 - smoothstep(0.55, 1.0, h));
    vec3 p = vec3(wx, pos.y * 0.24, wz) * VC_ALTO_SCALE;
    float cells = clamp(1.0 - vcWorley(p), 0.0, 1.0);
    float puff = smoothstep(0.38, 0.76, cells);
    return puff * cluster * profile * VC_ALTO_DENSITY;
}

vec3 vcMainAlto(vec3 color, vec3 dir, vec3 org, vec3 lightDir, vec3 sunCol, vec3 ambCol,
    float time, float limit, float jitter, float sunPhase, float rimPhase, float rimBoost)
{
    float tNear = vcSlabNear(org.y, dir.y, VC_ALTO_BASE, VC_ALTO_BASE + VC_ALTO_THICK);
    float tFar = vcSlabFar(org.y, dir.y, VC_ALTO_BASE, VC_ALTO_BASE + VC_ALTO_THICK, limit);
    if (tFar <= tNear) return color;

    float dt = (tFar - tNear) / float(VC_ALTO_STEPS);
    float t = tNear + dt * jitter;
    float trans = 1.0;
    vec3 inscatter = vec3(0.0);
    float firstHit = -1.0;
    float lightSeg = VC_ALTO_THICK * 0.20;

    for (int i = 0; i < VC_ALTO_STEPS; ++i) {
        vec3 pos = org + dir * t;
        float sigma = vcDensityAlto(pos, time);
        if (sigma > 0.00025) {
            if (firstHit < 0.0) firstHit = t;
            float od = vcDensityAlto(pos + lightDir * lightSeg, time) * lightSeg
                     + vcDensityAlto(pos + lightDir * (lightSeg * 2.0), time) * lightSeg;
            float height = clamp((pos.y - VC_ALTO_BASE) / VC_ALTO_THICK, 0.0, 1.0);
            float sunVis = exp(-od * 2.0);
            float rim = rimPhase * rimBoost * VC_RIM_GAIN * 1.20 * exp(-od * 0.5);
            vec3 radiance = sunCol * (sunVis * sunPhase * VC_SUN_GAIN * 0.85 + rim)
                          + ambCol * (mix(0.55, 1.0, height) * VC_AMBIENT_GAIN * 0.8);
            float stepTrans = exp(-sigma * dt);
            inscatter += radiance * (trans * (1.0 - stepTrans));
            trans *= stepTrans;
            if (trans < 0.025) break;
        }
        t += dt;
    }
    if (firstHit < 0.0) return color;
    return mix(color, color * trans + inscatter, exp(-firstHit * VC_FOG * 0.70));
}
#endif


#if VC_STYLE == 1
vec3 vcMainPhoto(vec3 color, vec3 dir, vec3 org, vec3 lightDir, vec3 sunCol, vec3 ambCol,
    float time, float limit, float jitter, float decay, float cumW,
    float sunPhase, float rimPhase, float rimBoost)
{
    float yLo = VC_BASE;
    float yHi = VC_BASE + VC_P_THICK;
    float tNear = vcSlabNear(org.y, dir.y, yLo, yHi);
    float tFar = vcSlabFar(org.y, dir.y, yLo, yHi, limit);
    if (tFar <= tNear) return color;

    float dt = (tFar - tNear) / float(VC_STEPS);
    float t = tNear + dt * jitter;
    float lightBase = VC_P_THICK * 0.03;

    float trans = 1.0;
    vec3 inscatter = vec3(0.0);
    float firstHit = -1.0;

    for (int i = 0; i < VC_STEPS; ++i) {
        vec3 pos = org + dir * t;
        float sigma = vcDensityP(pos, time, decay, cumW, 1.0);
        if (sigma > 0.0008) {
            if (firstHit < 0.0) firstHit = t;

            // light: steps that grow exponentially, so the small bumps shade each other
            float od = 0.0;
            float reach = 0.0;
            for (int j = 0; j < VC_LIGHT_STEPS; ++j) {
                float seg = lightBase * float(1 << j);
                od += vcDensityP(pos + lightDir * (reach + seg * 0.5), time, decay, cumW, 0.0) * seg;
                reach += seg;
            }

            // ambient occlusion: cloud above the point blocks the sky light (dark crevices, dark core)
            float aoOd = vcDensityP(pos + vec3(0.0, VC_P_THICK * 0.08, 0.0), time, decay, cumW, 0.0)
                       + vcDensityP(pos + vec3(0.0, VC_P_THICK * 0.22, 0.0), time, decay, cumW, 0.0);
            float ambVis = exp(-aoOd * VC_P_THICK * 0.08 * VC_P_AO);
            float hN = clamp((pos.y - VC_BASE) / VC_P_THICK, 0.0, 1.0);
            float ambBase = mix(VC_P_BASE_DARK, 1.0, smoothstep(0.0, 0.5, hN));   // flat, dark underside

            // sun: three orders of multiple scattering (each one softer and less directional)
            float ph1 = mix(sunPhase, 0.0796, 0.5);
            float ph2 = mix(sunPhase, 0.0796, 0.75);
            float sunTerm = sunPhase * exp(-od) + 0.5 * ph1 * exp(-od * 0.5) + 0.25 * ph2 * exp(-od * 0.25);
            float rim = rimPhase * rimBoost * VC_RIM_GAIN * exp(-od * 0.5);

            vec3 radiance = sunCol * (sunTerm * VC_SUN_GAIN + rim)
                          + ambCol * (ambBase * ambVis * VC_AMBIENT_GAIN);

            float stepTrans = exp(-sigma * dt);
            inscatter += radiance * (trans * (1.0 - stepTrans));
            trans *= stepTrans;
            if (trans < 0.02) break;
        }
        t += dt;
    }

    if (firstHit < 0.0) return color;
    float fade = exp(-firstHit * VC_FOG);
    return mix(color, color * trans + inscatter, fade);
}
#endif

// sceneColor : what is behind the clouds (sky or terrain)     dir : normalised view ray
// org : camera position                                       lightDir : direction TOWARDS the light
// sunCol : light colour (as the cirrus use)                   ambCol : sky / ambient radiance
// maxDist : distance to terrain (huge for sky)                sunElev : SunDir.y (sin of sun elevation)
vec3 applyVolumetricClouds(vec3 sceneColor, vec3 dir, vec3 org, vec3 lightDir,
    vec3 sunCol, vec3 ambCol, float time, float maxDist, vec2 fragCoord, float sunElev)
{
    if (abs(dir.y) < 0.0001) return sceneColor;

    float limit = min(maxDist, VC_MAX_DIST);
    float decay = 1.0 - smoothstep(0.02, 0.5, sunElev);
    float cumW = 1.0 - VC_SKY_STATE;
    float rimBoost = 1.0 - smoothstep(0.02, 0.4, abs(sunElev));
    vec3 cloudSun = sunCol;
#if MIRAI_SUNSET
    float warmWindow = 1.0 - smoothstep(0.015, 0.22, abs(sunElev));
    cloudSun = mix(sunCol, SUNSET_GOLD, warmWindow * 0.68);
    rimBoost = min(1.35, rimBoost * (1.0 + warmWindow * 0.28));
#endif
    float cosT = dot(dir, lightDir);
    float sunPhase = mix(phase(cosT, 0.55, 1.0), phase(cosT, -0.2, 1.0), 0.35);
    float rimPhase = phase(cosT, 0.92, 1.0);
    float jitter = vcBayer(fragCoord);

    vec3 color = sceneColor;

#if VC_STYLE == 1
    // Highest layer first: small, scattered altocumulus groups sit behind the thinner veil
    // and the larger cumulus towers. It also uses the same sunset rim-lighting response.
    color = vcMainAlto(color, dir, org, lightDir, cloudSun, ambCol, time, limit, jitter,
        sunPhase, rimPhase, rimBoost);
#endif

    // ---- high thin layer (behind the main one) -------------------------------------------
    {
        float yLo = VC_HIGH_BASE;
        float yHi = VC_HIGH_BASE + VC_HIGH_THICK;
        float tN = vcSlabNear(org.y, dir.y, yLo, yHi);
        float tF = vcSlabFar(org.y, dir.y, yLo, yHi, limit);
        if (tF > tN) {
            float amount = clamp(VC_CIRRUS_MIN + (1.0 - cumW) * 0.55 + decay * 0.25, 0.0, 0.95);
            float dt = (tF - tN) / float(VC_HIGH_STEPS);
            float t = tN + dt * jitter;
            float trans = 1.0;
            vec3 inscatter = vec3(0.0);
            float firstHit = -1.0;
            for (int i = 0; i < VC_HIGH_STEPS; ++i) {
                vec3 pos = org + dir * t;
                float sigma = vcDensityHigh(pos, time, amount);
                if (sigma > 0.0003) {
                    if (firstHit < 0.0) firstHit = t;
                    vec3 radiance = cloudSun * (sunPhase * VC_SUN_GAIN * 0.9 + rimPhase * rimBoost * VC_RIM_GAIN * 0.5)
                                  + ambCol * (VC_AMBIENT_GAIN * 0.9);
                    float stepTrans = exp(-sigma * dt);
                    inscatter += radiance * (trans * (1.0 - stepTrans));
                    trans *= stepTrans;
                }
                t += dt;
            }
            if (firstHit >= 0.0) {
                float fade = exp(-firstHit * VC_FOG * 0.5);
                color = mix(color, color * trans + inscatter, fade);
            }
        }
    }

#if VC_STYLE == 1
    return vcMainPhoto(color, dir, org, lightDir, cloudSun, ambCol, time, limit, jitter, decay, cumW,
        sunPhase, rimPhase, rimBoost);
#endif

    // ---- main layer ------------------------------------------------------------------------
    float yLo = VC_BASE;
    float yHi = VC_BASE + VC_THICKNESS;
    float tNear = vcSlabNear(org.y, dir.y, yLo, yHi);
    float tFar = vcSlabFar(org.y, dir.y, yLo, yHi, limit);
    if (tFar <= tNear) return color;

    float dt = (tFar - tNear) / float(VC_STEPS);
    float t = tNear + dt * jitter;
    float lightStep = VC_THICKNESS * 0.45 / float(VC_LIGHT_STEPS);

    float trans = 1.0;
    vec3 inscatter = vec3(0.0);
    float firstHit = -1.0;

    for (int i = 0; i < VC_STEPS; ++i) {
        vec3 pos = org + dir * t;
        float sigma = vcDensity(pos, time, decay, cumW);
        if (sigma > 0.0005) {
            if (firstHit < 0.0) firstHit = t;

            float od = 0.0;
            for (int j = 1; j <= VC_LIGHT_STEPS; ++j) {
                od += vcDensity(pos + lightDir * (lightStep * float(j)), time, decay, cumW) * lightStep;
            }
            float sunVis = exp(-od) + 0.2 * exp(-od * 0.15);          // crude multiple scattering
            float rim = rimPhase * rimBoost * VC_RIM_GAIN * exp(-od * 0.5);   // thin edges toward the sun glow
            float h = clamp((pos.y - VC_BASE) / VC_THICKNESS, 0.0, 1.0);
            vec3 radiance = cloudSun * (sunVis * sunPhase * VC_SUN_GAIN + rim)
                          + ambCol * (mix(0.45, 1.0, h) * VC_AMBIENT_GAIN);

            float stepTrans = exp(-sigma * dt);
            inscatter += radiance * (trans * (1.0 - stepTrans));
            trans *= stepTrans;
            if (trans < 0.02) break;
        }
        t += dt;
    }

    if (firstHit < 0.0) return color;
    float fade = exp(-firstHit * VC_FOG);
    return mix(color, color * trans + inscatter, fade);
}

#endif
