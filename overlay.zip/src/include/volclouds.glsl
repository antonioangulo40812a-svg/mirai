#ifndef MIRAI_VOLCLOUDS_INCLUDED
#define MIRAI_VOLCLOUDS_INCLUDED

// Volumetric clouds, procedural (no noise texture needed): a slab of 3D value-noise
// density, ray marched, lit by the sun with a short march towards the light.
// Own implementation. Called from the final pass, after Mirai's cirrus clouds.
//
// Written without swizzles / inout on purpose, so the maths can also be compiled and
// previewed on a CPU outside the game.
//
// Params (diag_config.glsl): VC_STEPS, VC_LIGHT_STEPS, VC_OCTAVES (quality),
// VC_BASE, VC_THICKNESS, VC_COVERAGE, VC_DENSITY, VC_SCALE, VC_WIND, VC_SUN_GAIN,
// VC_AMBIENT_GAIN, VC_MAX_DIST, VC_FOG.

float vcHash3(ivec3 p) {
    uint h = uint(p.x) * 374761393u + uint(p.y) * 668265263u + uint(p.z) * 2147483647u;
    h = (h ^ (h >> 13u)) * 1274126177u;
    h = h ^ (h >> 16u);
    return float(h & 16777215u) / 16777216.0;
}

float vcNoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = p - i;
    f = f * f * (3.0 - 2.0 * f);
    ivec3 ip = ivec3(i);
    float c000 = vcHash3(ip);
    float c100 = vcHash3(ip + ivec3(1, 0, 0));
    float c010 = vcHash3(ip + ivec3(0, 1, 0));
    float c110 = vcHash3(ip + ivec3(1, 1, 0));
    float c001 = vcHash3(ip + ivec3(0, 0, 1));
    float c101 = vcHash3(ip + ivec3(1, 0, 1));
    float c011 = vcHash3(ip + ivec3(0, 1, 1));
    float c111 = vcHash3(ip + ivec3(1, 1, 1));
    float x00 = mix(c000, c100, f.x);
    float x10 = mix(c010, c110, f.x);
    float x01 = mix(c001, c101, f.x);
    float x11 = mix(c011, c111, f.x);
    return mix(mix(x00, x10, f.y), mix(x01, x11, f.y), f.z);
}

float vcFbm(vec3 p) {
    float sum = 0.0;
    float amp = 0.5;
    float norm = 0.0;
    for (int i = 0; i < VC_OCTAVES; ++i) {
        sum += vcNoise(p) * amp;
        norm += amp;
        p = p * 2.03 + vec3(17.1, 9.3, 5.7);
        amp *= 0.5;
    }
    return sum / norm;
}

// extinction per world unit at a point
float vcDensity(vec3 pos, float time) {
    float h = clamp((pos.y - VC_BASE) / VC_THICKNESS, 0.0, 1.0);
    float profile = smoothstep(0.0, 0.14, h) * (1.0 - smoothstep(0.5, 1.0, h));
    if (profile <= 0.0) return 0.0;
    vec3 p = vec3(pos.x + time * VC_WIND, pos.y * 1.4, pos.z + time * VC_WIND * 0.35) * VC_SCALE;
    float shape = vcFbm(p);
    float threshold = 1.0 - VC_COVERAGE;
    float d = smoothstep(threshold, threshold + 0.22, shape) * profile;
    return d * VC_DENSITY;
}

// 4x4 ordered dither in [0,1): decorrelates the ray start so the steps do not show as bands
float vcBayer(vec2 fragCoord) {
    int x = int(mod(fragCoord.x, 4.0));
    int y = int(mod(fragCoord.y, 4.0));
    int a = x ^ y;
    int idx = ((a & 1) << 3) | ((y & 1) << 2) | (a & 2) | ((y & 2) >> 1);
    return (float(idx) + 0.5) / 16.0;
}

// sceneColor : what is behind the clouds (sky or terrain), same units as the final pass
// dir        : normalised view ray in world space      org : camera position in world space
// lightDir   : direction TOWARDS the light              sunCol : light colour (as the cirrus use)
// ambCol     : sky / ambient radiance                   maxDist: distance to terrain (or huge for sky)
vec3 applyVolumetricClouds(vec3 sceneColor, vec3 dir, vec3 org, vec3 lightDir,
    vec3 sunCol, vec3 ambCol, float time, float maxDist, vec2 fragCoord)
{
    if (abs(dir.y) < 0.0001) return sceneColor;

    float t0 = (VC_BASE - org.y) / dir.y;
    float t1 = (VC_BASE + VC_THICKNESS - org.y) / dir.y;
    float tNear = max(min(t0, t1), 0.0);
    float tFar = min(max(t0, t1), min(maxDist, VC_MAX_DIST));
    if (tFar <= tNear) return sceneColor;

    float dt = (tFar - tNear) / float(VC_STEPS);
    float t = tNear + dt * vcBayer(fragCoord);

    float cosT = dot(dir, lightDir);
    float sunPhase = mix(phase(cosT, 0.55, 1.0), phase(cosT, -0.2, 1.0), 0.35);
    float lightStep = VC_THICKNESS * 0.45 / float(VC_LIGHT_STEPS);

    float trans = 1.0;
    vec3 inscatter = vec3(0.0);
    float firstHit = -1.0;

    for (int i = 0; i < VC_STEPS; ++i) {
        vec3 pos = org + dir * t;
        float sigma = vcDensity(pos, time);
        if (sigma > 0.0005) {
            if (firstHit < 0.0) firstHit = t;

            float od = 0.0;
            for (int j = 1; j <= VC_LIGHT_STEPS; ++j) {
                od += vcDensity(pos + lightDir * (lightStep * float(j)), time) * lightStep;
            }
            float sunVis = exp(-od) + 0.2 * exp(-od * 0.15);          // crude multiple scattering
            float h = clamp((pos.y - VC_BASE) / VC_THICKNESS, 0.0, 1.0);
            vec3 radiance = sunCol * (sunVis * sunPhase * VC_SUN_GAIN)
                          + ambCol * (mix(0.45, 1.0, h) * VC_AMBIENT_GAIN);

            float stepTrans = exp(-sigma * dt);
            inscatter += radiance * (trans * (1.0 - stepTrans));
            trans *= stepTrans;
            if (trans < 0.02) break;
        }
        t += dt;
    }

    if (firstHit < 0.0) return sceneColor;
    float fade = exp(-firstHit * VC_FOG);                               // distance haze
    vec3 clouded = sceneColor * trans + inscatter;
    return mix(sceneColor, clouded, fade);
}

#endif
