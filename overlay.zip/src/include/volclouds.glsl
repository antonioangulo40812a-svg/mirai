#ifndef MIRAI_VOLCLOUDS_INCLUDED
#define MIRAI_VOLCLOUDS_INCLUDED

// Procedural volumetric clouds (own implementation, no noise texture needed).
//
//  * Main layer: big cumulus with large gaps between them, plus a few small puffs so the sky
//    is not empty. 3D value-noise density, ray marched, lit by the sun with a short march
//    towards the light.
//  * Upper layer: sparse thin clouds during the day, transitioning into grouped,
//    smaller altocumulus toward sunset. It reuses the same short ray march.
//  * Sky state (VC_SKY_STATE): 0 = cumulus-dominant, 1 = thin-cloud-dominant.
//  * Evening: individual cloud regions flatten at different times; upper cloud groups
//    strengthen as corresponding low cumulus regions thin out.
//  * Rim lighting: forward scattering glow on cloud edges that grows near sunrise / sunset.
//
// Written without swizzles / inout on purpose, so it can also be compiled and previewed on a CPU.

float vcHash3(ivec3 p) {
    uint h = uint(p.x) * 374761393u + uint(p.y) * 668265263u + uint(p.z) * 2147483647u;
    h = (h ^ (h >> 13u)) * 1274126177u;
    h = h ^ (h >> 16u);
    return float(h & 16777215u) / 16777216.0;
}

float vcNoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = p - i;
    f = f * f * (3.0 - 2.0 * f);
    ivec3 ip = ivec3(i);
    float c000 = vcHash3(ip);
    float c100 = vcHash3(ip + ivec3(1, 0, 0));
    float c010 = vcHash3(ip + ivec3(0, 1, 0));
    float c110 = vcHash3(ip + ivec3(1, 1, 0));
    float c001 = vcHash3(ip + ivec3(0, 0, 1));
    float c101 = vcHash3(ip + ivec3(1, 0, 1));
    float c011 = vcHash3(ip + ivec3(0, 1, 1));
    float c111 = vcHash3(ip + ivec3(1, 1, 1));
    float x00 = mix(c000, c100, f.x);
    float x10 = mix(c010, c110, f.x);
    float x01 = mix(c001, c101, f.x);
    float x11 = mix(c011, c111, f.x);
    return mix(mix(x00, x10, f.y), mix(x01, x11, f.y), f.z);
}

// 2D slice of the 3D noise (used for the large scale cloud placement)
float vcNoise2(float x, float z) {
    return vcNoise(vec3(x, 0.37, z));
}

// detail scales the amplitude of every octave after the first one (1 = full detail)
float vcFbm(vec3 p, float detail) {
    float sum = 0.0;
    float amp = 0.5;
    float norm = 0.0;
    for (int i = 0; i < VC_OCTAVES; ++i) {
        float w = (i == 0) ? 1.0 : detail;
        sum += vcNoise(p) * amp * w;
        norm += amp * w;
        p = p * 2.03 + vec3(17.1, 9.3, 5.7);
        amp *= 0.5;
    }
    return sum / norm;
}

// ---------------------------------------------------------------- main (cumulus) layer
// decay : 0 = day, 1 = evening/night (clouds flatten)      cumW : 1 = cumulus sky, 0 = cirrus sky
float vcDensity(vec3 pos, float time, float decay, float cumW) {
    float wx = pos.x + time * VC_WIND;
    float wz = pos.z + time * VC_WIND * 0.35;

    // Broad weather cells establish real gaps between cloud systems.
    float cellBig = vcNoise2(wx * VC_CELL_SCALE, wz * VC_CELL_SCALE);
    float cellSmall = vcNoise2(wx * VC_CELL_SCALE * 3.3 + 31.7, wz * VC_CELL_SCALE * 3.3 + 12.9);
    float thrBig = mix(0.88, VC_CELL_THRESHOLD, cumW);
    float maskBig = smoothstep(thrBig, thrBig + 0.14, cellBig);
    float maskSmall = 0.42 * smoothstep(VC_SMALL_THRESHOLD, VC_SMALL_THRESHOLD + 0.11, cellSmall);
    float mask = max(maskBig, maskSmall);
    if (mask <= 0.001) return 0.0;

    // Different regions flatten at different times, not as one synchronized sheet.
    float degMask = vcNoise2(wx * 0.0007 + 9.0, wz * 0.0007 + 3.0);
    float fl = smoothstep(degMask - 0.18, degMask + 0.18, decay);
    float base = VC_BASE + fl * VC_DEGRADE_RISE;
    float thick = VC_THICKNESS * mix(1.0, VC_DEGRADE_THICKNESS, fl);
    float h = (pos.y - base) / thick;
    if (h < 0.0 || h > 1.0) return 0.0;

    // Three vertical structures: a broad lower base, rounded middle billows,
    // and taller towers. Each has its own 3-D domain so the result is not a
    // horizontally smeared noise sheet. Evening suppresses the towers gradually.
    float baseProfile = smoothstep(0.00, 0.16, h) * (1.0 - smoothstep(0.40, 0.66, h));
    float billowProfile = smoothstep(0.08, 0.28, h) * (1.0 - smoothstep(0.72, 0.94, h));
    float towerProfile = smoothstep(0.18, 0.42, h) * (1.0 - smoothstep(0.78, 1.0, h));

    vec3 pBase = vec3(wx * VC_SCALE * 0.72, h * 2.2, wz * VC_SCALE * 0.72);
    vec3 pBillow = vec3(wx * VC_SCALE * 1.35, h * 3.8, wz * VC_SCALE * 1.35) + vec3(13.7, 4.1, 21.3);
    vec3 pTower = vec3(wx * VC_SCALE * 1.9, h * 5.0, wz * VC_SCALE * 1.9) + vec3(37.2, 8.3, 5.6);
    float broad = vcFbm(pBase, mix(0.72, 0.30, fl));
    float billows = vcFbm(pBillow, mix(1.0, 0.22, fl));
    float towers = vcFbm(pTower, mix(1.0, 0.12, fl));

    // Erode the edges with a smaller scale; keep the lower body connected while
    // making the tops lumpy and broken like cumulus instead of smoke.
    float erosion = vcNoise(vec3(wx * VC_SCALE * 4.1, h * 7.0, wz * VC_SCALE * 4.1));
    float body = smoothstep(0.43, 0.69, broad) * baseProfile;
    float lobes = smoothstep(0.43, 0.68, billows) * billowProfile;
    float verticalTowers = smoothstep(0.48, 0.70, towers) * towerProfile;
    float cloud = max(body * 0.88, lobes * 0.82);
    cloud = max(cloud, verticalTowers * (1.0 - fl) * 0.92);
    cloud *= smoothstep(0.22, 0.68, erosion) * 0.55 + 0.45;

    // As towers flatten, the broad base thins and the billows spread laterally.
    float density = cloud * mask * mix(1.0, 0.62, fl);
    return density * VC_DENSITY;
}

// ---------------------------------------------------------------- upper layer: thin daytime clouds -> sunset altocumulus
float vcDensityHigh(vec3 pos, float time, float amount, float decay) {
    float h = (pos.y - VC_HIGH_BASE) / VC_HIGH_THICK;
    if (h < 0.0 || h > 1.0) return 0.0;
    float lowerBand = smoothstep(0.00, 0.20, h) * (1.0 - smoothstep(0.38, 0.58, h));
    float upperBand = smoothstep(0.42, 0.62, h) * (1.0 - smoothstep(0.78, 1.0, h));
    float profile = max(lowerBand, 0.72 * upperBand);

    float wx = pos.x + time * VC_WIND * 1.6;
    float wz = pos.z + time * VC_WIND * 0.5;
    float highYScale = mix(0.08, 1.0, decay);
    vec3 p = vec3(wx, pos.y * highYScale, wz) * VC_HIGH_SCALE;
    float n = vcFbm(p, mix(0.65, 0.9, decay));

    // Thin sheets for the daytime/cirrus regime.
    float sheetThreshold = 0.74 - amount * 0.26;
    float sheet = smoothstep(sheetThreshold, sheetThreshold + 0.12, n);
    float sheetCoverage = smoothstep(0.05, 0.65, amount);
    sheet *= sheetCoverage;

    // Altocumulus: discrete groups containing many small rounded cloudlets,
    // rather than a uniform noisy blanket. This is only mixed in as the sun lowers.
    float macroCells = vcNoise2(wx * VC_HIGH_CELL_SCALE, wz * VC_HIGH_CELL_SCALE);
    float smallCells = vcNoise2(wx * VC_HIGH_CELL_SCALE * 2.8 + 17.3,
                                wz * VC_HIGH_CELL_SCALE * 2.8 + 8.1);
    float clusters = smoothstep(0.43, 0.61, macroCells);
    clusters = max(clusters,
        0.30 * smoothstep(0.65, 0.78, smallCells));
    float cloudlets = smoothstep(0.48, 0.68, n) * clusters;
    float fineNoise = vcFbm(vec3(wx * VC_HIGH_SCALE * 2.7, h * 5.0, wz * VC_HIGH_SCALE * 2.7) + vec3(8.2, 3.7, 19.1), 0.85);
    // Keep individual cloudlets rounded and separated; avoid a continuous smoke veil.
    float puffs = cloudlets * smoothstep(0.38, 0.56, fineNoise);
    puffs *= smoothstep(0.04, 0.36, amount);

    // Vary the conversion by broad cloud region so only some cumulus degrade first.
    float region = vcNoise2(wx * VC_REGION_SCALE + 9.0,
                            wz * VC_REGION_SCALE + 3.0);
    float localDegrade = smoothstep(region - 0.18, region + 0.18, decay);
    float altoMix = smoothstep(VC_ALTOMIX_START, VC_ALTOMIX_END, decay) * localDegrade;
    float density = mix(sheet, puffs, altoMix);
    return density * profile * VC_HIGH_DENSITY;
}

// 4x4 ordered dither in [0,1)
float vcBayer(vec2 fragCoord) {
    int x = int(mod(fragCoord.x, 4.0));
    int y = int(mod(fragCoord.y, 4.0));
    int a = x ^ y;
    int idx = ((a & 1) << 3) | ((y & 1) << 2) | (a & 2) | ((y & 2) >> 1);
    return (float(idx) + 0.5) / 16.0;
}

// ray / slab intersection, returns false in 'hit' when the ray does not cross it
float vcSlabNear(float oy, float dy, float yLo, float yHi) {
    float t0 = (yLo - oy) / dy;
    float t1 = (yHi - oy) / dy;
    return max(min(t0, t1), 0.0);
}
float vcSlabFar(float oy, float dy, float yLo, float yHi, float limit) {
    float t0 = (yLo - oy) / dy;
    float t1 = (yHi - oy) / dy;
    return min(max(t0, t1), limit);
}

// sceneColor : background; dir : normalized view ray; org : world-origin camera offset
// lightDir : active light direction for the short optical-depth march
// sunDir / sunIntensity : sun direction and scalar brightness
// cloudColor : direct-cloud tint; ambCol : sky/ambient radiance
// maxDist : distance to terrain (huge for sky); sunElev : SunDir.y
vec3 applyVolumetricClouds(vec3 sceneColor, vec3 dir, vec3 org, vec3 lightDir,
    vec3 sunDir, float sunIntensity, vec3 cloudColor, vec3 ambCol,
    float time, float maxDist, vec2 fragCoord, float sunElev)
{
    if (abs(dir.y) < 0.0001) return sceneColor;

    float limit = min(maxDist, VC_MAX_DIST);
    float decay = 1.0 - smoothstep(0.02, 0.5, sunElev);
    float cumW = 1.0 - VC_SKY_STATE;
    float rimBoost = 1.0 - smoothstep(0.02, 0.4, abs(sunElev));
    float cosT = clamp(dot(dir, normalize(sunDir)), -1.0, 1.0);
    float sunPhase = mix(phase(cosT, 0.55, 1.0), phase(cosT, -0.2, 1.0), 0.35);
    float rimPhase = phase(cosT, 0.92, 1.0);
    float jitter = vcBayer(fragCoord);

    vec3 color = sceneColor;

    // ---- upper layer (behind the main one; thin clouds -> altocumulus) ----------------------
    {
        float yLo = VC_HIGH_BASE;
        float yHi = VC_HIGH_BASE + VC_HIGH_THICK;
        float tN = vcSlabNear(org.y, dir.y, yLo, yHi);
        float tF = vcSlabFar(org.y, dir.y, yLo, yHi, limit);
        if (tF > tN) {
            float amount = clamp(VC_CIRRUS_MIN + (1.0 - cumW) * 0.55 + decay * 0.25, 0.0, 0.95);
            float dt = (tF - tN) / float(VC_HIGH_STEPS);
            float t = tN + dt * jitter;
            float trans = 1.0;
            vec3 inscatter = vec3(0.0);
            float firstHit = -1.0;
            for (int i = 0; i < VC_HIGH_STEPS; ++i) {
                vec3 pos = org + dir * t;
                float sigma = vcDensityHigh(pos, time, amount, decay);
                if (sigma > 0.0003) {
                    if (firstHit < 0.0) firstHit = t;
                    vec3 radiance = cloudColor * (sunIntensity
                                      * (sunPhase * VC_SUN_GAIN * 0.9
                                      + rimPhase * rimBoost * VC_RIM_GAIN * 0.5))
                                  + ambCol * (VC_AMBIENT_GAIN * 0.9);
                    float stepTrans = exp(-sigma * dt);
                    inscatter += radiance * (trans * (1.0 - stepTrans));
                    trans *= stepTrans;
                }
                t += dt;
            }
            if (firstHit >= 0.0) {
                float fade = exp(-firstHit * VC_FOG * 0.5);
                color = mix(color, color * trans + inscatter, fade);
            }
        }
    }

    // ---- main layer ------------------------------------------------------------------------
    float yLo = VC_BASE;
    float yHi = VC_BASE + VC_THICKNESS;
    float tNear = vcSlabNear(org.y, dir.y, yLo, yHi);
    float tFar = vcSlabFar(org.y, dir.y, yLo, yHi, limit);
    if (tFar <= tNear) return color;

    float dt = (tFar - tNear) / float(VC_STEPS);
    float t = tNear + dt * jitter;
    float lightStep = VC_THICKNESS * 0.45 / float(VC_LIGHT_STEPS);

    float trans = 1.0;
    vec3 inscatter = vec3(0.0);
    float firstHit = -1.0;

    for (int i = 0; i < VC_STEPS; ++i) {
        vec3 pos = org + dir * t;
        float sigma = vcDensity(pos, time, decay, cumW);
        if (sigma > 0.0005) {
            if (firstHit < 0.0) firstHit = t;

            float od = 0.0;
            for (int j = 1; j <= VC_LIGHT_STEPS; ++j) {
                od += vcDensity(pos + lightDir * (lightStep * float(j)), time, decay, cumW) * lightStep;
            }
            float sunVis = exp(-od) + 0.2 * exp(-od * 0.15);          // crude multiple scattering
            float rim = rimPhase * rimBoost * VC_RIM_GAIN * exp(-od * 0.5);   // thin edges toward the sun glow
            float h = clamp((pos.y - VC_BASE) / VC_THICKNESS, 0.0, 1.0);
            vec3 radiance = cloudColor * (sunIntensity * (sunVis * sunPhase * VC_SUN_GAIN + rim))
                          + ambCol * (mix(0.45, 1.0, h) * VC_AMBIENT_GAIN);

            float stepTrans = exp(-sigma * dt);
            inscatter += radiance * (trans * (1.0 - stepTrans));
            trans *= stepTrans;
            if (trans < 0.02) break;
        }
        t += dt;
    }

    if (firstHit < 0.0) return color;
    float fade = exp(-firstHit * VC_FOG);
    return mix(color, color * trans + inscatter, fade);
}

#endif
