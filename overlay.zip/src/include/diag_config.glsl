#ifndef MIRAI_DIAG_CONFIG_INCLUDED
#define MIRAI_DIAG_CONFIG_INCLUDED

// ---------------------------------------------------------------------------
// Diagnostic mode (compile time). 0 = OFF.
//   1..4 final pass   : 1 distance map, 2 normals, 3 albedo, 4 diffuse lighting
//   5..6 ambient pass : 5 depth, 6 normals
//   7    ambient pass : SSAO factor only (grey = light kept, dark = occluded)
//   8    final pass   : SSGI indirect light only (needs MIRAI_SSGI 1)
//   9    final pass   : SSGI colour tint only (grey = no shift, needs MIRAI_SSGI 1)
// Modes 5-7 also zero the directional light so only the ambient pass shows.
// ---------------------------------------------------------------------------
#define MIRAI_DIAG 0
#define MIRAI_DIAG_FINAL_GAIN 1.0
#define MIRAI_DIAG_AMBIENT_GAIN 0.01

// ---------------------------------------------------------------------------
// SSAO (screen space ambient occlusion), applied to the AMBIENT light only.
// MIRAI_SSAO 0 + MIRAI_DIAG 0 = identical to upstream Mirai.
// ---------------------------------------------------------------------------
#define MIRAI_SSAO 0
#define SSAO_SAMPLES 8
#define SSAO_RADIUS 0.5
#define SSAO_STRENGTH 0.6
#define SSAO_BIAS 0.03
#define SSAO_FADE_START 24.0
#define SSAO_FADE_END 48.0

#if MIRAI_SSAO || MIRAI_DIAG == 7
#define MIRAI_SSAO_CODE 1
#else
#define MIRAI_SSAO_CODE 0
#endif

// ---------------------------------------------------------------------------
// SSGI (screen space indirect light), applied in the FINAL pass using the
// diffuse lighting buffer as the source of bounced light.
// MIRAI_SSGI 0 = off.
// ---------------------------------------------------------------------------
#define MIRAI_SSGI 0
#define SSGI_SAMPLES 8
#define SSGI_RADIUS 3.0
#define SSGI_STRENGTH 0.5
#define SSGI_BLEED 0.8
#define SSGI_TINT 0.7
#define SSGI_GAIN 3.0
#define SSGI_FALLOFF 1.5
// colour bleeding is only shown on bright, neutral surfaces (see ssgiTintGate)
#define SSGI_TINT_LUM_MIN 0.12
#define SSGI_TINT_LUM_MAX 0.30
#define SSGI_TINT_SAT_POWER 1.5
#define SSGI_FADE_START 24.0
#define SSGI_FADE_END 48.0
#define SSGI_VIS_CHECK 1
#define SSGI_DEBUG_GAIN 2.0

#if MIRAI_SSGI || MIRAI_DIAG == 8 || MIRAI_DIAG == 9
#define MIRAI_SSGI_CODE 1
#else
#define MIRAI_SSGI_CODE 0
#endif

// which pass a diagnostic mode belongs to
#define MIRAI_DIAG_AMBIENT (MIRAI_DIAG >= 5 && MIRAI_DIAG <= 7)
#define MIRAI_DIAG_FINAL ((MIRAI_DIAG >= 1 && MIRAI_DIAG <= 4) || MIRAI_DIAG == 8 || MIRAI_DIAG == 9)

// ---------------------------------------------------------------------------
// Post processing, material ColorPostProcessing (own implementation).
// Everything off = identical to upstream Mirai.
// ---------------------------------------------------------------------------
#define MIRAI_CA 0
#define CA_STRENGTH 0.03
#define MIRAI_BLUR 0
#define BLUR_SIZE 0.014
#define BLUR_START 0.2
#define BLUR_END 0.65
#define BLUR_TAPS 8
#define SCREEN_ASPECT 2.2

// ---------------------------------------------------------------------------
// Volumetric clouds (own implementation, procedural noise). 0 = off = upstream Mirai.
// ---------------------------------------------------------------------------
#define MIRAI_VCLOUDS 0
// quality
#define VC_STEPS 20
#define VC_LIGHT_STEPS 3
#define VC_OCTAVES 3
#define VC_HIGH_STEPS 6
// sky: 0 = many big cumulus, 1 = few cumulus and many thin clouds
#define VC_SKY_STATE 0.2
#define VC_CELL_SCALE 0.0011
#define VC_CELL_THRESHOLD 0.58
#define VC_SMALL_THRESHOLD 0.68
#define VC_CIRRUS_MIN 0.25
// main layer
#define VC_BASE 200.0
#define VC_THICKNESS 90.0
#define VC_DENSITY 0.06
#define VC_SCALE 0.004
#define VC_WIND 3.0
// high thin layer (cirrostratus-like)
#undef VC_HIGH_BASE
#define VC_HIGH_BASE 330.0
#define VC_HIGH_THICK 30.0
#define VC_HIGH_DENSITY 0.018
#define VC_HIGH_SCALE 0.0016
// light
#define VC_SUN_GAIN 1.0
#define VC_AMBIENT_GAIN 0.5
#define VC_RIM_GAIN 1.0
#define VC_MAX_DIST 3500.0
#define VC_FOG 0.0004
// photoreal style (VC_STYLE 1): billowing cumulus, flat dark base, ambient occlusion inside the cloud
#define VC_STYLE 0
#define VC_P_THICK 150.0
#define VC_P_DENSITY 0.09
#define VC_P_BILLOW_SCALE 0.012
#define VC_P_ERODE_SCALE 0.045
#define VC_P_ERODE 0.35
#define VC_P_AO 1.1
#define VC_P_BASE_DARK 0.18

#endif
