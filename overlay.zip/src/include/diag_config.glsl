#ifndef MIRAI_DIAG_CONFIG_INCLUDED
#define MIRAI_DIAG_CONFIG_INCLUDED

// Screen-space solar diffuse bounce. Quality-first defaults for screenshot use.
#ifndef MIRAI_DIAG
#define MIRAI_DIAG 0
#endif
#ifndef MIRAI_SSAO
#define MIRAI_SSAO 0
#endif
#ifndef MIRAI_SSGI
#define MIRAI_SSGI 1
#endif

#ifndef SSGI_STRENGTH
#define SSGI_STRENGTH 2.0
#endif
#ifndef SSGI_RADIUS
#define SSGI_RADIUS 8.0
#endif
#ifndef SSGI_SAMPLES
#define SSGI_SAMPLES 24
#endif
#ifndef SSGI_RAY_STEPS
#define SSGI_RAY_STEPS 48
#endif
#ifndef SSGI_THICKNESS
#define SSGI_THICKNESS 0.16
#endif
#ifndef SSGI_BIAS
#define SSGI_BIAS 0.08
#endif

#endif // MIRAI_DIAG_CONFIG_INCLUDED
