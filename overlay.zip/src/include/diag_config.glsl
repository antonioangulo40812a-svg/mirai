#ifndef MIRAI_DIAG_CONFIG_INCLUDED
#define MIRAI_DIAG_CONFIG_INCLUDED

// Diagnostic mode (compile time). 0 = OFF, identical to upstream Mirai.
//   1 = final pass   : distance map (grey ramp, red band every 8 units, dark blue = sky)
//   2 = final pass   : normals as RGB          (tests s_Normal binding in that pass)
//   3 = final pass   : albedo                  (tests s_ColorMetalnessSubsurface binding)
//   4 = final pass   : DiffuseLighting only    (candidate radiance source for SSGI)
//   5 = ambient pass : depth                   (tests s_SceneDepth binding in that pass)
//   6 = ambient pass : normals as RGB          (tests s_Normal binding in that pass)
// Modes 5 and 6 also zero the directional light so only the ambient pass shows.
#define MIRAI_DIAG 0

// Output scale for modes 1-3 (applied before tonemapping).
#define MIRAI_DIAG_FINAL_GAIN 1.0
// Output scale for modes 5-6 (the ambient result is later multiplied by
// EXPOSURE_MULTIPLIER and auto-exposed, so a small value is expected).
#define MIRAI_DIAG_AMBIENT_GAIN 0.01

#endif
