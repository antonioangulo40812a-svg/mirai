#ifndef MIRAI_DIAG_CONFIG_INCLUDED
#define MIRAI_DIAG_CONFIG_INCLUDED

// ---------------------------------------------------------------------------
// Diagnostic mode (compile time). 0 = OFF.
//   1..4 final pass   : 1 distance map, 2 normals, 3 albedo, 4 diffuse lighting
//   5..6 ambient pass : 5 depth, 6 normals
//   7    ambient pass : SSAO factor only (grey = light kept, dark = occluded)
//   8    final pass   : SSGI indirect light only (needs MIRAI_SSGI 1)
//   9    final pass   : SSGI colour tint only (grey = no shift, needs MIRAI_SSGI 1)
// Modes 5-7 also zero the directional light so only the ambient pass shows.
// ---------------------------------------------------------------------------
#define MIRAI_DIAG 0
#define MIRAI_DIAG_FINAL_GAIN 1.0
#define MIRAI_DIAG_AMBIENT_GAIN 0.01

// ---------------------------------------------------------------------------
// SSAO (screen space ambient occlusion), applied to the AMBIENT light only.
// MIRAI_SSAO 0 + MIRAI_DIAG 0 = identical to upstream Mirai.
// ---------------------------------------------------------------------------
#define MIRAI_SSAO 0
#define SSAO_SAMPLES 8
#define SSAO_RADIUS 0.5
#define SSAO_STRENGTH 0.6
#define SSAO_BIAS 0.03
#define SSAO_FADE_START 24.0
#define SSAO_FADE_END 48.0

#if MIRAI_SSAO || MIRAI_DIAG == 7
#define MIRAI_SSAO_CODE 1
#else
#define MIRAI_SSAO_CODE 0
#endif

// ---------------------------------------------------------------------------
// SSGI (screen space indirect light), applied in the FINAL pass using the
// diffuse lighting buffer as the source of bounced light.
// MIRAI_SSGI 0 = off.
// ---------------------------------------------------------------------------
#define MIRAI_SSGI 0
#define SSGI_SAMPLES 8
#define SSGI_RADIUS 3.0
#define SSGI_STRENGTH 0.5
#define SSGI_BLEED 0.8
#define SSGI_TINT 0.7
#define SSGI_GAIN 3.0
#define SSGI_FALLOFF 1.5
// colour bleeding is only shown on bright, neutral surfaces (see ssgiTintGate)
#define SSGI_TINT_LUM_MIN 0.12
#define SSGI_TINT_LUM_MAX 0.30
#define SSGI_TINT_SAT_POWER 1.5
#define SSGI_FADE_START 24.0
#define SSGI_FADE_END 48.0
#define SSGI_VIS_CHECK 1
#define SSGI_DEBUG_GAIN 2.0

#if MIRAI_SSGI || MIRAI_DIAG == 8 || MIRAI_DIAG == 9
#define MIRAI_SSGI_CODE 1
#else
#define MIRAI_SSGI_CODE 0
#endif

// which pass a diagnostic mode belongs to
#define MIRAI_DIAG_AMBIENT (MIRAI_DIAG >= 5 && MIRAI_DIAG <= 7)
#define MIRAI_DIAG_FINAL ((MIRAI_DIAG >= 1 && MIRAI_DIAG <= 4) || MIRAI_DIAG == 8 || MIRAI_DIAG == 9)

// ---------------------------------------------------------------------------
// Post processing, material ColorPostProcessing (own implementation).
// Everything off = identical to upstream Mirai.
// ---------------------------------------------------------------------------
#define MIRAI_CA 0
#define CA_STRENGTH 0.03
#define MIRAI_BLUR 0
#define BLUR_SIZE 0.014
#define BLUR_START 0.2
#define BLUR_END 0.65
#define BLUR_TAPS 8
#define SCREEN_ASPECT 2.2

// ---------------------------------------------------------------------------
// Volumetric clouds (own implementation, procedural noise). 0 = off = upstream Mirai.
// ---------------------------------------------------------------------------
#define MIRAI_VCLOUDS 0
// quality
#define VC_STEPS 20
#define VC_LIGHT_STEPS 3
#define VC_OCTAVES 3
#define VC_HIGH_STEPS 6
// sky: 0 = many big cumulus, 1 = few cumulus and many thin clouds
#define VC_SKY_STATE 0.2
#define VC_CELL_SCALE 0.0011
#define VC_CELL_THRESHOLD 0.58
#define VC_SMALL_THRESHOLD 0.68
#define VC_CIRRUS_MIN 0.25
// main layer
#define VC_BASE 200.0
#define VC_THICKNESS 90.0
#define VC_DENSITY 0.06
#define VC_SCALE 0.004
#define VC_WIND 3.0
// high thin layer (cirrostratus-like)
#define VC_HIGH_BASE 330.0
#define VC_HIGH_THICK 30.0
#define VC_HIGH_DENSITY 0.018
#define VC_HIGH_SCALE 0.0016
// light
#define VC_SUN_GAIN 1.0
#define VC_AMBIENT_GAIN 0.5
#define VC_RIM_GAIN 1.0
#define VC_MAX_DIST 3500.0
#define VC_FOG 0.0004
// photoreal style (VC_STYLE 1): billowing cumulus, flat dark base, ambient occlusion inside the cloud
#define VC_STYLE 0
#define VC_P_THICK 150.0
#define VC_P_DENSITY 0.09
#define VC_P_BILLOW_SCALE 0.0095
#define VC_P_BILLOW2_SCALE 0.024
#define VC_P_BILLOW2_WEIGHT 0.18
#define VC_P_ERODE_SCALE 0.052
#define VC_P_ERODE 0.34
#define VC_P_AO 1.25
#define VC_P_BASE_DARK 0.16

// Sparse alto-cumulus cloudlets above the main cumulus deck (photoreal preset only).
// A broad 2D cluster mask creates clear corridors; Worley cells create individual puffs.
#define VC_ALTO_BASE 405.0
#define VC_ALTO_THICK 34.0
#define VC_ALTO_STEPS 8
#define VC_ALTO_SCALE 0.022
#define VC_ALTO_DENSITY 0.020
#define VC_ALTO_CLUSTER_SCALE 0.00155
#define VC_ALTO_CLUSTER_THRESHOLD 0.70

// Procedural sunset gradient and solar halo. Applied only near sunrise/sunset and
// to both the final sky and Sky Probe so reflections use the same atmosphere.
#define MIRAI_SUNSET 0
#define SUNSET_STRENGTH 0.78
#define SUNSET_GOLD vec3(1.0, 0.38, 0.075)
#define SUNSET_MAUVE vec3(0.52, 0.34, 0.57)
#define SUNSET_BLUE vec3(0.20, 0.44, 0.67)

// golden hour: warm tint on the light colours (direct, ambient, fog, clouds, reflections) plus a
// golden-orange strip on the horizon. Fades before night. 0 = off.
#define MIRAI_GOLDEN 0
#define GOLDEN_STRENGTH 1.0
#define GOLDEN_AMBIENT_MIX 0.45
#define GOLDEN_PEAK_BOOST 0.12
#define GOLDEN_GOLD vec3(1.00, 0.76, 0.42)
#define GOLDEN_PEACH vec3(1.00, 0.62, 0.52)
#define GOLDEN_STRIP_HEIGHT 0.14
#define GOLDEN_STRIP_STRENGTH 0.95
#define GOLDEN_STRIP_GOLD vec3(1.0, 0.56, 0.16)
#define GOLDEN_STRIP_PEACH vec3(1.0, 0.54, 0.40)
// auto exposure fix (ColorPostProcessing): limit how far the night exposure can rise and give
// the colour back as the exposure goes up. 0 = off = upstream.
#define MIRAI_EXPO_FIX 0
#define EXPO_NIGHT_LIMIT 2.5
#define EXPO_SAT 0.5
#endif
