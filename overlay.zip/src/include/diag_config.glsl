#ifndef MIRAI_DIAG_CONFIG_INCLUDED
#define MIRAI_DIAG_CONFIG_INCLUDED

// ---------------------------------------------------------------------------
// Diagnostic mode (compile time). 0 = OFF.
//   1..4 final pass   : 1 distance map, 2 normals, 3 albedo, 4 diffuse lighting
//   5..6 ambient pass : 5 depth, 6 normals
//   7    ambient pass : SSAO factor only (grey = light kept, dark = occluded)
//   8    final pass   : SSGI indirect light only (needs MIRAI_SSGI 1)
//   9    final pass   : SSGI colour tint only (grey = no shift, needs MIRAI_SSGI 1)
// Modes 5-7 also zero the directional light so only the ambient pass shows.
// ---------------------------------------------------------------------------
#define MIRAI_DIAG 0
#define MIRAI_DIAG_FINAL_GAIN 1.0
#define MIRAI_DIAG_AMBIENT_GAIN 0.01

// ---------------------------------------------------------------------------
// SSAO (screen space ambient occlusion), applied to the AMBIENT light only.
// MIRAI_SSAO 0 + MIRAI_DIAG 0 = identical to upstream Mirai.
// ---------------------------------------------------------------------------
#define MIRAI_SSAO 0
#define SSAO_SAMPLES 8
#define SSAO_RADIUS 0.5
#define SSAO_STRENGTH 0.6
#define SSAO_BIAS 0.03
#define SSAO_FADE_START 24.0
#define SSAO_FADE_END 48.0

#if MIRAI_SSAO || MIRAI_DIAG == 7
#define MIRAI_SSAO_CODE 1
#else
#define MIRAI_SSAO_CODE 0
#endif

// ---------------------------------------------------------------------------
// SSGI (screen space indirect light), applied in the FINAL pass using the
// diffuse lighting buffer as the source of bounced light.
// MIRAI_SSGI 0 = off.
// ---------------------------------------------------------------------------
#define MIRAI_SSGI 0
#define SSGI_SAMPLES 8
#define SSGI_RADIUS 3.0
#define SSGI_STRENGTH 0.5
#define SSGI_BLEED 0.8
#define SSGI_TINT 0.7
#define SSGI_GAIN 3.0
#define SSGI_FADE_START 24.0
#define SSGI_FADE_END 48.0
#define SSGI_VIS_CHECK 1
#define SSGI_DEBUG_GAIN 2.0

#if MIRAI_SSGI || MIRAI_DIAG == 8 || MIRAI_DIAG == 9
#define MIRAI_SSGI_CODE 1
#else
#define MIRAI_SSGI_CODE 0
#endif

// which pass a diagnostic mode belongs to
#define MIRAI_DIAG_AMBIENT (MIRAI_DIAG >= 5 && MIRAI_DIAG <= 7)
#define MIRAI_DIAG_FINAL ((MIRAI_DIAG >= 1 && MIRAI_DIAG <= 4) || MIRAI_DIAG == 8 || MIRAI_DIAG == 9)

#endif
