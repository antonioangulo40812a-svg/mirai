#ifndef MIRAI_SSAO_INCLUDED
#define MIRAI_SSAO_INCLUDED

// Screen space ambient occlusion, view-space hemisphere sampling.
// Conventions copied from Mirai's own SSR (screen_space_reflection.glsl):
//   - normals in the G-buffer are WORLD space, converted with u_view
//   - projToView / viewToProj handle the uv <-> NDC mapping
// Requires: s_SceneDepth (sampler2D) declared before this include.
// Distances are view-space units (1 unit should be 1 block: still to verify in game).

#include "lib/space_transf.glsl"

uniform mat4 u_view;
uniform mat4 u_proj;
uniform mat4 u_invProj;

// inverse of the uv mapping done by viewToProj()
vec2 ssaoUvToNdc(vec2 uv) {
    vec2 ndc = uv * 2.0 - 1.0;
#if !TRANSPILE_TARGET__GLSL
    ndc.y = -ndc.y;
#endif
    return ndc;
}

// interleaved gradient noise (Jimenez)
float ssaoNoise(vec2 p) {
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

// returns 0 (open) .. 1 (fully occluded), already faded with distance
float ssaoOcclusion(vec2 uv, float depth, vec3 worldNormal) {
    vec3 viewPos = projToView(vec3(ssaoUvToNdc(uv), depth), u_invProj);
    float dist = length(viewPos);

    float fade = 1.0 - smoothstep(SSAO_FADE_START, SSAO_FADE_END, dist);
    if (fade <= 0.0) return 0.0;

    vec3 n = normalize((u_view * vec4(worldNormal, 0.0)).xyz);
    vec3 helper = abs(n.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 t = normalize(cross(helper, n));
    vec3 b = cross(n, t);

    float n1 = ssaoNoise(gl_FragCoord.xy);
    float n2 = ssaoNoise(gl_FragCoord.yx + 17.0);
    float rot = n1 * 6.2831853;

    float occ = 0.0;
    for (int i = 0; i < SSAO_SAMPLES; ++i) {
        float fi = (float(i) + 0.5) / float(SSAO_SAMPLES);
        float phi = float(i) * 2.3999632 + rot;          // golden angle spiral
        float sxy = sqrt(fi);
        float cz = sqrt(1.0 - fi);                       // cosine weighted hemisphere
        vec3 h = vec3(cos(phi) * sxy, sin(phi) * sxy, cz);
        float r = 0.2 + 0.8 * fract(fi * 3.7 + n2);      // radius varies per sample

        vec3 sampleView = viewPos + (t * h.x + b * h.y + n * h.z) * (SSAO_RADIUS * r);
        vec3 sp = viewToProj(sampleView, u_proj);        // xy = uv, z = ndc depth
        if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0) continue;

        float sceneDepth = sampleDepth(s_SceneDepth, sp.xy);
        if (sceneDepth >= 0.9999) continue;              // sky never occludes

        vec3 sceneView = projToView(vec3(ssaoUvToNdc(sp.xy), sceneDepth), u_invProj);
        float dSample = length(sampleView);
        float dScene = length(sceneView);

        float rangeCheck = smoothstep(0.0, 1.0, SSAO_RADIUS / max(abs(dist - dScene), 0.0001));
        occ += (dScene < dSample - SSAO_BIAS ? 1.0 : 0.0) * rangeCheck;
    }
    return clamp(occ / float(SSAO_SAMPLES), 0.0, 1.0) * fade;
}

#endif
