#include "diag_config.glsl"

///////////////////////////////////////////////////////////
// VERTEX SHADER
///////////////////////////////////////////////////////////
#if SHADER_STAGE__VERTEX
in vec3 a_position;
in vec2 a_texcoord0;

out vec2 v_texcoord0;

void main() {
    v_texcoord0 = a_texcoord0;
    gl_Position = vec4(a_position.xy * 2.0 - 1.0, 0.0, 1.0);
}
#endif

///////////////////////////////////////////////////////////
// FRAGMENT SHADER
///////////////////////////////////////////////////////////
#if SHADER_STAGE__FRAGMENT
uniform vec4 ExposureCompensation;
uniform vec4 LuminanceMinMaxAndWhitePointAndMinWhitePoint;

SAMPLER2D(s_ColorTexture);
SAMPLER2D(s_PreExposureLuminance);
SAMPLER2D(s_AverageLuminance);
SAMPLER2D(s_CustomExposureCompensation);
SAMPLER2D(s_RasterizedColor);

#include "lib/common.glsl"

// AgX tonemapping
// https://github.com/bWFuanVzYWth/AgX
// https://iolite-engine.com/blog_posts/minimal_agx_implementation

const mat3 AGX_INSET = mat3(
    0.842479062253094, 0.0423282422610123, 0.0423756549057051,
    0.0784335999999992, 0.878468636469772, 0.0784336,
    0.0792237451477643, 0.0791661274605434, 0.879142973793104
);

const mat3 AGX_OUTSET = mat3(
    1.19687900512017, -0.0528968517574562, -0.0529716355144438,
    -0.0980208811401368, 1.15190312990417, -0.0980434501171241,
    -0.0990297440797205, -0.0989611768448433, 1.15107367264116
);

const float AGX_MIN_EV = -12.473931188332413;
const float AGX_MAX_EV = 4.026068811667588;
const float AGX_DYNAMIC_RANGE = AGX_MAX_EV - AGX_MIN_EV;

vec3 agxCurve3(vec3 v) {
    const float threshold = 0.6060606060606061;
    const float a_up = 69.86278913545539;
    const float a_down = 59.507875;
    const float b_up = 13.0 / 4.0;
    const float b_down = 3.0 / 1.0;
    const float c_up = -4.0 / 13.0;
    const float c_down = -1.0 / 3.0;

    vec3 mask = step(v, vec3(threshold));
    vec3 a = a_up + (a_down - a_up) * mask;
    vec3 b = b_up + (b_down - b_up) * mask;
    vec3 c = c_up + (c_down - c_up) * mask;
    return 0.5 + (((-2.0 * threshold)) + 2.0 * v) * pow(1.0 + a * pow(abs(v - threshold), b), c);
}

vec3 agx(vec3 val) {
    val = AGX_INSET * val;
    val = max(val, vec3(1e-6));
    val = clamp(log2(val) * (1.0 / AGX_DYNAMIC_RANGE) - (AGX_MIN_EV / AGX_DYNAMIC_RANGE), 0.0, 1.0);
    val = agxCurve3(val);
    val = AGX_OUTSET * val;
    val = max(val, vec3(0.0));
    return val;
}

#if MIRAI_CA || MIRAI_BLUR
// Chromatic aberration: R shifted outwards, B inwards, shift grows with the squared
// distance from the screen centre (zero in the middle).
vec3 postSampleCA(vec2 uv, vec2 caOff) {
#if MIRAI_CA
    return vec3(texture(s_ColorTexture, uv + caOff).r,
                texture(s_ColorTexture, uv).g,
                texture(s_ColorTexture, uv - caOff).b);
#else
    return texture(s_ColorTexture, uv).rgb;
#endif
}

// Fake depth of field WITHOUT depth (this material has no depth buffer): the picture gets
// softer towards the edges of the screen, like a lens. Real depth-based DoF is not possible here.
vec3 postSceneColor(vec2 uv) {
    vec2 c = uv - 0.5;
    vec2 caOff = c * dot(c, c) * CA_STRENGTH;
#if MIRAI_BLUR
    float amt = smoothstep(BLUR_START, BLUR_END, length(c));
    if (amt > 0.02) {
        vec3 sum = postSampleCA(uv, caOff);
        float wsum = 1.0;
        for (int i = 0; i < BLUR_TAPS; ++i) {
            float fi = (float(i) + 0.5) / float(BLUR_TAPS);
            float phi = float(i) * 2.3999632;                 // golden angle spiral
            vec2 o = vec2(cos(phi), sin(phi)) * sqrt(fi) * (amt * BLUR_SIZE);
            o.x /= SCREEN_ASPECT;                             // keep the blur circular on screen
            sum += postSampleCA(uv + o, caOff);
            wsum += 1.0;
        }
        return sum / wsum;
    }
#endif
    return postSampleCA(uv, caOff);
}
#endif

in vec2 v_texcoord0;
out vec4 fragColor;

void main() {
#if MIRAI_CA || MIRAI_BLUR
    vec3 inputColor = postSceneColor(v_texcoord0);
#else
    vec3 inputColor = texture(s_ColorTexture, v_texcoord0).rgb;
#endif
    inputColor = unExposeLighting(inputColor, texture(s_PreExposureLuminance, vec2(0.5)).r);

    float refLuminance = clamp(texture(s_AverageLuminance, vec2(0.5)).r,
        LuminanceMinMaxAndWhitePointAndMinWhitePoint.r,
        LuminanceMinMaxAndWhitePointAndMinWhitePoint.g);
    float exposure = (MIDDLE_GRAY / refLuminance) * ExposureCompensation.g;
    inputColor *= exposure;

    vec4 overlayCol = texture(s_RasterizedColor, v_texcoord0);
    inputColor = mix(inputColor, overlayCol.rgb, overlayCol.a);

    vec3 outColor = agx(inputColor);
    fragColor = vec4(outColor, 1.0);
}
#endif //SHADER_STAGE__FRAGMENT
