#!/usr/bin/env python3
"""Apply one JSON matrix variant to src/include/diag_config.glsl."""
from __future__ import annotations
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "src" / "include" / "diag_config.glsl"
KEYS = (
    "MIRAI_DIAG", "MIRAI_SSAO", "MIRAI_SSGI",
    "SSGI_STRENGTH", "SSGI_RADIUS", "SSGI_SAMPLES",
    "SSGI_RAY_STEPS", "SSGI_THICKNESS", "SSGI_BIAS",
)

def main() -> int:
    raw = os.environ.get("VARIANT")
    if not raw:
        print("error: VARIANT environment variable is missing", file=sys.stderr)
        return 2
    try:
        variant = json.loads(raw)
    except json.JSONDecodeError as exc:
        print(f"error: VARIANT is not valid JSON: {exc}", file=sys.stderr)
        return 2
    if not CONFIG.is_file():
        print(f"error: {CONFIG} is missing; extract overlay.zip first", file=sys.stderr)
        return 2

    values = {
        "MIRAI_DIAG": int(variant.get("diag", 0)),
        "MIRAI_SSAO": int(variant.get("ssao", 0)),
        "MIRAI_SSGI": int(variant.get("ssgi", 1)),
        "SSGI_STRENGTH": float(variant.get("strength", 0.65)),
        "SSGI_RADIUS": float(variant.get("radius", 8.0)),
        "SSGI_SAMPLES": int(variant.get("samples", 20)),
        "SSGI_RAY_STEPS": int(variant.get("ray_steps", 48)),
        "SSGI_THICKNESS": float(variant.get("thickness", 0.16)),
        "SSGI_BIAS": float(variant.get("bias", 0.08)),
    }
    content = CONFIG.read_text(encoding="utf-8")
    for key, value in values.items():
        pattern = rf"(^[ \t]*#define[ \t]+{re.escape(key)}[ \t]+).*$"
        content, count = re.subn(pattern, lambda m: m.group(1) + str(value), content, count=1, flags=re.M)
        if count != 1:
            print(f"error: expected exactly one #define for {key}", file=sys.stderr)
            return 2
    CONFIG.write_text(content, encoding="utf-8")

    # Lazurite 0.12.0 bumped its compact material JSON schema from 2 to 3.
    # Mirai's vanilla merge-source files are still schema 2. In schema 3,
    # Buffer.unknown (default 0) is inserted immediately before sampler_state.
    # Migrate only the four materials selected by this workflow.
    vanilla_dir = ROOT / "src" / "vanilla"
    material_names = (
        "DeferredMixedResolution.material.json",
        "DeferredMixedResolutionCaustics.material.json",
        "DeferredMixedResolutionSurfaceRadiance.material.json",
        "DeferredMixedResolutionLightingPrepass.material.json",
    )
    migrated = 0
    for filename in material_names:
        path = vanilla_dir / filename
        if not path.is_file():
            print(f"error: required vanilla material is missing: {path}", file=sys.stderr)
            return 2
        try:
            material = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            print(f"error: cannot read {path}: {exc}", file=sys.stderr)
            return 2
        if not isinstance(material, list) or len(material) < 7:
            print(f"error: unexpected material structure: {path}", file=sys.stderr)
            return 2
        if material[0] == 3:
            continue
        if material[0] != 2:
            print(f"error: unsupported material JSON schema {material[0]} in {path}", file=sys.stderr)
            return 2
        buffers = material[6]
        if not isinstance(buffers, list):
            print(f"error: invalid buffer table in {path}", file=sys.stderr)
            return 2
        for index, buffer in enumerate(buffers):
            if not isinstance(buffer, list) or len(buffer) not in (12, 14):
                size = len(buffer) if isinstance(buffer, list) else "non-list"
                print(f"error: invalid buffer record #{index} (length {size}) in {path}", file=sys.stderr)
                return 2
            buffer.insert(11, 0)
        material[0] = 3
        path.write_text(json.dumps(material, separators=(",", ":"), ensure_ascii=False) + "\n", encoding="utf-8")
        migrated += 1

    print(f"Migrated Lazurite material JSON: {migrated} upgraded, {len(material_names) - migrated} already current.")
    print("Configured variant:", variant.get("id", "unknown"))
    for key in KEYS:
        print(f"{key}={values[key]}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
