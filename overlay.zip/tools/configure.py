#!/usr/bin/env python3
"""Validate the Fotorrealista cloud overlay before compiling it."""
import json
import os
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

try:
    variant = json.loads(os.environ.get("VARIANT", "{}"))
except json.JSONDecodeError as exc:
    raise SystemExit(f"VARIANT is not valid JSON: {exc}")

if not isinstance(variant, dict):
    raise SystemExit("VARIANT must be a JSON object")
for key in ("id", "label", "n"):
    if key not in variant:
        raise SystemExit(f"VARIANT is missing {key!r}")
if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", str(variant["id"])):
    raise SystemExit("Variant id must contain only lowercase letters, digits, and hyphens")
if not isinstance(variant["label"], str) or not variant["label"].strip():
    raise SystemExit("Variant label must be a non-empty string")
if not isinstance(variant["n"], int) or variant["n"] < 1 or variant["n"] > 999:
    raise SystemExit("Variant n must be an integer from 1 to 999")

shader = ROOT / "src/include/lib/clouds.glsl"
if not shader.is_file():
    raise SystemExit(f"Missing patched cloud shader source: {shader}")
source = shader.read_text(encoding="utf-8")
for marker in ("MR_CLOUD_RAY_STEPS 16", "mrValueNoise3", "mrCumulusDensity", "applyProceduralCloudLayer"):
    if marker not in source:
        raise SystemExit(f"Cloud overlay is incomplete: missing {marker!r}")
if "time * 0.01" in source:
    raise SystemExit("Cloud source still contains the old time-dependent cirrus drift")

base_pack = ROOT / "base/mirai-android-3.1.0.mcpack"
if not base_pack.is_file():
    raise SystemExit(f"Missing bundled base Mirai pack: {base_pack}")
try:
    with zipfile.ZipFile(base_pack) as archive:
        names = archive.namelist()
        manifest_names = [n for n in names if n.endswith("/manifest.json") or n == "manifest.json"]
        if not manifest_names:
            raise SystemExit("Bundled base pack has no manifest.json")
        for path in (
            "renderer/materials/DeferredMixedResolutionSurfaceRadiance.material.bin",
            "renderer/materials/SkyProbeDeferredShading.material.bin",
        ):
            if not any(n.endswith("/" + path) for n in names):
                raise SystemExit(f"Bundled base pack is missing {path}")
except zipfile.BadZipFile as exc:
    raise SystemExit(f"Bundled base Mirai pack is not a valid ZIP: {exc}")

# The existing workflow filters for DeferredMixedResolution*. Extend the build
# selection to include SkyProbeDeferredShading, so the environment/sky probe
# receives the same cloud code as the visible sky. This is an idempotent patch
# to the checked-out build helper, not a change to the GitHub repository itself.
build_script = ROOT / "build.py"
if not build_script.is_file():
    raise SystemExit(f"Cannot find repository build script: {build_script}")
build_text = build_script.read_text(encoding="utf-8")
marker = "# MIRAI_FOTORREALISTA_SKYPROBE_BUILD"
anchor = "    selected, partial = _select_materials(all_materials, args.material)"
if marker not in build_text:
    if build_text.count(anchor) != 1:
        raise SystemExit("build.py layout differs from the expected version; refusing unsafe patch")
    patch = (
        f"    {marker}\n"
        "    if args.material and \"DeferredMixedResolution*\" in args.material:\n"
        "        args.material.append(\"SkyProbeDeferredShading*\")\n"
    )
    build_text = build_text.replace(anchor, patch + anchor, 1)
    build_script.write_text(build_text, encoding="utf-8")

print(f"Validated overlay variant: {variant['id']} ({variant['label']})")
print("Base Mirai pack and Fotorrealista subpack paths are present.")
print("Build selection includes both visible cloud composition and sky probe materials.")
