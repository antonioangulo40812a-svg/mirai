#!/usr/bin/env python3
"""Validate and wire the Mirai 2.1.1 legacy-cloud port into Mirai 3.1.x."""
import json
import os
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
try:
    variant = json.loads(os.environ.get("VARIANT", "{}"))
except json.JSONDecodeError as exc:
    raise SystemExit(f"VARIANT is not valid JSON: {exc}")
if not isinstance(variant, dict):
    raise SystemExit("VARIANT must be a JSON object")
for key in ("id", "label", "n"):
    if key not in variant:
        raise SystemExit(f"VARIANT is missing {key!r}")
if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", str(variant["id"])):
    raise SystemExit("Variant id must contain only lowercase letters, digits, and hyphens")
if not isinstance(variant["label"], str) or not variant["label"].strip():
    raise SystemExit("Variant label must be a non-empty string")
if not isinstance(variant["n"], int) or not 1 <= variant["n"] <= 999:
    raise SystemExit("Variant n must be an integer from 1 to 999")

shader = ROOT / "src/include/lib/clouds.glsl"
if not shader.is_file():
    raise SystemExit(f"Missing cloud shader source: {shader}")
source = shader.read_text(encoding="utf-8")
for marker in ("CLOUD_VOLUME_MAX_STEP_COUNTS 200", "calcCumulusModel", "calcDirectScattering", "applyMiraiLegacyClouds"):
    if marker not in source:
        raise SystemExit(f"Legacy cloud source is incomplete: missing {marker!r}")
for forbidden in ("applyProceduralCloudLayer", "mrCumulusDensity", "MR_CLOUD_RAY_STEPS"):
    if forbidden in source:
        raise SystemExit(f"Old experimental cloud implementation still present: {forbidden}")

targets = {
    ROOT / "src/include/deferred_mixed_resolution.glsl": (
        "applyCirrusClouds(outColor, worldDir, -WorldOrigin.xyz,\n            DirectionalLightSourceWorldSpaceDirection.xyz, cloudColor, Time.x, isTerrain);",
        "applyMiraiLegacyClouds(outColor, worldDir, worldDist, cloudColor, isTerrain);"
    ),
    ROOT / "src/include/sky_probe_deferred_shading.glsl": (
        "applyCirrusClouds(outColor, worldDir, -WorldOrigin.xyz,\n        DirectionalLightSourceWorldSpaceDirection.xyz, cloudColor, Time.x, false);",
        "applyMiraiLegacyClouds(outColor, worldDir, length(worldPos), cloudColor, false);"
    ),
}
for path, (old_call, new_call) in targets.items():
    if not path.is_file():
        raise SystemExit(f"Missing shader call site: {path}")
    text = path.read_text(encoding="utf-8")
    if new_call in text:
        continue
    if text.count(old_call) != 1:
        raise SystemExit(f"Expected exactly one original cloud call in {path}; refusing unsafe patch")
    path.write_text(text.replace(old_call, new_call, 1), encoding="utf-8")

# Restore the old soft cloud-shadow contribution to direct lighting as well.
deferred = ROOT / "src/include/deferred_mixed_resolution.glsl"
deferred_text = deferred.read_text(encoding="utf-8")
shadow_include = '#include "lib/clouds.glsl"'
shadow_uniform = "uniform vec4 MoonDir;"
shadow_anchor = "vec2 shadowMap = calcShadowMap(worldPos, normal);"
shadow_code = """vec2 shadowMap = calcShadowMap(worldPos, normal);

    CloudSetup cloudShadowSetup = calcCloudSetup(
        DirectionalLightSourceWorldSpaceDirection.y, position.y);
    float cloudShadow = calcCloudShadow(position,
        DirectionalLightSourceWorldSpaceDirection.xyz, 2.0, cloudShadowSetup);
    float cloudShadowMix = cloudShadow * CLOUD_SHADOW_CONTRIBUTION
        + (1.0 - CLOUD_SHADOW_CONTRIBUTION);
    shadowMap = min(shadowMap, vec2(cloudShadowMix));"""
if shadow_code not in deferred_text:
    if deferred_text.count(shadow_anchor) != 1:
        raise SystemExit("Could not locate the directional-light shadow anchor; refusing unsafe patch")
    # Add the include only to the directional-lighting section.
    direction_start = deferred_text.find("#if DIRECTIONAL_LIGHTING_PASS")
    direction_end = deferred_text.find("#endif //DIRECTIONAL_LIGHTING_PASS", direction_start)
    if direction_start < 0 or direction_end < 0:
        raise SystemExit("Could not locate directional-lighting block")
    block = deferred_text[direction_start:direction_end]
    if shadow_include not in block:
        block = block.replace('#include "lib/water_wave.glsl"', '#include "lib/water_wave.glsl"\n#include "lib/clouds.glsl"', 1)
    if shadow_uniform not in block:
        block = block.replace("uniform vec4 SunColor;", "uniform vec4 SunColor;\nuniform vec4 MoonDir;", 1)
    if block.count(shadow_anchor) != 1:
        raise SystemExit("Could not patch cloud-shadow calculation safely")
    block = block.replace(shadow_anchor, shadow_code, 1)
    deferred_text = deferred_text[:direction_start] + block + deferred_text[direction_end:]
    deferred.write_text(deferred_text, encoding="utf-8")

build_script = ROOT / "build.py"
if not build_script.is_file():
    raise SystemExit(f"Cannot find repository build script: {build_script}")
build_text = build_script.read_text(encoding="utf-8")
marker = "# MIRAI_LEGACY_CLOUDS_SKYPROBE_BUILD"
anchor = "    selected, partial = _select_materials(all_materials, args.material)"
if marker not in build_text:
    if build_text.count(anchor) != 1:
        raise SystemExit("build.py layout differs from the expected version; refusing unsafe patch")
    patch = (
        f"    {marker}\n"
        "    if args.material and any(\"DeferredMixedResolution\" in item for item in args.material):\n"
        "        if \"SkyProbeDeferredShading*\" not in args.material:\n"
        "            args.material.append(\"SkyProbeDeferredShading*\")\n"
    )
    build_script.write_text(build_text.replace(anchor, patch + anchor, 1), encoding="utf-8")

base_pack = ROOT / "base/mirai-android-3.1.0.mcpack"
if not base_pack.is_file():
    raise SystemExit(f"Missing bundled base pack: {base_pack}")
try:
    with zipfile.ZipFile(base_pack) as archive:
        names = archive.namelist()
        manifests = [n for n in names if n == "manifest.json" or n.endswith("/manifest.json")]
        if not manifests:
            raise SystemExit("Bundled base pack has no manifest.json")
        for path in (
            "renderer/materials/DeferredMixedResolutionSurfaceRadiance.material.bin",
            "renderer/materials/SkyProbeDeferredShading.material.bin",
        ):
            if not any(n.endswith("/" + path) for n in names):
                raise SystemExit(f"Bundled base pack is missing {path}")
except zipfile.BadZipFile as exc:
    raise SystemExit(f"Bundled base Mirai pack is not a valid ZIP: {exc}")

print(f"Validated overlay variant: {variant['id']} ({variant['label']})")
print("Experimental procedural clouds removed; Mirai 2.1.1 volumetric model wired into both sky paths.")
