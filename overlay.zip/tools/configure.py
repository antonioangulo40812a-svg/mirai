#!/usr/bin/env python3
"""Apply one JSON matrix variant to src/include/diag_config.glsl."""
from __future__ import annotations
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "src" / "include" / "diag_config.glsl"
KEYS = (
    "MIRAI_DIAG", "MIRAI_SSAO", "MIRAI_SSGI",
    "SSGI_STRENGTH", "SSGI_RADIUS", "SSGI_SAMPLES",
    "SSGI_RAY_STEPS", "SSGI_THICKNESS", "SSGI_BIAS",
)

def main() -> int:
    raw = os.environ.get("VARIANT")
    if not raw:
        print("error: VARIANT environment variable is missing", file=sys.stderr)
        return 2
    try:
        variant = json.loads(raw)
    except json.JSONDecodeError as exc:
        print(f"error: VARIANT is not valid JSON: {exc}", file=sys.stderr)
        return 2
    if not CONFIG.is_file():
        print(f"error: {CONFIG} is missing; extract overlay.zip first", file=sys.stderr)
        return 2

    values = {
        "MIRAI_DIAG": int(variant.get("diag", 0)),
        "MIRAI_SSAO": int(variant.get("ssao", 0)),
        "MIRAI_SSGI": int(variant.get("ssgi", 1)),
        "SSGI_STRENGTH": float(variant.get("strength", 2.0)),
        "SSGI_RADIUS": float(variant.get("radius", 8.0)),
        "SSGI_SAMPLES": int(variant.get("samples", 24)),
        "SSGI_RAY_STEPS": int(variant.get("ray_steps", 48)),
        "SSGI_THICKNESS": float(variant.get("thickness", 0.16)),
        "SSGI_BIAS": float(variant.get("bias", 0.08)),
    }
    content = CONFIG.read_text(encoding="utf-8")
    for key, value in values.items():
        pattern = rf"(^[ \t]*#define[ \t]+{re.escape(key)}[ \t]+).*$"
        content, count = re.subn(pattern, lambda m: m.group(1) + str(value), content, count=1, flags=re.M)
        if count != 1:
            print(f"error: expected exactly one #define for {key}", file=sys.stderr)
            return 2
    CONFIG.write_text(content, encoding="utf-8")
    print("Configured variant:", variant.get("id", "unknown"))
    for key in KEYS:
        print(f"{key}={values[key]}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
