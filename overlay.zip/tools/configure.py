#!/usr/bin/env python3
"""Validate the selected overlay variant before building."""
import json
import os
from pathlib import Path

root = Path(__file__).resolve().parents[1]
try:
    variant = json.loads(os.environ.get("VARIANT", "{}"))
except json.JSONDecodeError as exc:
    raise SystemExit(f"VARIANT is not valid JSON: {exc}")

required = {"id", "label", "n"}
if not isinstance(variant, dict) or not required.issubset(variant):
    raise SystemExit("VARIANT must contain id, label, and n")

shader = root / "src/include/water_prepass.glsl"
if not shader.is_file():
    raise SystemExit(f"Missing expected shader source: {shader}")
source = shader.read_text(encoding="utf-8")
if "waves2(waterPos, Time.x) * 0.25" not in source:
    raise SystemExit("Water-wave patch not found; refusing to build the wrong source")

print(f"Validated overlay variant: {variant['id']} ({variant['label']})")
print("No extra source configuration is required for this water-wave test.")
