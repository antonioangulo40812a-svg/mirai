#!/usr/bin/env python3
"""Apply one variant's #define overrides to src/include/diag_config.glsl.
The variant is passed as JSON in the VARIANT environment variable."""
import json, os, re, sys
from pathlib import Path

variant = json.loads(os.environ["VARIANT"])
path = Path(__file__).resolve().parent.parent / "src" / "include" / "diag_config.glsl"
text = path.read_text(encoding="utf-8")
for key, value in variant["defines"].items():
    pattern = re.compile(rf"^#define {re.escape(key)} .*$", re.M)
    if not pattern.search(text):
        sys.exit(f"error: '#define {key}' not found in {path.name}")
    text = pattern.sub(f"#define {key} {value}", text, count=1)
path.write_text(text, encoding="utf-8")
print(f"variant {variant['id']}:")
for key in variant["defines"]:
    print("  ", re.search(rf"^#define {re.escape(key)} .*$", text, re.M).group(0))
