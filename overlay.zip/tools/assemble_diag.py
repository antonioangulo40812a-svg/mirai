#!/usr/bin/env python3
"""Build a diagnostic .mcpack: official Mirai Android pack + freshly compiled materials.

usage: python tools/assemble_diag.py <mode 1-6>
needs: base/*.mcpack (official Mirai Android pack) and output-android/*.material.bin
"""
import json, shutil, sys, uuid, zipfile
from pathlib import Path

NAMES = {
    1: "distance map (final pass)",
    2: "normals (final pass)",
    3: "albedo (final pass)",
    4: "diffuse lighting (final pass)",
    5: "depth (ambient pass)",
    6: "normals (ambient pass)",
}

mode = int(sys.argv[1])
root = Path(__file__).resolve().parent.parent
bases = sorted((root / "base").glob("*.mcpack"))
if not bases:
    sys.exit("error: put the official Mirai Android .mcpack in base/")
built = sorted((root / "output-android").glob("*.material.bin"))
if not built:
    sys.exit("error: output-android/ has no .material.bin (did the build fail?)")

work = root / "work"
shutil.rmtree(work, ignore_errors=True)
with zipfile.ZipFile(bases[0]) as z:
    z.extractall(work)

manifest_path = next(work.rglob("manifest.json"))
pack = manifest_path.parent
mats = pack / "renderer" / "materials"
if not mats.is_dir():
    sys.exit(f"error: {mats} not found in the base pack")

replaced = []
for f in built:
    if not (mats / f.name).is_file():
        sys.exit(f"error: {f.name} is not in the base pack, refusing to add unknown material")
    shutil.copy2(f, mats / f.name)
    replaced.append(f.name)

m = json.loads(manifest_path.read_text(encoding="utf-8"))
m["header"]["name"] = f"Mirai DIAG {mode}: {NAMES[mode]}"
m["header"]["uuid"] = str(uuid.uuid5(uuid.NAMESPACE_URL, f"mirai-diag-header-{mode}"))
m["header"]["version"] = [3, 0, 100 + mode]
for mod in m.get("modules", []):
    mod["uuid"] = str(uuid.uuid5(uuid.NAMESPACE_URL, f"mirai-diag-module-{mode}"))
    mod["version"] = [3, 0, 100 + mode]
manifest_path.write_text(json.dumps(m, indent=2), encoding="utf-8")

out = root / f"mirai-diag-{mode}.mcpack"
out.unlink(missing_ok=True)
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(work.rglob("*")):
        z.write(p, p.relative_to(work).as_posix())
print(f"wrote {out.name}; replaced {len(replaced)} material(s): {', '.join(replaced)}")
