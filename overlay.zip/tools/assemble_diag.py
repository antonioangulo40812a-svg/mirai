#!/usr/bin/env python3
"""Package one diagnostic build using the common .mcpack assembler."""
from __future__ import annotations
import sys
from assemble_pack import main

def run() -> int:
    if len(sys.argv) != 2:
        print("usage: python tools/assemble_diag.py <mode>", file=sys.stderr)
        return 2
    mode = int(sys.argv[1])
    if not 1 <= mode <= 99:
        print("error: diagnostic mode must be between 1 and 99", file=sys.stderr)
        return 2
    return main([f"diag-{mode}", f"Diagnostic mode {mode}", str(30 + mode)])

if __name__ == "__main__":
    raise SystemExit(run())
