#!/usr/bin/env python3
"""Assemble a full Mirai pack with procedural clouds as a selectable subpack."""
import json
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
BASE_PACK = ROOT / "base/mirai-android-3.1.0.mcpack"
COMPILED_DIR = ROOT / "output-android"
MATERIAL_NAMES = (
    "DeferredMixedResolutionSurfaceRadiance.material.bin",
    "SkyProbeDeferredShading.material.bin",
)
SUBPACK_FOLDER = "mirai-2-1-1"


def safe_id(value: str) -> bool:
    return re.fullmatch(r"[a-z0-9][a-z0-9-]*", value) is not None


def extract_flat_pack(archive_path: Path, destination: Path) -> None:
    with zipfile.ZipFile(archive_path, "r") as source:
        names = [name for name in source.namelist() if not name.endswith("/")]
        manifest_candidates = [name for name in names if name == "manifest.json" or name.endswith("/manifest.json")]
        if not manifest_candidates:
            raise SystemExit("Base pack has no manifest.json")

        manifest_path = next((
            name for name in manifest_candidates
            if name[:-len("manifest.json")] + "renderer/materials/" + MATERIAL_NAMES[0] in names
        ), manifest_candidates[0])
        prefix = manifest_path[:-len("manifest.json")]
        extracted = 0
        for name in names:
            if not name.startswith(prefix):
                continue
            rel = name[len(prefix):]
            if not rel or rel.startswith("/") or ".." in PurePosixPath(rel).parts:
                continue
            target = destination.joinpath(*PurePosixPath(rel).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read(name))
            extracted += 1
        if extracted < 100:
            raise SystemExit(f"Base pack extraction looks incomplete ({extracted} files)")


def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit("usage: assemble_pack.py ID LABEL N")
    variant_id, label, n_raw = sys.argv[1:]
    if not safe_id(variant_id):
        raise SystemExit("ID must contain lowercase letters, digits, and hyphens only")
    if not label.strip():
        raise SystemExit("LABEL cannot be empty")
    try:
        n = int(n_raw)
    except ValueError:
        raise SystemExit("N must be an integer")
    if not 1 <= n <= 999:
        raise SystemExit("N must be between 1 and 999")

    compiled = {}
    for name in MATERIAL_NAMES:
        path = COMPILED_DIR / name
        if not path.is_file() or path.stat().st_size < 1024:
            raise SystemExit(
                f"Missing or implausibly small compiled material: {path}. "
                "The cloud shader must compile successfully before packaging."
            )
        compiled[name] = path
    if not BASE_PACK.is_file():
        raise SystemExit(f"Missing bundled base pack: {BASE_PACK}")

    with tempfile.TemporaryDirectory(prefix="mirai-cloud-pack-") as tmp:
        stage = Path(tmp) / "pack"
        stage.mkdir(parents=True)
        extract_flat_pack(BASE_PACK, stage)

        manifest_path = stage / "manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for name in MATERIAL_NAMES:
            original = stage / "renderer/materials" / name
            if not original.is_file():
                raise SystemExit(f"Base pack does not contain renderer/materials/{name}")

        # Register one in-menu subpack while retaining any unrelated entries.
        subpacks = manifest.setdefault("subpacks", [])
        subpacks = [entry for entry in subpacks
                    if not (isinstance(entry, dict) and entry.get("folder_name") == SUBPACK_FOLDER)]
        subpacks.append({
            "folder_name": SUBPACK_FOLDER,
            "name": "Nubes Mirai 2.1.1",
            "memory_performance_tier": 0,
        })
        manifest["subpacks"] = subpacks

        # Bump the pack version so Bedrock distinguishes this build from 3.1.0.
        version = [3, 1, n]
        manifest.setdefault("header", {})["version"] = version
        manifest["header"]["name"] = f"Mirai 3.1.{n} — {label}"
        description = manifest["header"].get("description", "")
        note = "Select the Nubes Mirai 2.1.1 subpack in pack settings for Mirai 2.1.1 volumetric clouds."
        manifest["header"]["description"] = (description.rstrip() + "\n" + note).strip()
        for module in manifest.get("modules", []):
            if isinstance(module, dict):
                module["version"] = version
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

        for name, compiled_path in compiled.items():
            override = stage / "subpacks" / SUBPACK_FOLDER / "renderer/materials" / name
            override.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(compiled_path, override)

        out_path = ROOT / f"mirai-{variant_id}.mcpack"
        with zipfile.ZipFile(out_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for path in sorted(stage.rglob("*")):
                if path.is_file():
                    archive.write(path, path.relative_to(stage).as_posix())

    # Validate archive root, preservation of the full base pack and both subpack overrides.
    with zipfile.ZipFile(out_path, "r") as archive:
        names = set(archive.namelist())
        if "manifest.json" not in names:
            raise SystemExit("Package validation failed: manifest.json must be at archive root")
        for name in MATERIAL_NAMES:
            if f"renderer/materials/{name}" not in names:
                raise SystemExit(f"Package validation failed: base material {name} is missing")
            if f"subpacks/{SUBPACK_FOLDER}/renderer/materials/{name}" not in names:
                raise SystemExit(f"Package validation failed: subpack override {name} is missing")
        material_count = sum(1 for name in names if name.startswith("renderer/materials/") and name.endswith(".material.bin"))
        if material_count < 30:
            raise SystemExit(f"Package validation failed: only {material_count} base materials were preserved")
        checked = json.loads(archive.read("manifest.json"))
        if not any(p.get("folder_name") == SUBPACK_FOLDER and p.get("name") == "Nubes Mirai 2.1.1"
                   for p in checked.get("subpacks", []) if isinstance(p, dict)):
            raise SystemExit("Package validation failed: Nubes Mirai 2.1.1 is not registered in manifest.json")
        if any(name.startswith("materials/") for name in names):
            raise SystemExit("Package validation failed: invalid root-level materials/ directory detected")
        if any(name.startswith("mirai-android-3.1.0/") for name in names):
            raise SystemExit("Package validation failed: legacy wrapper directory leaked into the archive")

    print(f"Created {out_path.name}: full base pack plus selectable Nubes Mirai 2.1.1 subpack.")
    print(f"Preserved {material_count} base material binaries; added {len(MATERIAL_NAMES)} compiled material overrides.")


if __name__ == "__main__":
    main()
