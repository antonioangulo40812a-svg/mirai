#!/usr/bin/env python3
"""Assemble a complete .mcpack from the preserved Mirai base and rebuilt materials."""
from __future__ import annotations
import json
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def copy_overlay_tree(source: Path, destination: Path) -> None:
    if source.is_dir():
        shutil.copytree(source, destination, dirs_exist_ok=True)

def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) != 3:
        print("usage: python tools/assemble_pack.py <id> <label> <version_patch>", file=sys.stderr)
        return 2
    variant_id, label, patch_raw = argv
    if not re.fullmatch(r"[A-Za-z0-9._-]+", variant_id):
        print("error: invalid variant id", file=sys.stderr)
        return 2
    try:
        patch = int(patch_raw)
    except ValueError:
        print("error: version_patch must be an integer", file=sys.stderr)
        return 2
    if not 0 <= patch <= 65535:
        print("error: version_patch is outside the allowed range", file=sys.stderr)
        return 2

    pack_src = ROOT / "pack"
    build_src = ROOT / "output-android" / "renderer" / "materials"
    base_materials = ROOT / "renderer" / "materials"
    manifest_src = pack_src / "manifest.json"
    required = build_src / "DeferredMixedResolutionLightingPrepass.material.bin"

    if not pack_src.is_dir() or not manifest_src.is_file():
        print("error: pack/ or pack/manifest.json is missing", file=sys.stderr)
        return 2
    if not base_materials.is_dir():
        print("error: preserved renderer/materials base is missing from overlay.zip", file=sys.stderr)
        return 2
    if not required.is_file():
        print("error: rebuilt DeferredMixedResolutionLightingPrepass is missing", file=sys.stderr)
        return 2

    out_file = ROOT / f"mirai-{variant_id}.mcpack"
    with tempfile.TemporaryDirectory(prefix="mirai-pack-") as temp:
        stage = Path(temp) / "pack"
        shutil.copytree(pack_src, stage)

        # Restore the precompiled base materials and existing cloud subpack.
        copy_overlay_tree(ROOT / "renderer", stage / "renderer")
        copy_overlay_tree(ROOT / "subpacks", stage / "subpacks")

        # The current CI job rebuilds only DeferredMixedResolution*; these
        # freshly compiled files overwrite the matching preserved binaries.
        if build_src.is_dir():
            shutil.copytree(build_src, stage / "renderer" / "materials", dirs_exist_ok=True)

        final_materials = list((stage / "renderer" / "materials").glob("*.material.bin"))
        if len(final_materials) < 50:
            print(f"error: only {len(final_materials)} base materials found; overlay is incomplete", file=sys.stderr)
            return 2

        manifest_path = stage / "manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        version = [3, 1, patch]
        manifest.setdefault("header", {})["version"] = version
        manifest["header"]["name"] = f"Mirai 3.1.{patch} — {label}"
        old_desc = manifest["header"].get("description", "Mirai")
        variant_line = f"Experimental lighting variant: {label}"
        if variant_line not in old_desc:
            manifest["header"]["description"] = old_desc.rstrip() + "\n" + variant_line
        for module in manifest.get("modules", []):
            module["version"] = version
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        with zipfile.ZipFile(out_file, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for path in sorted(stage.rglob("*")):
                if path.is_file():
                    archive.write(path, path.relative_to(stage).as_posix())

    print(f"Created {out_file.name} ({out_file.stat().st_size:,} bytes)")
    print(f"Preserved {len(final_materials)} compiled materials and existing subpacks.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
