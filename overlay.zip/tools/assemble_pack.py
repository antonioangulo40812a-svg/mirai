#!/usr/bin/env python3
"""Assemble a temporary Bedrock resource pack from pack/ and output-android/."""
import json
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def main():
    if len(sys.argv) != 4:
        raise SystemExit("usage: assemble_pack.py ID LABEL N")
    variant_id, label, n_raw = sys.argv[1:]
    try:
        n = int(n_raw)
    except ValueError:
        raise SystemExit("N must be an integer")

    source_pack = ROOT / "pack"
    compiled_dir = ROOT / "output-android"
    source_manifest = source_pack / "manifest.json"
    if not source_manifest.is_file():
        raise SystemExit(f"Missing resource-pack manifest: {source_manifest}")
    if not compiled_dir.is_dir():
        raise SystemExit(f"Compiled output directory not found: {compiled_dir}")

    compiled = sorted(compiled_dir.glob("*.material.bin"))
    if not compiled:
        raise SystemExit(
            f"No compiled *.material.bin files found in {compiled_dir}; "
            "check the material filter and build log."
        )

    with tempfile.TemporaryDirectory(prefix="mirai-pack-") as tmp:
        stage = Path(tmp) / "pack"
        shutil.copytree(source_pack, stage)
        materials = stage / "materials"
        materials.mkdir(parents=True, exist_ok=True)
        for item in compiled:
            shutil.copy2(item, materials / item.name)

        manifest_path = stage / "manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        version = [3, 1, n]
        manifest["header"]["name"] = f"Mirai 3.1.0 - {label}"
        manifest["header"]["version"] = version
        for module in manifest.get("modules", []):
            module["version"] = version
        manifest_path.write_text(
            json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

        out_path = ROOT / f"mirai-{variant_id}.mcpack"
        with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(stage.rglob("*")):
                if path.is_file():
                    archive.write(path, path.relative_to(stage).as_posix())

    # Verify the artifact contains a manifest and compiled materials.
    with zipfile.ZipFile(out_path) as archive:
        names = archive.namelist()
        if "manifest.json" not in names:
            raise SystemExit("Pack validation failed: manifest.json is missing")
        if not any(name.startswith("materials/") and name.endswith(".material.bin") for name in names):
            raise SystemExit("Pack validation failed: no compiled material binaries were packaged")
    print(f"Created {out_path.name} with {len(compiled)} compiled material(s).")

if __name__ == "__main__":
    main()
