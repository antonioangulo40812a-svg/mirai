#!/usr/bin/env python3
"""Build a Mirai variant .mcpack: official Mirai Android pack + freshly compiled materials.

usage: python tools/assemble_pack.py <id> <label> <n>
env  : VARIANT (json) with optional extra build stages and subpacks:
  "base_from_build": false   -> do not copy stage 0 into the base pack (base stays official Mirai)
  "stages": [ {"materials": "ColorPostProcessing" | ["DeferredMixedResolution*", "ColorPostProcessing"], "tier": 1,
               "defines": {"MIRAI_CA": "1"},
               "dest": "base" | "subpack", "folder": "ca", "name": "Chromatic aberration"} ]
  "empty_subpacks": [ {"folder": "plain", "name": "No post processing"} ]
Stage 0 (the materials already built by the workflow into output-android/) always goes
to the base pack. Every extra stage re-runs build.py with its own #define overrides.
needs: base/*.mcpack (official Mirai Android pack)
"""
import json, os, re, shlex, shutil, subprocess, sys, uuid, zipfile
from pathlib import Path

slug, label, n = sys.argv[1], sys.argv[2], int(sys.argv[3])
variant = json.loads(os.environ.get("VARIANT") or "{}")
root = Path(__file__).resolve().parent.parent
bases = sorted((root / "base").glob("*.mcpack"))
if not bases:
    sys.exit("error: put the official Mirai Android .mcpack in base/")
out_dir = root / "output-android"
built = sorted(out_dir.glob("*.material.bin"))
if not built:
    sys.exit("error: output-android/ has no .material.bin (did the build fail?)")

work = root / "work"
shutil.rmtree(work, ignore_errors=True)
with zipfile.ZipFile(bases[0]) as z:
    z.extractall(work)
manifest_path = next(work.rglob("manifest.json"))
pack = manifest_path.parent
mats = pack / "renderer" / "materials"
if not mats.is_dir():
    sys.exit(f"error: {mats} not found in the base pack")


def put(files, target):
    target.mkdir(parents=True, exist_ok=True)
    for f in files:
        if not (mats / f.name).is_file():
            sys.exit(f"error: {f.name} is not in the base pack, refusing to add unknown material")
        shutil.copy2(f, target / f.name)


def apply_defines(cfg, defines):
    text = cfg.read_text(encoding="utf-8")
    for key, value in defines.items():
        pat = re.compile(rf"^#define {re.escape(key)} .*$", re.M)
        if not pat.search(text):
            sys.exit(f"error: '#define {key}' not found in {cfg.name}")
        text = pat.sub(f"#define {key} {value}", text, count=1)
    cfg.write_text(text, encoding="utf-8")


# stage 0: what the workflow already compiled (copied now, before extra builds touch the folder)
if variant.get("base_from_build", True):
    put(built, mats)
    summary = [f"base: {len(built)} material(s)"]
else:
    summary = ["base: official Mirai"]

# extra stages
cfg = root / "src" / "include" / "diag_config.glsl"
saved = cfg.read_text(encoding="utf-8")
subpacks = []
for st in variant.get("stages", []):
    cfg.write_text(saved, encoding="utf-8")
    apply_defines(cfg, st.get("defines", {}))
    patterns = st["materials"] if isinstance(st["materials"], list) else [st["materials"]]
    cmd = shlex.split(os.environ.get("MIRAI_BUILD_CMD", "")) or [sys.executable, "build.py", "android"]
    files = []
    for pattern in patterns:
        subprocess.run(cmd + ["-m", pattern], cwd=root, check=True)
        got = sorted(out_dir.glob(pattern + ".material.bin"))
        if not got:
            sys.exit(f"error: stage for '{pattern}' produced no .material.bin")
        files += got            # collected right away: the next build may overwrite the folder
    if st.get("dest") == "subpack":
        folder = st["folder"]
        put(files, pack / "subpacks" / folder / "renderer" / "materials")
        subpacks.append({"folder_name": folder, "name": st["name"], "memory_tier": st.get("tier", 1)})
        summary.append(f"subpack {folder}: {', '.join(f.name for f in files)}")
    else:
        put(files, mats)
        summary.append(f"base overridden: {', '.join(f.name for f in files)}")
cfg.write_text(saved, encoding="utf-8")

# empty subpacks (use the base materials as they are)
for e in variant.get("empty_subpacks", []):
    (pack / "subpacks" / e["folder"] / "renderer" / "materials").mkdir(parents=True, exist_ok=True)
    subpacks.insert(0, {"folder_name": e["folder"], "name": e["name"], "memory_tier": 0})
    summary.append(f"empty subpack {e['folder']}")

# keep Mirai's MIT notice and credits inside the pack (required when redistributing)
if (root / "LICENSE").is_file():
    shutil.copy2(root / "LICENSE", pack / "LICENSE-Mirai.txt")
(pack / "credits.txt").write_text(
    "Mirai shader by bambosan (MIT license, see LICENSE-Mirai.txt)\n"
    "https://github.com/bambosan/mirai\n\n"
    "This build adds, on top of Mirai: screen space global illumination with colour bleeding,\n"
    "procedural volumetric clouds (also reflected in water) and optional post effects.\n"
    "Added code is original work; it does not use code from other shader packs.\n",
    encoding="utf-8")

m = json.loads(manifest_path.read_text(encoding="utf-8"))
m["header"]["name"] = f"Mirai {label}"
m["header"]["uuid"] = str(uuid.uuid5(uuid.NAMESPACE_URL, f"mirai-variant-header-{slug}"))
m["header"]["version"] = [3, 0, 200 + n]
for mod in m.get("modules", []):
    mod["uuid"] = str(uuid.uuid5(uuid.NAMESPACE_URL, f"mirai-variant-module-{slug}"))
    mod["version"] = [3, 0, 200 + n]
if subpacks:
    m["subpacks"] = subpacks
manifest_path.write_text(json.dumps(m, indent=2, ensure_ascii=False), encoding="utf-8")

out = root / f"mirai-{slug}.mcpack"
out.unlink(missing_ok=True)
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(work.rglob("*")):
        z.write(p, p.relative_to(work).as_posix())
print(f"wrote {out.name}: " + "; ".join(summary))
